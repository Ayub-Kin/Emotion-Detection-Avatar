import cv2
import numpy as np
from vosk import Model, KaldiRecognizer
import wave
import json
import pyaudio
from fer import FER
from datetime import datetime, timezone
import os
import threading
import time
import re
import pyttsx3
import subprocess
from collections import Counter, deque
from pymongo import MongoClient
import tempfile
import queue
import random
import logging
import requests
from concurrent.futures import ThreadPoolExecutor
from bson import ObjectId

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Direct Ollama query
def query_ollama(stt_text, emotion_context, conversation_history=None, use_emotion_context=True):
    OLLAMA_URL = "http://localhost:11434/api/generate"
    OLLAMA_MODEL = "llama3.2:latest"
    # Default emotional response parameters
    emotional_guidance = {
        'response_length': "brief",  # Force brief responses (1-2 sentences)
        'emotional_tone': "supportive",
        'complexity': "simple"
    }

    # Analyze emotional context to adjust response parameters
    if use_emotion_context and emotion_context:
        # Apply privacy scrubbing if needed (this should be handled separately)
        if emotion_context.get('privacy_mode', False):
            stt_text = scrub_sensitive_info(stt_text)
        
        facial_emotion = emotion_context.get('facial_emotion', 'neutral').lower()
        tone_emotion = emotion_context.get('tone_emotion', 'neutral').lower()
        text_sentiment = emotion_context.get('text_sentiment', 'neutral').lower()

        # Adjust response parameters based on emotions
        if any(e in ['angry', 'frustrated'] for e in [facial_emotion, tone_emotion]):
            emotional_guidance.update({
                'emotional_tone': "calming",
                'response_length': "short",
                'complexity': "simple"
            })
        elif any(e in ['sad', 'disappointed'] for e in [facial_emotion, tone_emotion]):
            emotional_guidance.update({
                'emotional_tone': "comforting",
                'response_length': "short"
            })
        elif any(e in ['happy', 'excited'] for e in [facial_emotion, tone_emotion]):
            emotional_guidance.update({
                'emotional_tone': "enthusiastic",
                'response_length': "short"
            })

        context_prompt = f"""You are an emotionally intelligent assistant. Respond to the user while considering:

1. USER'S STATE:
- Facial emotion: {facial_emotion}
- Voice tone: {tone_emotion}
- Text sentiment: {text_sentiment}

2. RESPONSE GUIDELINES:
- Reply in a single, creative sentence.
- Be emotionally aware and brief (1 sentence max)
- Be playful, witty, or surprising if possible
- DO NOT repeat the user's message
- If the emotion is negative, you may gently suggest listening to music or another uplifting activity
- Empathy is key in emotional situations (angry, sad, frustrated)
- Do NOT use phrases like "I sense", "I can tell", "I hear", "I notice", or similar. Instead, show empathy in a more creative or indirect way.

3. CONTEXT:
{conversation_history[-3:] if conversation_history else 'No prior context'}

USER MESSAGE: "{stt_text}"

YOUR TASK:
- Acknowledge the user's emotional state (especially if sad, angry, or frustrated)
- DO NOT repeat the user's exact words
- Your tone must reflect the user's emotional context
- Suggest unique, uplifting, or even slightly funny ideas to cheer the user up
- If the user feels bad, you may suggest a specific uplifting song (mention the title & artist)
- Avoid repeating past suggestions too frequently
- Keep your message very short (1 sentence), emotionally aware, and naturally conversational
"""
    else:
        context_prompt = f"""You are a helpful assistant. Respond to:
"{stt_text}"
Guidelines:
- Be concise (1-2 sentences)
- Be helpful
- Stay neutral in tone"""

    # Optimized payload for faster response
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": context_prompt,
        "stream": False,
        "options": {
            "temperature": 1.0,  
            "top_p": 0.95,
            "num_ctx": 1024,
            "num_predict": 40,  
            "stop": [".", "\n", "User:"]
        }
    }

    mode = "emotional" if use_emotion_context and emotion_context else "normal"
    logger.info(f"🤖 Querying Ollama (mode: {mode}, emotional_tone: {emotional_guidance['emotional_tone']})")
    
    try:
        # Faster timeout with retries
        for attempt in range(3):
            try:
                response = requests.post(
                    OLLAMA_URL,
                    json=payload
                )
                
                if response.status_code == 200:
                    result = response.json()
                    raw_response = result.get("response", "").strip()
                    
                    # Post-process response for emotional alignment
                    return adjust_response_for_emotion(
                        raw_response,
                        emotional_guidance,
                        emotion_context
                    )
                    
                elif response.status_code >= 500 and attempt < 2:
                    time.sleep(1 * (attempt + 1))  # Exponential backoff
                    continue
                    
            except requests.exceptions.Timeout:
                if attempt == 2:
                    raise
                time.sleep(1 * (attempt + 1))
                
        logger.error(f"❌ Ollama API error: {response.status_code}")
        return emotional_fallback_response(emotion_context)
        
    except Exception as e:
        logger.error(f"❌ Ollama connection failed: {e}")
        return emotional_fallback_response(emotion_context)

def adjust_response_for_emotion(response, guidance, emotion_context):
    """Ensure response matches emotional guidelines and adds empathy or support"""
    global last_suggestion

    if not emotion_context:
        return response

    facial = emotion_context.get('facial_emotion', '').lower()
    tone = emotion_context.get('tone_emotion', '').lower()
    negative_emotions = ['angry', 'sad', 'frustrated', 'disappointed']

    should_suggest = any(e in negative_emotions for e in [facial, tone])
    
    # Ensure response is brief
    sentences = [s.strip() for s in response.split('.') if s.strip()]
    if guidance.get('response_length') == 'brief' and len(sentences) > 2:
        response = '. '.join(sentences[:2]) + '.'
    return response

def emotional_fallback_response(emotion_context):
    """Context-aware fallback responses"""
    if not emotion_context:
        return "I'm here to help. Could you please try again?"
    
    tone = emotion_context.get('tone_emotion', 'neutral')
    if tone in ['angry', 'frustrated']:
        return "I want to help with this. Let me try that again."
    elif tone == 'sad':
        return "I'm sorry for the trouble. Please give me another moment."
    return "I'm working on your request. Just a moment..."

 #JSON serialization helper for MongoDB ObjectId
def serialize_for_json(obj):
    """Convert MongoDB ObjectId and other non-serializable objects to JSON-compatible format"""
    if isinstance(obj, ObjectId):
        return str(obj)
    elif isinstance(obj, dict):
        return {key: serialize_for_json(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [serialize_for_json(item) for item in obj]
    else:
        return obj

# ========== MongoDB Setup ==========
try:
    mongo_client = MongoClient("mongodb://localhost:27017", serverSelectionTimeoutMS=5000)
    mongo_db = mongo_client["emotion_avatar"]
    emotions_collection = mongo_db["emotions"]
    interactions_collection = mongo_db["interactions"]
    mongo_client.server_info()  # Trigger connection check
    logger.info("✅ MongoDB connected successfully")
except Exception as e:
    logger.warning(f"⚠️ MongoDB connection failed: {e}. Continuing without database.")
    emotions_collection = None
    interactions_collection = None

# Global shared variables
latest_emotion_result = {}
current_frame = None
last_suggestion = None
frame_lock = threading.Lock()
display_frame = None
display_frame_lock = threading.Lock()
detection_active = threading.Event()
audio_active = threading.Event()
camera_active = threading.Event()
current_phase = "Ready - Talk to Avatar"
phase_start_time = time.time()
avatar_talking = threading.Event()
interaction_active = threading.Event()
processing_active = threading.Event()
listening_active = threading.Event()
stt_processing_active = threading.Event()
tone_analysis_allowed = threading.Event()
running = False
cap = None
camera_thread = None
detection_thread = None
systems_paused = False
# Emotion recognition setup
emotion_detector = None
emotion_window = deque(maxlen=80)
speech_data_queue = queue.Queue()
sentiment_to_emotion = {"positive": "happy", "negative": "sad", "neutral": "neutral"}

# Create output folder
if not os.path.exists("collected_data"):
    os.makedirs("collected_data")

# Initialize TTS to use eSpeak-NG
logger.info("✅ TTS system set to use local espeak-ng")

# Initialize FER with error handling
try:
    emotion_detector = FER(mtcnn=False)
    logger.info("✅ FER emotion detector initialized")
except Exception as e:
    logger.error(f"❌ Failed to initialize FER: {e}")
    emotion_detector = None

# Initialize Vosk model with error handling
vosk_model = None
try:
    model_paths = [
        "vosk-model-en-us-0.22",
        "vosk-model-small-en-us-0.15",
        "model"
    ]
    
    for model_path in model_paths:
        if os.path.exists(model_path):
            try:
                # Check if model directory has required files
                required_files = ["am", "conf", "graph", "ivector"]
                missing_files = [f for f in required_files if not os.path.exists(os.path.join(model_path, f))]
                
                if missing_files:
                    logger.warning(f"⚠️ Model {model_path} missing required files: {missing_files}")
                    continue
                
                vosk_model = Model(model_path)
                logger.info(f"✅ Vosk model loaded from {model_path}")
                break
            except Exception as model_error:
                logger.warning(f"⚠️ Failed to load model from {model_path}: {model_error}")
                continue
    
    if vosk_model is None:
        logger.warning("⚠️ No Vosk model found. Speech recognition will be disabled.")
        # Create a dummy model for testing
        vosk_model = None
        
except Exception as e:
    logger.error(f"❌ Failed to load Vosk model: {e}")
    vosk_model = None

# Thread-safe performance metrics with change detection
performance_lock = threading.Lock()
timing_data = {
    "stt_time": 0.0,
    "tone_time": 0.0,
    "llm_time": 0.0,
    "tts_time": 0.0,
    "total_time": 0.0,
    "last_updated": datetime.now(timezone.utc).isoformat(),
    "interaction_count": 0
}
# Store previous timing data to detect changes
previous_timing_data = timing_data.copy()

# Add a global variable to store the latest emotion samples
latest_emotion_samples = []
latest_emotion_samples_raw = []

# Global variables for system state
latest_emotion_result = {}
current_llm_response = ""  # Add this line to store current LLM response
current_dominant_emotion = "neutral"  # Store current dominant emotion for immediate access

# ========== Performance Timing Utilities ==========
class Timer:
    def __init__(self, name):
        self.name = name
        self.start_time = None
        
    def __enter__(self):
        self.start_time = time.perf_counter()
        return self
        
    def __exit__(self, *args):
        end_time = time.perf_counter()
        # Only subtract if self.start_time is not None
        if self.start_time is not None:
            duration = end_time - self.start_time
        else:
            duration = 0.0
        with performance_lock:
            global timing_data
            timing_data[f"{self.name}_time"] = duration
            timing_data["last_updated"] = datetime.now(timezone.utc).isoformat()
        logger.info(f"⏱️ {self.name.upper()}: {duration:.3f}s")

def reset_performance_metrics():
    """Reset all performance metrics to zero"""
    with performance_lock:
        global timing_data
        timing_data.update({
            "stt_time": 0.0,
            "tone_time": 0.0,
            "llm_time": 0.0,
            "tts_time": 0.0,
            "total_time": 0.0,
            # Always set last_updated to current UTC time
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "interaction_count": timing_data.get("interaction_count", 0)
        })
    logger.debug("📊 Performance metrics reset")

def update_performance_metric(metric_name, value):
    """Thread-safe update of individual performance metric with timeout"""
    try:
        # Use timeout to avoid deadlock in subsequent interactions
        if performance_lock.acquire(timeout=1.0):  # 1 second timeout
            try:
                global timing_data
                timing_data[metric_name] = value
                timing_data["last_updated"] = datetime.now(timezone.utc).isoformat()
            finally:
                performance_lock.release()
        else:
            logger.warning(f"⚠️ Performance metric update timeout for {metric_name} - skipping")
    except Exception as e:
        logger.warning(f"⚠️ Performance metric update failed for {metric_name}: {e}")

# ========== Database Functions ==========
def save_to_database(emotion_data):
    """Save emotion data to MongoDB with proper ObjectId handling"""
    if emotions_collection is not None:
        try:
            result = emotions_collection.insert_one(emotion_data)
            logger.debug(f"💾 Saved to database: {emotion_data.get('final_emotion', 'unknown')} with ID: {result.inserted_id}")
        except Exception as e:
            logger.error(f"❌ Database save error: {e}")

# ========== Camera Management ==========
def initialize_camera():
    """Initialize camera with multiple backend attempts"""
    global cap

    if cap is not None and cap.isOpened():
        logger.info("📷 Camera already initialized and open")
        return True
    
    backends = [
        (cv2.CAP_DSHOW, "DirectShow"),
        (cv2.CAP_V4L2, "V4L2"),
        (cv2.CAP_ANY, "Any")
    ]
    
    for backend, name in backends:
        try:
            logger.info(f"🔧 Trying camera with {name} backend")
            cap = cv2.VideoCapture(0, backend)

            if cap.isOpened():
                # Optimize camera settings for speed
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                cap.set(cv2.CAP_PROP_FPS, 30)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  
                
                ret, test_frame = cap.read()
                if ret and test_frame is not None:
                    logger.info(f"✅ Camera initialized successfully with {name}")
                    return True
                else:
                    logger.warning(f"⚠️ {name} backend opened but failed to capture frame")
                    cap.release()
                    cap = None
            else:
                logger.warning(f"⚠️ Failed to open camera with {name} backend")
                
        except Exception as e:
            logger.error(f"❌ Camera init error with {name}: {e}")
            if cap:
                cap.release()
                cap = None

    logger.error("❌ Failed to initialize camera with any backend")
    return False

def camera_thread_func():
    """Optimized camera capture thread with proper status display"""
    global current_frame, display_frame, cap, camera_active
    
    logger.info("🎥 Camera thread started")
    frame_count = 0
    
    while camera_active.is_set():
        try:
            if cap and cap.isOpened():
                ret, frame = cap.read()
                if ret and frame is not None:
                    with frame_lock:
                        current_frame = frame.copy()
                    
                    # Create display frame with current status 
                    frame_for_display = frame.copy()
                    
                    # Determining current status with clearer priority
                    if avatar_talking.is_set():
                        status_text = "AVATAR SPEAKING - Please wait..."
                        status_color = (255, 0, 255)  # Magenta
                    elif processing_active.is_set():
                        status_text = "PROCESSING - Please wait..."
                        status_color = (0, 165, 255)  # Orange
                    elif listening_active.is_set():
                        status_text = "LISTENING - Speak now..."
                        status_color = (0, 255, 0)  # Green
                    else:
                        status_text = "READY - Click 'Talk to Avatar' to start"
                        status_color = (0, 255, 255)  # Yellow
                        
                    cv2.putText(frame_for_display, status_text, 
                              (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, status_color, 2)
                    
                    with display_frame_lock:
                        display_frame = frame_for_display
                    
                    frame_count += 1
                else:
                    logger.warning("⚠️ Failed to read frame from camera")
                    time.sleep(0.1)
            else:
                logger.warning("⚠️ Camera not available")
                time.sleep(1)
                
        except Exception as e:
            logger.error(f"❌ Error in camera thread: {e}")
            time.sleep(1)
        
        time.sleep(1.0/30.0)  # 30 FPS
    
    logger.info("🛑 Camera thread stopped")

def start_camera():
    """Start camera capture"""
    global camera_thread, camera_active
    
    if camera_active.is_set():
        logger.info("📷 Camera already running")
        return True
    
    if not initialize_camera():
        logger.error("❌ Failed to initialize camera")
        return False
    
    camera_active.set()
    camera_thread = threading.Thread(target=camera_thread_func, daemon=True)
    camera_thread.start()
    
    time.sleep(0.5)
    logger.info("✅ Camera started successfully")
    return True

def stop_camera():
    """Stop camera capture"""
    global cap, camera_active, camera_thread
    
    logger.info("🛑 Stopping camera...")
    camera_active.clear()
    
    if camera_thread and camera_thread.is_alive():
        camera_thread.join(timeout=2)
    
    if cap:
        cap.release()
        cap = None
    
    with display_frame_lock:
        global display_frame
        display_frame = None
    
    logger.info("✅ Camera stopped")

def get_frame():
    """Get the current camera frame for video feed"""
    try:
        with display_frame_lock:
            if display_frame is None or not camera_active.is_set():
                return None
                
            ret, jpeg = cv2.imencode('.jpg', display_frame) # Convert frame to JPEG
            return jpeg.tobytes() if ret else None
    except Exception as e:
        logger.error(f"Frame capture error: {e}")
        return None
    
# ========== ULTRA-FAST STT with Immediate Response ==========
def perform_speech_to_text_vosk():
    global current_phase, phase_start_time, p, stream
    logger.info("🎤 Starting STT with improved word capture")
    
    if vosk_model is None:
        logger.error("❌ Vosk STT model not loaded — using fallback") 
        return ("test speech for debugging", None) 

    p = None
    stream = None
    
    # Update UI to show listening phase immediately
    current_phase = "🎤 LISTENING - Speak now!"
    phase_start_time = time.time()
    logger.info(f"📱 UI Phase set to: {current_phase}")
    
    # Timeout mechanism
    start_time = time.time()
    max_total_time = 12  # Maximum 12 seconds total for STT
    max_silence_time = 1.0
    try:
        p = pyaudio.PyAudio() # Initialize PyAudio
        # Configure audio stream
        stream = p.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=16000,
            input=True,
            frames_per_buffer=2048,
            input_device_index=None,
            start=False
        )
        stream.start_stream()
        
        recognizer = KaldiRecognizer(vosk_model, 16000) # Initialize Vosk recognizer
        # Audio buffer for saving
        audio_buffer = []
        final_text = ""
        max_listening_time = 5.0  # Hard limit - no exceptions
        silence_threshold = max_silence_time
        speech_detected = False
        start_time = time.time()
        words_collected = []
        partial_results = []
        
        volume_threshold = 300  # Threshold for better sensitivity
        ambient_samples = []
        ambient_calibration_time = 0.5  # To calibrate ambient noise
        ambient_calibration_start = time.time()
        # Variables for silence detection timing
        last_speech_time = None
        silence_start_time = None
        silence_detected = False
        current_phase = "🎤 LISTENING - Speak now!"
        phase_start_time = time.time()
        logger.info("🎙️ PHASE 1A: LISTENING - Speak now (max 5 seconds)...")
        
        consecutive_errors = 0
        max_consecutive_errors = 5
        
        while listening_active.is_set():
            current_time = time.time()
            elapsed_time = current_time - start_time
            # STRICT 5-second timeout 
            if elapsed_time >= max_listening_time:
                logger.info(f"⏰ Maximum listening time ({max_listening_time}s) reached - stopping immediately")
                current_phase = "⏰ Time's up (5s) - Processing..."
                break 
            # Check total timeout
            if current_time - start_time > max_total_time:
                logger.warning("⏰ Maximum 5s time reached")
                break
            
            try:
                # Read audio data
                try:
                    data = stream.read(2048, exception_on_overflow=False)
                except Exception as read_error:
                    logger.warning(f"⚠️ Audio read timeout: {read_error}")
                    break
                audio_buffer.append(data)
                # Volume analysis with ambient noise calibration
                audio_data = np.frombuffer(data, dtype=np.int16)
                if len(audio_data) == 0:
                    volume = 0
                else:
                    with np.errstate(invalid='ignore'):
                        volume = np.sqrt(np.mean(audio_data**2))
                    if np.isnan(volume):
                        volume = 0
                # Calibrate ambient noise during first 0.5 seconds
                if current_time - ambient_calibration_start < ambient_calibration_time:
                    ambient_samples.append(volume)
                    if len(ambient_samples) > 5:  # After 5 samples, set threshold
                        ambient_volume = np.mean(ambient_samples)
                        volume_threshold = max(300, ambient_volume * 1.5)  # 1.5x ambient noise
                        logger.info(f"🔊 Ambient noise calibrated. Threshold set to {volume_threshold:.1f}")
                    continue
                # Speech detection with silence detection
                if volume > volume_threshold:
                    if not speech_detected:
                        speech_detected = True
                        last_speech_time = current_time
                        silence_start_time = None
                        logger.info("🗣️ Speech started")
                    silence_count = 0
                    last_speech_time = current_time
                elif speech_detected:
                    silence_count += 1
                    if silence_start_time is None:
                        silence_start_time = current_time
                    
                    # Calculate exact silence duration
                    silence_duration = current_time - last_speech_time if last_speech_time else 0
                    
                    # Only consider it silence if it's a continuous silence for the threshold period
                    if silence_duration >= silence_threshold:
                        logger.info(f"🔇 Silence detected for {silence_duration:.2f}s (threshold: {silence_threshold}s)")
                        silence_detected = True
                        break
                
                # Process with Vosk
                try:
                    if recognizer.AcceptWaveform(data):
                        res = json.loads(recognizer.Result())
                        text = res.get("text", "").strip()
                        if text:
                            words = text.split()
                            words_collected.extend(words)
                            final_text += text + " "
                            current_phase = f"📝 Got: '{text}' ({len(words_collected)} words)"
                            logger.info(f"📝 Final words: {text} (Total: {len(words_collected)})")
                            # Reset silence on new words
                            silence_count = 0
                            last_speech_time = current_time
                            silence_start_time = None
                    else:
                        # Capture partial results
                        try:
                            partial_res = json.loads(recognizer.PartialResult())
                            partial_text = partial_res.get("partial", "").strip()
                            if partial_text:
                                partial_results.append(partial_text)
                                current_phase = f"📝 Hearing: '{partial_text}'"
                                logger.debug(f"📝 Partial: {partial_text}")
                        except json.JSONDecodeError:
                            pass
                except Exception as vosk_error:
                    logger.warning(f"⚠️ Vosk processing error: {vosk_error}")
                    consecutive_errors += 1
                    if consecutive_errors >= max_consecutive_errors:
                        logger.error("❌ Too many consecutive Vosk errors")
                        break
                    time.sleep(0.01)  # Brief pause before retrying

                # Only stop if there is speech AND significant silence AND some words
                if (elapsed_time < max_listening_time and 
                    speech_detected and 
                    len(words_collected) > 0 and
                    silence_detected):
                    
                    logger.info(f"✅ Speech complete! Words: {len(words_collected)}, "
                               f"Silence detected after {silence_duration:.2f}s")
                    current_phase = "✅ Speech complete - Processing..."
                    break
                
                # Alternative stop condition: if we have words and enough time has passed
                if (len(words_collected) > 0 and 
                    speech_detected and 
                    elapsed_time > 3.0 and  # Start checking after 3 seconds
                    elapsed_time < max_listening_time and  
                    (last_speech_time is not None and (current_time - last_speech_time) > silence_threshold)):
                    
                    logger.info(f"✅ Speech complete (time-based)! Words: {len(words_collected)}, "
                               f"Time elapsed: {elapsed_time:.1f}s")
                    current_phase = "✅ Speech complete - Processing..."
                    break
                
            except Exception as e:
                logger.error(f"❌ Audio processing error: {e}")
                consecutive_errors += 1
                if consecutive_errors >= max_consecutive_errors:
                    logger.error("❌ Too many consecutive audio errors")
                    break
                time.sleep(0.01)
        
        # Final processing with extended timeout
        current_phase = "🎙️ CONVERTING SPEECH-TO-TEXT..."
        logger.info("🎙️ PHASE 1B: CONVERTING SPEECH-TO-TEXT - Finalizing...")
        listening_active.clear()
        
        # Process remaining audio buffer
        remaining_buffer = b''.join(audio_buffer[-10:])  # Last 10 chunks
        if remaining_buffer:
            try:
                if recognizer.AcceptWaveform(remaining_buffer):
                    res = json.loads(recognizer.Result())
                    text = res.get("text", "").strip()
                    if text:
                        final_text += text + " "
                        logger.info(f"📝 Final buffer words: {text}")
            except Exception as e:
                logger.debug(f"Final buffer processing: {e}")
        
        # Get final result
        if recognizer:
            try:
                final_result = json.loads(recognizer.FinalResult())
                final_part = final_result.get("text", "")
                if final_part:
                    final_text += final_part + " "
                    logger.info(f"📝 Final words captured: {final_part}")
                    current_phase = f"📝 Final: '{final_part}'"
            except Exception as e:
                logger.debug(f"Final result processing: {e}")
        
        # Better partial result handling
        final_text = final_text.strip()
        if len(final_text.split()) < 3 and partial_results:
            # Use the longest partial as fallback, but do NOT append to final_text if final_text is already meaningful
            recent_partials = [p for p in partial_results[-5:] if len(p.split()) >= 2]
            if recent_partials:
                longest_partial = max(recent_partials, key=len)
                if len(longest_partial.split()) > len(final_text.split()):
                    logger.info(f"📝 Using partial result as final: '{longest_partial}'")
                    final_text = longest_partial
                    current_phase = f"📝 Used partial: '{longest_partial}'"
        
        # Save audio file
        audio_file = None
        if audio_buffer and len(audio_buffer) > 3:  # More lenient
            try:
                current_phase = "💾 Saving audio..."
                
                # Limit audio buffer size to prevent memory issues
                max_buffer_chunks = 1000  # Limit to ~6 seconds of audio
                if len(audio_buffer) > max_buffer_chunks:
                    logger.info(f"📦 Truncating audio buffer from {len(audio_buffer)} to {max_buffer_chunks} chunks")
                    audio_buffer = audio_buffer[-max_buffer_chunks:]
                
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_audio:
                    wf = wave.open(temp_audio.name, 'wb')
                    wf.setnchannels(1)
                    wf.setsampwidth(2)
                    wf.setframerate(16000)
                    
                    # Join audio buffer with error handling
                    try:
                        audio_data = b''.join(audio_buffer)
                        wf.writeframes(audio_data)
                        wf.close()
                        audio_file = temp_audio.name
                        logger.info(f"💾 Audio saved: {os.path.getsize(audio_file)} bytes")
                    except MemoryError:
                        logger.error("❌ Memory error joining audio buffer - using last 100 chunks")
                        audio_data = b''.join(audio_buffer[-100:]) # Fallback: use only last 100 chunks
                        wf.writeframes(audio_data)
                        wf.close()
                        audio_file = temp_audio.name
                        logger.info(f"💾 Audio saved (fallback): {os.path.getsize(audio_file)} bytes")
                    except Exception as join_error:
                        logger.error(f"❌ Audio buffer join error: {join_error}")
                        wf.close()
                        raise
                        
            except Exception as e:
                logger.error(f"❌ Error saving audio file: {e}")
                current_phase = "⚠️ Audio save failed"
                audio_file = None
        
        final_text = final_text.strip()
        
        # Update UI with final result
        if final_text:
            current_phase = f"✅ Heard: '{final_text[:50]}...'"
            logger.info(f"✅ STT completed: '{final_text}'")
        else:
            current_phase = "❌ No speech detected"
            logger.info("❌ STT completed with no speech detected")
        
        # Log the return value
        result = (final_text, audio_file)
        logger.info(f"🔍 STT function returning: {result}")
        
        return result
    except Exception as e:
        logger.error(f"❌ STT error: {e}")
        current_phase = f"❌ STT Error: {str(e)[:30]}..."
        return "", None
    finally:
        try:
            if stream is not None:
                stream.stop_stream()
                stream.close()
                stream = None
            if p is not None:
                p.terminate()
                p = None
            logger.info("🧹 Audio stream cleaned up")
        except Exception as cleanup_error:
            logger.error(f"❌ Cleanup error: {cleanup_error}")

# ========== ULTRA-FAST Tone Analysis ==========
def analyze_tone_from_audio(audio_path):
    global current_phase
    start_time = time.perf_counter()
    logger.info("⏱️ [START] Tone analysis started")
    try:
        logger.info("🎵 Starting tone analysis...")
        if not audio_path or not os.path.exists(audio_path):
            logger.warning(f"⚠️ No audio file for tone analysis: {audio_path}")
            return ("neutral", "neutral (no audio)")
        # Defensive: Check file size
        try:
            file_size = os.path.getsize(audio_path)
            logger.info(f"🎵 Tone analysis: file {audio_path}, size {file_size} bytes")
            if file_size > 10 * 1024 * 1024:  # 10MB
                logger.warning(f"⚠️ Audio file too large for analysis: {file_size} bytes")
                return ("neutral", "neutral (file too large)")
        except Exception as e:
            logger.error(f"❌ Error checking audio file size: {e}")
            return ("neutral", "neutral (file error)")
        import wave
        import numpy as np
        # Direct file read with timeout - no threads
        audio_data = None
        framerate = 16000
        try:
            # Use a direct file read with timeout
            with wave.open(audio_path, 'rb') as wf:
                frames = wf.readframes(-1)
                audio_data = np.frombuffer(frames, dtype=np.int16)
                framerate = wf.getframerate()
                logger.info(f"🎵 Audio file read successfully: {len(audio_data)} samples, {framerate}Hz")
        except Exception as e:
            logger.error(f"❌ Audio file read error: {e}")
            return ("neutral", "neutral (audio read error)")
        if audio_data is None or len(audio_data) == 0:
            logger.warning(f"⚠️ Empty audio data in {audio_path}")
            return ("neutral", "neutral (empty audio)")
        try:
            duration = len(audio_data) / framerate
            rms_energy = np.sqrt(np.mean(audio_data ** 2))
            peak_amplitude = np.max(np.abs(audio_data))
            zero_crossings = np.sum(np.diff(np.signbit(audio_data)))
            fft = np.fft.fft(audio_data)
            freqs = np.fft.fftfreq(len(fft), 1/framerate)
            magnitude = np.abs(fft)
            dominant_freq_idx = np.argmax(magnitude[:len(magnitude)//2])
            dominant_freq = abs(freqs[dominant_freq_idx])
            logger.info(f"[TONE DEBUG] rms_energy={rms_energy:.2f}, peak_amplitude={peak_amplitude}, zero_crossings={zero_crossings}, dominant_freq={dominant_freq:.2f}")
        except Exception as e:
            logger.error(f"❌ Audio analysis error: {e}")
            return ("neutral", "neutral (analysis error)")
        # --- Improved tone classification ---
        if duration < 0.5:
            tone = "brief"
        elif rms_energy > 200 or peak_amplitude > 33000:
            tone = "shouting"
        elif rms_energy > 100:
            tone = "excited"
        elif rms_energy > 70:
            tone = "energetic"
        elif rms_energy > 50:
            tone = "engaged"
        elif rms_energy > 30:
            tone = "calm"
        elif rms_energy > 20:
            tone = "soft"
        else:
            tone = "neutral"
        details = f"{tone} (duration: {duration:.1f}s, energy: {rms_energy:.0f}, peak: {peak_amplitude}, freq: {dominant_freq:.0f}Hz)"
        logger.info(f"🎵 Tone analysis: {details}")
        logger.info(f"⏱️ [END] Tone analysis completed in {time.perf_counter() - start_time:.3f}s")
        return (tone, details)
    except Exception as e:
        logger.warning(f"⚠️ Tone analysis failed: {e}")
        return ("neutral", f"neutral (exception: {e})")
    finally:
        pass

# ========== Text Sentiment Analysis ==========
def analyze_text_sentiment(text):
    global current_phase
    start_time = time.perf_counter()
    logger.info("⏱️ [START] Sentiment analysis started")
    try:
        # Avoid race condition with current_phase - use local variable for debugging
        logger.info("📊 Starting text sentiment analysis...")
        
        if not text or len(text.strip()) < 2:
            logger.info("⚠️ No text provided for sentiment analysis")
            return "neutral"
        
        positive_words = [
            "happy", "good", "great", "awesome", "love", "like", "yes", "amazing", 
            "wonderful", "fantastic", "excellent", "perfect", "brilliant", "cool",
            "nice", "beautiful", "thanks", "thank", "pleased", "excited"
        ]
        negative_words = [
            "sad", "bad", "hate", "no", "terrible", "awful", "angry", "frustrated",
            "disappointed", "upset", "annoyed", "horrible", "disgusting", "stupid",
            "wrong", "problem", "issue", "fail", "broken", "worst"
        ]
        neutral_words = [
            "okay", "ok", "fine", "maybe", "perhaps", "possibly", "probably",
            "could", "might", "should", "would", "think", "believe"
        ]
        
        text_lower = text.lower()
        words = text_lower.split()
        
        pos_count = sum(1 for word in words if word in positive_words)
        neg_count = sum(1 for word in words if word in negative_words)
        neu_count = sum(1 for word in words if word in neutral_words)
        
        # Nuanced sentiment analysis
        if pos_count > neg_count and pos_count > 0:
            sentiment = "happy"
        elif neg_count > pos_count and neg_count > 0:
            sentiment = "sad"
        elif neu_count > 0:
            sentiment = "thoughtful"
        else:
            sentiment = "neutral"
        
        logger.info(f"📊 Text sentiment: {sentiment} (pos:{pos_count}, neg:{neg_count}, neu:{neu_count})")
        logger.info(f"⏱️ [END] Sentiment analysis completed in {time.perf_counter() - start_time:.3f}s")
        return sentiment  
    except Exception as e:
        logger.error(f"❌ Text sentiment error: {e}")
        return "neutral"

# ========== Facial Emotion Capture ==========
def capture_facial_emotion(return_confidence=False):
    global current_phase
    if emotion_detector is None:
        logger.warning("⚠️ Emotion detector not available")
        current_phase = "⚠️ No emotion detector"
        return ("unknown", 0.0) if return_confidence else "unknown"
    current_phase = "😊 Capturing emotion..."
    with frame_lock:
        if current_frame is None:
            current_phase = "⚠️ No camera frame"
            return ("unknown", 0.0) if return_confidence else "unknown"
        frame_for_analysis = current_frame.copy()
    try:
        small_frame = cv2.resize(frame_for_analysis, (240, 180))
        faces = emotion_detector.detect_emotions(small_frame)
        if faces:
            faces_sorted = sorted(faces, key=lambda f: f['box'][2] * f['box'][3], reverse=True)
            dominant_face = faces_sorted[0]
            emotion_scores = dominant_face["emotions"]
            dominant_emotion = max(emotion_scores, key=emotion_scores.get)
            confidence = emotion_scores[dominant_emotion]
            current_phase = f"😊 Face: {dominant_emotion} ({confidence:.2f})"
            logger.info(f"😊 Facial emotion: {dominant_emotion} (confidence: {confidence:.2f})")
            if confidence >= 0.5:
                return (dominant_emotion, confidence) if return_confidence else dominant_emotion
            else:
                logger.info("🤷 Emotion confidence <0.5 — ignoring")
                return ("uncertain", confidence) if return_confidence else "uncertain"
        else:
            current_phase = "👤 No face detected"
            logger.debug("👤 No face detected")
            return ("no_face", 0.0) if return_confidence else "no_face"
    except Exception as e:
        logger.error(f"❌ Facial emotion capture error: {e}")
        current_phase = "❌ Face detection failed"
        return ("unknown", 0.0) if return_confidence else "unknown"

def update_camera_overlay():
    """Function to ensure camera overlay shows current phase"""
    global current_phase, phase_start_time
    
    if current_phase and phase_start_time:
        elapsed = time.time() - phase_start_time
        logger.debug(f"📱 UI Phase: {current_phase} (elapsed: {elapsed:.1f}s)")
    
    return current_phase

# ========== ULTRA-FAST LOCAL TTS CONFIGURATION ==========
class LocalFastTTS:
    DEFAULT_VOICES = {
        "female": "en-us+f3",
        "male": "en-us+m3"
    }
    DEFAULT_RATE = 200
    MIN_RATE = 80
    MAX_RATE = 200
    RATE_MULTIPLIER = 0.85
    DEFAULT_VOLUME = "100"  # eSpeak amplitude (0-200)
    DEFAULT_PITCH = "5"     # eSpeak pitch (0-99)

    def __init__(self):
        self.espeak_available = self._check_espeak()
        if self.espeak_available:
            logger.info("✅ eSpeak-ng detected - Ultra-fast local TTS ready")
        else:
            logger.warning("⚠️ eSpeak-ng not found - install with: sudo apt-get install espeak-ng")
    
    def _check_espeak(self) -> bool:
        """Check if eSpeak-ng is available on the system.
        
        Returns:
            bool: True if eSpeak-ng is available and functional
        """
        try:
            subprocess.run(["espeak-ng", "--version"], 
                         capture_output=True, 
                         check=True, 
                         timeout=2)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as e:
            logger.debug(f"eSpeak-ng check failed: {str(e)}")
            return False
    
    def speak_instant(self, text: str, gender: str = "female", rate: int = DEFAULT_RATE) -> bool:
        """Instant local TTS with eSpeak-ng.
        
        Args:
            text: Text to speak
            gender: Voice gender ('female' or 'male')
            rate: Speech rate (words per minute)
            
        Returns:
            bool: True if speech was initiated successfully
        """
        if not self.espeak_available:
            logger.warning("eSpeak-ng not available - speech request ignored")
            return False
            
        try:
            # Voice selection (completely local)
            voice = self.DEFAULT_VOICES.get(gender.lower(), self.DEFAULT_VOICES["female"])
            
            # Speed conversion with bounds checking
            espeak_speed = min(max(int(rate * self.RATE_MULTIPLIER), self.MAX_RATE), self.MIN_RATE)
            cmd = [
                "espeak-ng",
                "-v", voice,           # Voice selection
                "-s", str(espeak_speed),  # Speed in words per minute
                "-a", self.DEFAULT_VOLUME, # Amplitude (0-200)
                "-g", self.DEFAULT_PITCH, # Pitch (0-99)
                "-p", "60", # Pitch (0-99)
                "--punct=all",  # Keep all punctuation for better flow
                "--stdout",            # Output to stdout
                text
            ]
            
            # Execute instantly (non-blocking)
            subprocess.Popen(
                cmd, 
                stdout=subprocess.DEVNULL, 
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
            return True
            
        except Exception as e:
            logger.error(f"❌ eSpeak error: {e}", exc_info=True)
            return False

# Initialize TTS systems
try:
    local_tts = LocalFastTTS()
    logger.info("✅ Local TTS system initialized")
except Exception as e:
    logger.warning(f"⚠️ Local TTS initialization failed: {e}", exc_info=True)
    local_tts = None

# Initialize fallback engine with timeout

def timeout_handler(signum, frame):
    raise Exception("TTS initialization timeout")

try:
    tts_engine = pyttsx3.init()
    tts_engine.setProperty('rate', LocalFastTTS.DEFAULT_RATE)
    tts_engine.setProperty('volume', 1.0)  # Maximum volume for clarity
    if (voices := tts_engine.getProperty('voices')):
        tts_engine.setProperty('voice', voices[0].id)
    logger.info("✅ Fallback TTS engine initialized")
except Exception as e:
    logger.warning(f"⚠️ Fallback TTS engine failed: {e}")
    tts_engine = None

# ========== ULTRA-FAST LLM Integration ==========
def build_emotional_context(facial_emotion, tone_emotion, text_sentiment):
    """Structured emotional context for LLM processing"""
    return {
        "facial_emotion": facial_emotion,
        "tone_emotion": tone_emotion,
        "text_sentiment": text_sentiment,
        "emotion_congruence": analyze_emotion_congruence(facial_emotion, tone_emotion, text_sentiment),
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

def analyze_emotion_congruence(facial, tone, sentiment):
    """Detecting if facial, tone, and text emotions align or conflict"""
    # Case 1: Clear contradiction (e.g., smiling but angry tone)
    if (facial == "happy" and tone in ["angry", "sad"]) or \
       (tone == "excited" and sentiment == "negative"):
        return "contradiction"
    
    # Case 2: Perfect alignment (all signals match)
    elif (facial == tone == sentiment):
        return "aligned"
    
    # Case 3: Mixed signals (some match, some don't)
    else:
        return "mixed"

# ========== Emotion Detection Thread ==========
def run_emotion_detection():
    global latest_emotion_result, running
    
    logger.info("😊 Starting continuous emotion detection...")
    
    while running:
        try:
            # Allow it to run during listening and tone analysis phases
            if (processing_active.is_set() and not listening_active.is_set()) or avatar_talking.is_set():
                time.sleep(0.1)
                continue

            # Only run emotion detection when camera is active and system is idle
            if not camera_active.is_set():
                time.sleep(0.5)
                continue

            # Capture emotion only when system is truly idle (not during interactions)
            if camera_active.is_set() and detection_active.is_set():
                try:
                    emotion_result = capture_facial_emotion()
                    if emotion_result:
                        latest_emotion_result = emotion_result
                except Exception as e:
                    logger.error(f"❌ Emotion detection error: {e}")
                    
            time.sleep(0.1)  # Reduced polling frequency

        except Exception as e:
            logger.error(f"❌ Emotion detection loop error: {e}")
            time.sleep(1)
    
    logger.info("🛑 Emotion detection loop stopped")

# ========== Privacy and Security Functions ==========
def scrub_sensitive_info(text):
    """Enhanced privacy scrubbing to match emotion_detector standards"""
    if not text:
        return text
        
    # Email addresses
    text = re.sub(r'\S+@\S+\.\S+', '[REDACTED_EMAIL]', text)
    
    # Gender
    text = re.sub(r'\b(i am|my gender is|i identify as)\s+(male|female|man|woman|nonbinary|non-binary|trans|cis)\b', 
                  '[REDACTED_GENDER]', text, flags=re.IGNORECASE)
    
    # Age phrases
    text = re.sub(r'\b(i am)\s+\d{1,3}\s+(years old|yo)\b', '[REDACTED_AGE]', text, flags=re.IGNORECASE)
    text = re.sub(r'\b(i am)\s+aged?\s*\d{1,3}\b', '[REDACTED_AGE]', text, flags=re.IGNORECASE)

    # Phone numbers (various formats)
    text = re.sub(r'\+?\d[\d\s\-\(\)]{7,}', '[REDACTED_PHONE]', text)
    
    # Names (basic patterns)
    text = re.sub(r'\bmy name is\s+\w+\b', 'my name is [REDACTED_NAME]', text, flags=re.IGNORECASE)
    text = re.sub(r'\bi am\s+\w+\b', 'i am [REDACTED_NAME]', text, flags=re.IGNORECASE)
    
    # Social Security Numbers
    text = re.sub(r'\b\d{3}-\d{2}-\d{4}\b', '[REDACTED_SSN]', text)
    
    # Credit card numbers (basic)
    text = re.sub(r'\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b', '[REDACTED_CARD]', text)
    
    # National ID (Germany or others)
    text = re.sub(r'\bID\s*[:\-]?\s*\d{6,12}\b', '[REDACTED_ID]', text, flags=re.IGNORECASE)

    # Addresses (basic)
    text = re.sub(r'\b\d+\s+[A-Za-z\s]+(street|st|avenue|ave|road|rd|drive|dr|boulevard|blvd)\b', 
                  '[REDACTED_ADDRESS]', text, flags=re.IGNORECASE)
    
    # GPS coordinates (optional)
    text = re.sub(r'\b\d{1,3}\.\d{4,},\s*-?\d{1,3}\.\d{4,}\b', '[REDACTED_GPS]', text)
    
    return text

def log_system_state():
    """Logs the current state of all critical flags"""
    states = {
        'camera_active': camera_active.is_set(),
        'detection_active': detection_active.is_set(),
        'interaction_active': interaction_active.is_set(),
        'listening_active': listening_active.is_set(),
        'processing_active': processing_active.is_set(),
        'avatar_talking': avatar_talking.is_set(),
        'stt_processing_active': stt_processing_active.is_set()
    }
    logger.info("🔧 SYSTEM STATE: " + " | ".join(f"{k}:{'✅' if v else '❌'}" for k,v in states.items()))

def log_phase_transition(from_phase, to_phase):
    """Logs phase changes with timestamps"""
    logger.info(f"🔄 PHASE CHANGE: {from_phase} → {to_phase} ({(time.time()-phase_start_time):.2f}s)")

# ========== ULTRA-OPTIMIZED Main Interaction ==========
def talk_to_avatar(speak=True, voice_gender="female", privacy_mode=True, use_emotion_context=True):
    from emotion_detector import reset_performance_metrics
    reset_performance_metrics()  # Reset metrics at the start of the interaction
    stt_time = 0.0
    tone_time = 0.0
    llm_time = 0.0
    tts_time = 0.0
    try:
        logger.info("\n" + "="*80)
        logger.info("🚀 STARTING NEW INTERACTION (talk_to_avatar called)")
        log_system_state()
        global latest_emotion_result, current_phase, phase_start_time, current_dominant_emotion
        # Reset current dominant emotion at the start of new interaction
        current_dominant_emotion = "neutral"
        interaction_active.set()
        logger.info("🚀 Starting real-time interaction - emotions reset to neutral")
        
        cleanup_temp_audio_files() 
        
        # Initialize variables
        stt_text = ""
        original_text = ""
        audio_file = None
        dominant_emotion = "neutral"
        emotion_confidence = 0.0
        all_emotions = []
        tone_emotion = "neutral"
        text_sentiment = "neutral"
        llm_response = ""

        try:
            # ========== SYSTEM INITIALIZATION ==========
            current_phase = "🔧 Initializing systems..."
            logger.info("🔧 Initializing systems...")

            if not camera_active.is_set() and not start_camera():
                raise Exception("Camera initialization failed")
            if not detection_active.is_set():
                start_detection()
                while not running:  # Wait for detection thread
                    time.sleep(0.1)

            # ========== PHASE 1: LISTENING + CONTINUOUS EMOTION CAPTURE ==========
            log_phase_transition(current_phase, "listening")
            current_phase = "🎤 Listening - Speak now..."
            phase_start_time = time.time()
            listening_active.set()  # Activate listening mode
            interaction_start_time = time.perf_counter()
            logger.info("\n" + "="*80)
            logger.info(f"⏱️ [INTERACTION START] Timestamp: {datetime.now(timezone.utc).isoformat()}")
            log_system_state()
            
            # Define the set of valid emotions for filtering
            VALID_EMOTIONS = {"happy", "sad", "angry", "surprise", "fear", "disgust", "neutral"}
            
            def capture_continuous_emotions():
                """Capture emotions throughout the entire Phase 1"""
                global latest_emotion_samples, latest_emotion_samples_raw
                emotions_captured_raw = []  # All valid samples
                emotions_captured = []      # Only those with confidence >= 0.5
                confidences_raw = []        # Track all confidences
                emotion_confidences_raw = [] # Track (emotion, confidence)
                emotion_start_time = time.perf_counter()
                logger.info("😊 Starting continuous emotion detection during listening + STT...")
                try:
                    while (listening_active.is_set() or stt_processing_active.is_set()):
                        try:
                            emotion, confidence = capture_facial_emotion(return_confidence=True)
                            # Only consider valid emotions
                            if emotion in VALID_EMOTIONS:
                                emotions_captured_raw.append(emotion)
                                confidences_raw.append(confidence)
                                emotion_confidences_raw.append((emotion, confidence))
                                if confidence >= 0.5:
                                    emotions_captured.append(emotion)
                                    logger.debug(f"😊 Emotion captured: {emotion} (confidence: {confidence:.2f})")
                                else:
                                    logger.debug(f"🤷 Emotion confidence <0.5 — ignoring ({emotion}, {confidence:.2f})")
                            # Safety timeout
                            if time.perf_counter() - emotion_start_time > 25:
                                logger.warning("⚠️ Emotion capture timeout")
                                break
                            time.sleep(0.05)  # Capture emotions at 50ms intervals
                        except Exception as e:
                            logger.error(f"❌ Individual emotion capture error: {e}")
                            time.sleep(0.1)
                except Exception as e:
                    logger.error(f"❌ Emotion capture loop error: {e}")
                # Save all captured emotions globally for frontend access
                latest_emotion_samples = list(emotions_captured)
                latest_emotion_samples_raw = list(emotions_captured_raw)
                # Find dominant emotion
                if emotions_captured_raw and emotion_confidences_raw:
                    try:
                        # Use all (emotion, confidence) pairs for high-confidence samples
                        emotion_confidences = [(e, c) for (e, c) in emotion_confidences_raw if c >= 0.5]
                        emotion_counts = Counter([e for (e, c) in emotion_confidences])
                        dominant_emotion = emotion_counts.most_common(1)[0][0]
                        # Get all confidence values for the dominant emotion
                        dominant_confidences = [c for (e, c) in emotion_confidences if e == dominant_emotion]
                        if dominant_confidences:
                            confidence = sum(dominant_confidences) / len(dominant_confidences)
                        else:
                            confidence = 0.0
                        logger.info(f"😊 Dominant emotion: {dominant_emotion} (avg confidence: {confidence:.2f}, values: {dominant_confidences})")
                        return dominant_emotion, confidence, emotions_captured, emotions_captured_raw
                    except Exception as e:
                        logger.error(f"❌ Emotion processing error: {e}")
                        return "neutral", 0.0, emotions_captured, emotions_captured_raw
                elif emotions_captured_raw and confidences_raw:
                    # No valid samples, but we have raw data: show the most frequent emotion and its highest confidence
                    try:
                        emotion_counts = Counter(emotions_captured_raw)
                        dominant_emotion = emotion_counts.most_common(1)[0][0]
                        # Find the highest confidence for the dominant emotion
                        max_conf = max([c for (e, c) in emotion_confidences_raw if e == dominant_emotion], default=0.0)
                        logger.info(f"😶 No valid samples, fallback to dominant: {dominant_emotion} (max confidence: {max_conf:.2f})")
                        return dominant_emotion, max_conf, [], emotions_captured_raw
                    except Exception as e:
                        logger.error(f"❌ Fallback emotion processing error: {e}")
                        return "neutral", 0.0, [], emotions_captured_raw
                else:
                    logger.warning("⚠️ No emotions captured")
                    return "neutral", 0.0, [], emotions_captured_raw

            def perform_speech_capture():
                """Perform speech-to-text with immediate silence detection"""
                global current_phase, phase_start_time, stt_time
                try:
                    current_phase = "🎤 Listening for speech..."
                    phase_start_time = time.time()
                    stt_start_time = time.perf_counter()
                    # Call STT function that stops immediately on silence
                    logger.info("🎤 Starting STT with improved word capture")
                    result = perform_speech_to_text_vosk()
                    stt_time_local = time.perf_counter() - stt_start_time  # Calculate STT duration
                    logger.info(f"⏱️ [RAW TIME] STT processing took: {stt_time_local:.3f}s")
                    # Ensure we always return a valid result
                    if result and isinstance(result, tuple) and len(result) >= 2:
                        global audio_file
                        stt_text, audio_file = result
                        original_text = stt_text  # Store original for debugging
                        if privacy_mode:
                            stt_text = scrub_sensitive_info(stt_text)
                            logger.info(f"🔒 Privacy scrubbing applied:\nOriginal: {original_text}\nScrubbed: {stt_text}")
                        if stt_text:
                            stt_text = remove_repeated_phrases(stt_text)
                            current_phase = f"✅ Heard: '{stt_text[:50]}...'"
                            logger.info(f"✅ STT completed: '{stt_text}'")
                        else:
                            current_phase = "❌ No speech detected"
                            logger.info("❌ STT completed with no speech detected")
                        return result, stt_time_local
                    else:
                        logger.warning("⚠️ STT returned invalid result, using defaults")
                        current_phase = "❌ STT failed"
                        return ("", None), stt_time_local
                except Exception as e:
                    current_phase = f"❌ STT Error: {str(e)[:20]}..."
                    logger.error(f"❌ STT error: {e}")
                    return ("", None), 0.0

            # Start emotion capture before STT begins
            emotion_future = None
            with ThreadPoolExecutor(max_workers=2) as executor:
                # Start emotion capture first
                emotion_future = executor.submit(capture_continuous_emotions)
                
                # Then start STT with enhanced logging
                logger.info("🎤 Starting STT capture process...")
                stt_future = executor.submit(perform_speech_capture)
                
                # Wait for STT to complete first (this determines when Phase 1 ends)
                try:
                    logger.info("⏳ Waiting for STT result (timeout: 20s)...")
                    stt_result_tuple = stt_future.result(timeout=20)
                    if isinstance(stt_result_tuple, tuple) and len(stt_result_tuple) == 2:
                        stt_result, stt_time_local = stt_result_tuple
                        stt_time = stt_time_local
                    else:
                        stt_result = ("", None)
                        stt_time = 0.0
                    logger.info(f"📦 Raw STT result received: {str(stt_result)[:200]}...")
                    if isinstance(stt_result, tuple) and len(stt_result) >= 2:
                        stt_text, audio_file = stt_result
                        logger.info(f"✅ STT successful - Text: '{stt_text[:50]}...' | Audio: {'exists' if audio_file else 'None'}")
                        # Additional verification if audio file exists
                        if audio_file:
                            try:
                                audio_size = os.path.getsize(audio_file) if os.path.exists(audio_file) else 0
                                logger.info(f"🔊 Audio file verification - Size: {audio_size} bytes | Path: {audio_file}")
                                try:
                                    with wave.open(audio_file, 'rb') as wf:
                                        frames = wf.getnframes()
                                        rate = wf.getframerate()
                                        duration = frames / float(rate)
                                        logger.info(f"🔊 Audio file valid - Duration: {duration:.2f}s | Sample rate: {rate}Hz")
                                except Exception as audio_check_error:
                                    logger.error(f"❌ Audio file validation failed: {audio_check_error}")
                            except Exception as file_error:
                                logger.error(f"❌ Audio file inspection error: {file_error}")
                    else:
                        stt_text, audio_file = "", None
                        logger.warning("⚠️ STT returned invalid result format")
                    current_phase = "✅ Speech processing complete"
                    logger.info("✅ STT processing completed successfully")
                    # --- Update metrics after STT phase ---
                    update_all_performance_metrics(
                        stt_time=stt_time,
                        tone_time=tone_time,
                        llm_time=llm_time,
                        tts_time=tts_time
                    )
                except TimeoutError:
                    logger.error("⏰ STT timed out after 45 seconds")
                    current_phase = "❌ STT timed out"
                    stt_text, audio_file = "", None
                    stt_time = 0.0
                    if stt_future:
                        logger.info(f"🔍 STT Future state - Done: {stt_future.done()}, Running: {stt_future.running()}, Cancelled: {stt_future.cancelled()}")
                        try:
                            if stt_future and not stt_future.done():
                                stt_future.cancel() # Cancel the STT future if it's still running
                                logger.info("🚫 STT future cancelled due to timeout")
                            logger.info("🧹 Forced cleanup of STT resources after timeout")
                        except Exception as cleanup_error:
                            logger.error(f"❌ Forced cleanup error: {cleanup_error}")
                except Exception as e:
                    logger.error(f"❌ STT processing failed with exception: {str(e)}", exc_info=True)
                    logger.error(f"🧾 Exception type: {type(e).__name__}")
                    logger.error(f"🔍 Exception args: {e.args}")
                    if "input overflowed" in str(e):
                        logger.error("🔊 Potential audio buffer overflow detected")
                    elif "Error opening stream" in str(e):
                        logger.error("🔌 Audio stream opening failure - possible device contention")
                    elif "Invalid number of channels" in str(e):
                        logger.error("🎚️ Audio channel configuration error")
                    current_phase = f"❌ STT failed: {str(e)[:20]}..."
                    stt_text, audio_file = "", None
                    stt_time = 0.0
                finally:
                    logger.info("🧹 Cleaning up STT resources...") # Enhanced cleanup logging
                    
                    # Clear listening flags immediately after STT completes
                    listening_active.clear()
                    stt_processing_active.clear()
                    logger.info("🚩 Listening flags cleared")
                    
                    # Log thread states
                    logger.info(f"📊 Thread status - STT: {'alive' if stt_future.running() else 'done'} | Emotion: {'alive' if emotion_future.running() else 'done'}")
                    
                    log_system_state() # Additional system state logging
                
                # Get emotion results (continued capturing during STT processing)
                try:
                    current_phase = "😊 Processing emotions..."
                    emotion_result = emotion_future.result(timeout=5) if emotion_future else ("neutral", 0.0, [], [])
                    # Fix: Unpack all four values
                    if isinstance(emotion_result, tuple) and len(emotion_result) == 4:
                        dominant_emotion, emotion_confidence, all_emotions, all_emotions_raw = emotion_result
                    elif isinstance(emotion_result, tuple) and len(emotion_result) == 3:
                        dominant_emotion, emotion_confidence, all_emotions = emotion_result
                        all_emotions_raw = []
                    else:
                        dominant_emotion, emotion_confidence, all_emotions, all_emotions_raw = "neutral", 0.0, [], []
                    # Update global dominant emotion immediately for frontend access
                    current_dominant_emotion = dominant_emotion
                    current_phase = f"😊 Emotion: {dominant_emotion}"
                    logger.info(f"✅ Emotion capture completed: {dominant_emotion}")
                except Exception as e:
                    logger.warning(f"⚠️ Emotion capture timeout: {e}")
                    current_phase = "⚠️ Emotion processing failed"
                    dominant_emotion, emotion_confidence, all_emotions, all_emotions_raw = "neutral", 0.0, [], []
                    # Update global dominant emotion even in error case
                    current_dominant_emotion = "neutral"
            # Better validation for speech input
            speech_words = stt_text.strip().split() if stt_text else []
            if not stt_text or len(speech_words) < 1:
                logger.warning(f"⚠️ Insufficient speech input: '{stt_text}' ({len(speech_words)} words)")
                current_phase = "🤐 I didn't hear what you said. Please speak more clearly."
                phase_start_time = time.time()
                time.sleep(2)
                
                # Reset to ready state
                current_phase = "Ready - Talk to Avatar"
                phase_start_time = time.time()
                processing_active.clear()
                interaction_active.clear()
                
                result = serialize_for_json({
                    "status": "insufficient_speech",
                    "message": "I didn't hear what you said. Please speak more clearly.",
                    "speech_captured": stt_text,
                    "words_detected": len(speech_words),
                    "dominant_emotion": dominant_emotion,
                    "emotion_confidence": float(emotion_confidence),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "privacy_mode": privacy_mode,  # Track privacy mode in results
                    "original_text": original_text if privacy_mode else None  # For debugging
                })
                logger.info(f"🔄 Returning insufficient speech result: {result}")
                update_all_performance_metrics(
                    stt_time=stt_time,
                    tone_time=tone_time,
                    llm_time=llm_time,
                    tts_time=tts_time
                )
                return result

            # ========== PHASE 2: PARALLEL TONE/SENTIMENT ANALYSIS ==========
            tone_analysis_allowed.set()
            tone_emotion = "neutral"
            text_sentiment = "neutral"

            def process_tone_analysis():
                logger.info("[PHASE2] process_tone_analysis: starting")
                start_time = time.perf_counter()
                try:
                    if audio_file:
                        logger.info(f"[PHASE2] process_tone_analysis: calling analyze_tone_from_audio({audio_file})")
                        tone_result, tone_details = analyze_tone_from_audio(audio_file)
                        logger.info(f"[PHASE2] process_tone_analysis: result={tone_result}, details={tone_details}")
                        try:
                            elapsed = time.perf_counter() - start_time
                            logger.info(f"📍 DEBUG: About to update tone_time metric: {elapsed}")
                            update_performance_metric("tone_time", elapsed if elapsed > 0 else 0.001)
                            logger.info(f"📍 DEBUG: Successfully updated tone_time metric")
                        except Exception as e:
                            logger.warning(f"⚠️ Performance metric update failed: {e}")
                        return tone_result, tone_details
                    logger.info("[PHASE2] process_tone_analysis: no audio_file, returning 'neutral'")
                    return "neutral", "neutral (no audio)"
                except Exception as e:
                    logger.error(f"❌ Tone analysis error: {e}")
                    return "neutral", f"neutral (exception: {e})"
            def process_text_sentiment():
                logger.info("[PHASE2] process_text_sentiment: starting")
                try:
                    if stt_text:
                        logger.info(f"[PHASE2] process_text_sentiment: calling analyze_text_sentiment({stt_text[:30]}...)")
                        result = analyze_text_sentiment(stt_text)
                        logger.info(f"[PHASE2] process_text_sentiment: result={result}")
                        return str(result)
                    logger.info("[PHASE2] process_text_sentiment: no stt_text, returning 'neutral'")
                    return "neutral"
                except Exception as e:
                    logger.error(f"❌ Text sentiment error: {e}")
                    return "neutral"
            current_phase = "⚡ PHASE 2: Analyzing tone & sentiment..."
            phase_start_time = time.time()
            processing_active.set()
            logger.info("🔧 SYSTEM STATE: Entering Phase 2 | "
                        f"listening_active:{'✅' if listening_active.is_set() else '❌'} | "
                        f"processing_active:{'✅' if processing_active.is_set() else '❌'}")
            logger.info("⚡ PHASE 2: PARALLEL ANALYSIS (Tone + Sentiment)")
            
            # ---  Tone Analysis  ---
            if not audio_file:
                logger.warning("[PHASE2] No audio file — skipping tone analysis, using 'neutral'")
                tone_emotion = "neutral"
                tone_time = 0.0
                tone_analysis_details = "neutral (no audio)"
            else:
                try:
                    logger.info("[PHASE2] Starting direct tone analysis (no threading)")
                    tone_start = time.perf_counter()
                    tone_emotion, tone_analysis_details = process_tone_analysis()
                    tone_time = time.perf_counter() - tone_start
                    logger.info(f"⏱️ [RAW TIME] Tone analysis took: {tone_time:.3f}s")
                    logger.info(f"[PHASE2] ✅ Direct tone analysis completed in {tone_time:.2f}s: {tone_emotion}")
                except Exception as e:
                    import traceback
                    logger.warning(f"⚠️ Tone analysis error: {e}")
                    logger.info(f"[PHASE2] Traceback:\n{traceback.format_exc()}")
                    tone_emotion = "neutral"
                    tone_time = 0.0
                    tone_analysis_details = f"neutral (exception: {e})"
                logger.info(f"[PHASE2] tone_emotion result: {tone_emotion}")
            # --- Update metrics after Tone phase ---
            update_all_performance_metrics(
                stt_time=stt_time,
                tone_time=tone_time,
                llm_time=llm_time,
                tts_time=tts_time
            )

            # --- Sentiment Analysis  ---
            try:
                logger.info("[PHASE2] Starting direct sentiment analysis (no threading)")
                sentiment_start = time.perf_counter()
                text_sentiment = process_text_sentiment()
                sentiment_time = time.perf_counter() - sentiment_start
                logger.info(f"⏱️ [RAW TIME] Sentiment analysis took: {sentiment_time:.3f}s")
                logger.info(f"[PHASE2] Direct sentiment analysis completed: {text_sentiment}")
            except Exception as e:
                import traceback
                logger.warning(f"⚠️ Sentiment analysis error: {e}")
                logger.info(f"[PHASE2] Exception in sentiment analysis: {e}")
                logger.info(f"[PHASE2] Traceback:\n{traceback.format_exc()}")
                text_sentiment = "neutral"
            logger.info(f"[PHASE2] Exiting sentiment analysis: Tone={tone_emotion}, Sentiment={text_sentiment}")
            # --- Update metrics after Sentiment phase ---
            update_all_performance_metrics(
                stt_time=stt_time,
                tone_time=tone_time,
                llm_time=llm_time,
                tts_time=tts_time
            )

            # Clean up audio file
            if audio_file and os.path.exists(audio_file):
                try:
                    logger.info(f"[PHASE2] Attempting to delete temp audio file: {audio_file}")
                    os.remove(audio_file)
                    logger.info(f"[PHASE2] Successfully deleted temp audio file: {audio_file}")
                except Exception as cleanup_error:
                    logger.error(f"[PHASE2] Error deleting temp audio file: {cleanup_error}")
            # Safety fallback
            if not tone_emotion:
                tone_emotion = "neutral"
            if not text_sentiment:
                text_sentiment = "neutral"
            # Final phase status
            current_phase = f"✅ Analysis done: {tone_emotion}, {text_sentiment}"
            logger.info(f"✅ PHASE 2 COMPLETE: Tone={tone_emotion}, Sentiment={text_sentiment}")
            
            logger.info("📍 DEBUG: About to clear tone_analysis_allowed flag...")
            try:
                tone_analysis_allowed.clear()
                logger.info("📍 DEBUG: Successfully cleared tone_analysis_allowed flag")
            except Exception as e:
                logger.error(f"📍 DEBUG: Error clearing tone_analysis_allowed flag: {e}")
            
            logger.info("🧠 Transitioning to PHASE 3: LLM Processing...")
            
            # ========== PHASE 3: LLM PROCESSING ==========
            current_phase = "🤖 PHASE 3: Thinking..."
            phase_start_time = time.time()
            llm_start_time = time.perf_counter()
            logger.info("🔧 SYSTEM STATE: Entering Phase 3 | "
                        f"processing_active:{'✅' if processing_active.is_set() else '❌'} | "
                        f"avatar_talking:{'✅' if avatar_talking.is_set() else '❌'}")
            try:
                # Call LLM function directly
                emotion_context = {
                    "facial_emotion": dominant_emotion,
                    "tone_emotion": tone_emotion,
                    "text_sentiment": text_sentiment,
                    "privacy_mode": privacy_mode
                }
                emotional_mode = emotion_context.get('emotional_tone', "neutral" if not emotion_context else "supportive")
                logger.info(f"🤖 [LLM QUERY] Preparing query with emotional mode: {emotional_mode}")
                # Call LLM directly 
                llm_response = query_ollama(stt_text, emotion_context if use_emotion_context else None, conversation_history=None, use_emotion_context=use_emotion_context)
                llm_time = time.perf_counter() - llm_start_time
                logger.info(f"⏱️ [RAW TIME] LLM processing took: {llm_time:.3f}s")
                if privacy_mode and "REDACTED" in stt_text:
                    llm_response = ("Note: Some personal information was removed for privacy. " + 
                                   llm_response)
                
                # Store the LLM response globally for immediate access
                global current_llm_response
                current_llm_response = llm_response
                logger.info(f"💾 Stored LLM response globally: {llm_response[:100]}...")
                tts_success = False  # Direct LLM call doesn't include TTS
                # --- Update metrics after LLM phase ---
                update_all_performance_metrics(
                    stt_time=stt_time,
                    tone_time=tone_time,
                    llm_time=llm_time,
                    tts_time=tts_time
                )
            except Exception as e:
                logger.error(f"❌ LLM processing error: {e}")
                # Provide a contextual response based on detected emotion
                if "timeout" in str(e).lower():
                    if dominant_emotion == "happy":
                        llm_response = "I can see you're feeling happy! That's wonderful!"
                    elif dominant_emotion == "sad":
                        llm_response = "I notice you seem a bit sad. I'm here if you want to talk."
                    elif dominant_emotion == "angry":
                        llm_response = "I can sense some frustration. Take a deep breath."
                    else:
                        llm_response = "I'm listening and understanding your emotions."
                else:
                    llm_response = "I apologize, but I encountered an error."
                tts_success = False
                llm_time = 0.0
            finally:
                llm_elapsed = time.perf_counter() - llm_start_time
                if llm_time == 0.0:
                    llm_time = llm_elapsed
                update_performance_metric("llm_time", llm_time if llm_time > 0 else llm_elapsed)
            
            # ========== PHASE 4: TEXT-TO-SPEECH ==========
            processing_active.clear()
            current_phase = "🗣️ PHASE 4: Speaking..."
            phase_start_time = time.time()
            logger.info("🗣️ PHASE 4: TEXT-TO-SPEECH")

            tts_success = False
            try:
                tts_start_time = time.perf_counter()
                if llm_response and speak:
                    if privacy_mode:
                        spoken_response = scrub_sensitive_info(llm_response)
                        if spoken_response != llm_response:
                            logger.info("🔒 Applied additional privacy scrubbing for TTS")
                    else:
                        spoken_response = llm_response

                    avatar_talking.set()
                    logger.info("🔧 SYSTEM STATE: Entering Phase 4 | "
                                f"avatar_talking:{'✅' if avatar_talking.is_set() else '❌'} | "
                                f"processing_active:{'✅' if processing_active.is_set() else '❌'}")
                    logger.info(f"Starting TTS for: {spoken_response[:100]}...")
                    tts_success = speak_text_advanced(spoken_response, voice_gender) # Use the advanced TTS function
                    tts_time = time.perf_counter() - tts_start_time
                    logger.info(f"⏱️ TTS: {tts_time:.3f}s")
                    
                    if tts_success:
                        total_interaction_time = time.perf_counter() - interaction_start_time
                        logger.info(f"⏱️ [TOTAL INTERACTION TIME] {total_interaction_time:.3f}s "
                                f"(STT: {stt_time:.3f}s | Tone: {tone_time:.3f}s | "
                                f"Sentiment: {sentiment_time:.3f}s | LLM: {llm_time:.3f}s | "
                                f"TTS: {tts_time:.3f}s)")
                        logger.info("✅ PHASE 4 COMPLETE: TTS SUCCESS")
                    else:
                        logger.error("❌ TTS failed")
                else:
                    logger.info("⚠️ No TTS - speak=False or no LLM response")
                    tts_success = True  # Consider it success if no TTS needed

                # --- Update metrics after TTS phase ---
                update_all_performance_metrics(
                    stt_time=stt_time,
                    tone_time=tone_time,
                    llm_time=llm_time,
                    tts_time=tts_time
                )
            except Exception as e:
                logger.error(f"❌ TTS error: {e}")
                tts_success = False
                tts_time = time.perf_counter() - tts_start_time
                total_interaction_time = time.perf_counter() - interaction_start_time
                logger.error(f"⏱️ [INTERACTION FAILED] Total time: {total_interaction_time:.3f}s - Error: {str(e)}")
                raise
            finally:
                avatar_talking.clear() # Clear avatar_talking flag after TTS completes
                logger.info("✅ FULL INTERACTION COMPLETE")
                reset_interaction_flags() # Final cleanup - ensure all flags are reset
                logger.info("✅ Interaction fully completed and system reset")
            
            # ========== FINAL RESULTS ==========
            current_phase = "✅ Interaction complete!"

            # Ensure all timing variables are set
            stt_time = stt_time if 'stt_time' in locals() and stt_time is not None else 0.0
            tone_time = tone_time if 'tone_time' in locals() and tone_time is not None else 0.0
            llm_time = llm_time if 'llm_time' in locals() and llm_time is not None else 0.0
            tts_time = tts_time if 'tts_time' in locals() and tts_time is not None else 0.0

            # Update timing data and increment interaction count
            update_all_performance_metrics(
                stt_time=stt_time,
                tone_time=tone_time,
                llm_time=llm_time,
                tts_time=tts_time
            )
            increment_interaction_count()

            # Comprehensive result
            result = {
                "status": "success",
                "speech_text": str(stt_text),
                "original_text": original_text if privacy_mode else None,
                "words_captured": int(len(speech_words)),
                "dominant_emotion": str(dominant_emotion),
                "facial_emotion": str(dominant_emotion),
                "emotion_confidence": float(emotion_confidence),
                "all_emotions_captured": list(all_emotions),
                "all_emotions_captured_raw": list(all_emotions_raw),
                "tone_emotion": str(tone_emotion),
                "text_sentiment": str(text_sentiment),
                "llm_response": str(llm_response),
                "tts_success": bool(tts_success),
                "emotional_context": {
                    "dominant": str(dominant_emotion),
                    "confidence": float(emotion_confidence),
                    "tone": str(tone_emotion),
                    "sentiment": str(text_sentiment)
                },
                "timing": get_current_timing_data(),
                "interaction_id": f"int_{int(time.time())}_{timing_data.get('interaction_count', 0)}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "pipeline_phases": {
                    "phase1_listening_emotion": "completed",
                    "phase2_parallel_analysis": "completed", 
                    "phase3_llm_processing": "completed",
                    "phase4_tts": "completed" if tts_success else "failed"
                },
                "privacy_mode": privacy_mode,
                "tone_analysis_details": str(tone_analysis_details),
            }
            # Log and set latest_emotion_result immediately
            logger.info(f"[DEBUG] Final result dict: {result}")
            global latest_emotion_result
            latest_emotion_result = dict(result)
            # Save and return results
            try:
                serialized_result = serialize_for_json(result)
                save_to_database(serialized_result)
                # --- Save to interactions_collection for conversation logs ---
                if interactions_collection is not None:
                    try:
                        interactions_collection.insert_one({
                            "timestamp": result["timestamp"],
                            "user_message": result.get("speech_text", ""),
                            "llm_reply": result.get("llm_response", ""),
                            "voice_gender": result.get("voice_gender", ""),
                            "tts_success": result.get("tts_success", False),
                            "timing": result.get("timing", {}),
                            "privacy_mode": result.get("privacy_mode", False),
                            "log_flags": result.get("log_flags", {}),
                            "emotion_congruence": result.get("emotional_context", {}),
                            "emotional_context": result.get("emotional_context", {}),
                            "interaction_id": result.get("interaction_id", "")
                        })
                    except Exception as e:
                        logger.error(f"❌ Failed to insert conversation log: {e}")
                # FINAL METRICS FLUSH: update metrics with final values before return
                update_all_performance_metrics(
                    stt_time=stt_time,
                    tone_time=tone_time,
                    llm_time=llm_time,
                    tts_time=tts_time
                )
                return serialized_result
            except Exception as e:
                logger.error(f"❌ Result processing error: {e}")
                update_all_performance_metrics(
                    stt_time=stt_time,
                    tone_time=tone_time,
                    llm_time=llm_time,
                    tts_time=tts_time
                )
                return {  # Always return a dict
                    "status": "success",
                    "speech_text": str(stt_text),
                    "llm_response": str(llm_response),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "privacy_mode": privacy_mode
                }

        except Exception as e:
            logger.error(f"❌ Pipeline error: {e}")
            current_phase = f"❌ System Error: {str(e)[:30]}..."
            error_result = {
                "status": "error",
                "error": str(e),
                "error_type": type(e).__name__,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "speech_text": str(stt_text) if 'stt_text' in locals() else '',
                "llm_response": str(llm_response) if 'llm_response' in locals() else '',
                "privacy_mode": privacy_mode
            }
            # FINAL METRICS FLUSH: update metrics with final values before return
            update_all_performance_metrics(
                stt_time=stt_time,
                tone_time=tone_time,
                llm_time=llm_time,
                tts_time=tts_time
            )
            return serialize_for_json(error_result)
        finally:
            # Do not update metrics here, just cleanup
            reset_interaction_flags()
            cleanup_temp_audio_files()

    except Exception as e:
        logger.error(f"❌ Pipeline error: {e}")
        current_phase = f"❌ System Error: {str(e)[:30]}..."
        error_result = {
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "speech_text": str(stt_text) if 'stt_text' in locals() else '',
            "llm_response": str(llm_response) if 'llm_response' in locals() else '',
            "privacy_mode": privacy_mode
        }
        # FINAL METRICS FLUSH: update metrics with final values before return
        update_all_performance_metrics(
            stt_time=stt_time,
            tone_time=tone_time,
            llm_time=llm_time,
            tts_time=tts_time
        )
        return serialize_for_json(error_result)
    finally:
        # Do not update metrics here, just cleanup
        reset_interaction_flags()
        cleanup_temp_audio_files()

def speak_text_advanced(text, gender="female", rate=130, volume=0.9):
    """Returns only success status (bool) - timing handled by caller"""
    if not text or not text.strip():
        return False
    
    start_time = time.perf_counter()
    success = False  # Initialize success flag
    
    try:
        # Method 1: Ultra-fast eSpeak-ng (LOCAL)
        if local_tts and local_tts.espeak_available:
            try:
                voice_map = {
                    "female": "en+f3",    
                    "male": "en+m3",      
                }
                voice = voice_map.get(gender.lower(), "en+f3")
                espeak_speed = min(max(int(rate * 1.0), 100), 400)
                
                cmd = [
                    "espeak-ng",
                    "-v", voice,           
                    "-s", str(espeak_speed), 
                    "-a", "150",           # Keep good volume
                    "-p", "60",            # Higher pitch for clearer voice   
                    "-g", "3",             # More word gap for clarity
                    "-k", "5",             # Emphasis for clarity
                    "--punct=all",         # Keep all punctuation
                    text
                ]
                
                # SYNCHRONOUS execution for accurate timing
                result = subprocess.run(
                    cmd, 
                    stdout=subprocess.DEVNULL, 
                    stderr=subprocess.DEVNULL,
                    timeout=30  # Prevent hanging
                )
                
                elapsed_time = time.perf_counter() - start_time
                success = result.returncode == 0
                logger.info(f"🚀 eSpeak TTS completed in {elapsed_time:.3f}s")
                return success
            
            except Exception as e:
                logger.error(f"❌ eSpeak error: {e}")
            
        # Method 2: Fallback to pyttsx3
        elif tts_engine:
            try:
                voices = tts_engine.getProperty('voices')
                if voices:
                    if gender.lower() == "male" and len(voices) > 1:
                        tts_engine.setProperty('voice', voices[1].id)
                    else:
                        tts_engine.setProperty('voice', voices[0].id)
                
                tts_engine.setProperty('rate', rate)
                tts_engine.setProperty('volume', 1.0)  # Maximum volume for clarity
                
                logger.info(f"🗣️ Fallback TTS starting...")
                tts_engine.say(text)
                tts_engine.runAndWait()  # This blocks until complete
                
                elapsed_time = time.perf_counter() - start_time
                logger.info(f"🗣️ Fallback TTS completed in {elapsed_time:.3f}s")
                return True
                
            except Exception as e:
                logger.error(f"❌ Fallback TTS error: {e}")
                return False
        
    finally:
        pass
        
# ========== ULTRA-FAST Text-to-Speech ==========
def synthesize_response(text, voice_gender="female"):
    return speak_text_advanced(text, voice_gender)

def start_detection():
    """Start emotion detection system"""
    if not detection_active.is_set():
        detection_active.set()
        if not camera_active.is_set():
            if not start_camera():
                return {"status": "Failed to start camera", "success": False}
            time.sleep(1)
        
        global detection_thread
        detection_thread = threading.Thread(target=run_emotion_detection, daemon=True)
        detection_thread.start()
        
        logger.info("✅ Emotion detection started")
        return {"status": "Detection started", "success": True}
    else:
        return {"status": "Already running", "success": True}

def stop_detection():
    """Stop emotion detection system with thread-safe full cleanup"""
    logger.info("🛑 Stopping emotion detection subsystem...")
    
    try:
        reset_interaction_flags() # Full system reset first (thread-safe)
        
        # Special detection subsystem handling
        with threading.Lock():
            detection_active.clear()
            
            # Set final detection state
            latest_emotion_result = {
                "status": "Detection stopped",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "final_emotion": "stopped",
                "face_detected": False,
                "system_state": "inactive"
            }
            
            if camera_active.is_set():
                time.sleep(0.2)  # Small delay only if needed for hardware
        
        logger.info("✅ Detection subsystem fully stopped")
        return {
            "status": "success",
            "message": "Detection system stopped",
            "timestamp": latest_emotion_result["timestamp"]
        }
        
    except Exception as e:
        logger.error(f"❌ Error during detection stop: {str(e)}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

def get_current_llm_response():
    """Return the current LLM response if available"""
    global current_llm_response
    return {
        "status": "success" if current_llm_response else "no_response",
        "llm_response": current_llm_response,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

def get_current_dominant_emotion():
    """Return the current dominant emotion if available"""
    global current_dominant_emotion
    return {
        "status": "success" if current_dominant_emotion else "no_emotion",
        "dominant_emotion": current_dominant_emotion,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

def get_latest_emotion():
    """Return enhanced latest emotion data with updated timing and performance metrics"""
    global previous_timing_data
    global latest_emotion_result

    if not latest_emotion_result:
        return serialize_for_json({
            "status": "No data yet",
            "timing": get_current_timing_data(),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    current_timing = get_current_timing_data()
    if isinstance(latest_emotion_result, dict):
        result = dict(latest_emotion_result)
    else:
        result = {"status": "No data yet", "timing": current_timing, "timestamp": datetime.now(timezone.utc).isoformat()}

    # Determine if timing changed
    timing_changed = False
    for key in ["stt_time", "tone_time", "llm_time", "tts_time", "total_time", "interaction_count"]:
        if current_timing.get(key, 0) != previous_timing_data.get(key, 0):
            timing_changed = True
            break

    if timing_changed or previous_timing_data.get("interaction_count", 0) == 0:
        result["current_timing"] = current_timing
        result["performance_metrics"] = get_performance_metrics()
        previous_timing_data = current_timing.copy()

    return serialize_for_json(result)

def get_system_health():
    """Get comprehensive system health status"""
    try:
        health_data = {
            "camera_active": camera_active,
            "detection_active": detection_active,
            "mongodb_connected": emotions_collection is not None,
            "database_status": "connected" if emotions_collection is not None else "disconnected",
            "last_emotion_time": timing_data.get("last_updated", "never"),
            "total_interactions": timing_data.get("interaction_count", 0),
        }
        
        # ✅Safe uptime calculation
        if 'phase_start_time' in globals() and phase_start_time is not None:
            try:
                current_time = time.time()
                
                # Check if phase_start_time is a datetime object or float
                if isinstance(phase_start_time, datetime):
                    # Convert datetime to timestamp for consistent calculation
                    start_timestamp = phase_start_time.timestamp()
                    uptime_seconds = current_time - start_timestamp
                elif isinstance(phase_start_time, (int, float)):
                    # Already a timestamp
                    uptime_seconds = current_time - phase_start_time
                else:
                    # Unknown type, set to 0
                    uptime_seconds = 0
                    
                health_data["uptime"] = max(0, uptime_seconds)  # Ensure non-negative
                
            except Exception as uptime_error:
                logger.warning(f"⚠️ Uptime calculation error: {uptime_error}")
                health_data["uptime"] = 0
        else:
            health_data["uptime"] = 0
        
        # Test database connection if available
        if emotions_collection is not None:
            try:
                # Simple ping to test connection
                emotions_collection.find_one(limit=1)
                health_data["database_test"] = "passed"
            except Exception as db_error:
                health_data["database_test"] = f"failed: {str(db_error)}"
                health_data["mongodb_connected"] = False
                
        return health_data
        
    except Exception as e:
        logger.error(f"❌ Health check error: {e}")
        return {
            "camera_active": False,
            "detection_active": False,
            "mongodb_connected": False,
            "database_status": "error",
            "error": str(e),
            "uptime": 0
        }

def get_system_status():
    """Get enhanced system status with proper emotion system reporting - FIXED JSON serialization"""
    try:
        current_timing = get_current_timing_data()
        
        # Check emotion system health
        emotion_system_healthy = (
            camera_active.is_set() and 
            detection_active.is_set() and 
            emotion_detector is not None and
            cap is not None
        )
        
        # Build comprehensive status
        if isinstance(latest_emotion_result, dict):
            latest_emotion = latest_emotion_result.get("facial_emotion", "unknown")
            latest_status = latest_emotion_result.get("status", "ready")
            face_detected = latest_emotion_result.get("face_detected", False)
        else:
            latest_emotion = "unknown"
            latest_status = "ready"
            face_detected = False
        status = {
            "status": "healthy" if emotion_system_healthy else "degraded",
            "camera_active": camera_active.is_set(),
            "detection_active": detection_active.is_set(),
            "interaction_active": interaction_active.is_set(),
            "listening_active": listening_active.is_set(),
            "processing_active": processing_active.is_set(),
            "avatar_talking": avatar_talking.is_set(),
            "running": running,
            "latest_emotion": latest_emotion,
            "latest_status": latest_status,
            "face_detected": face_detected,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "system_health": {
                "emotion_system": emotion_system_healthy,
                "camera": camera_active.is_set() and cap is not None,
                "emotion_detector": emotion_detector is not None,
                "vosk_model": vosk_model is not None,
                "database": emotions_collection is not None,
                "llm_system": True,
                "tts_system": True
            },
            "capabilities": {
                "speech_recognition": vosk_model is not None,
                "emotion_detection": emotion_detector is not None,
                "facial_detection": emotion_detector is not None and camera_active.is_set(),
                "text_to_speech": True,
                "llm_integration": True
            },
            "timing_data": current_timing,
            "performance_metrics": get_performance_metrics()
        }
        return serialize_for_json(status)
    except Exception as e:
        logger.error(f"❌ Error getting system status: {e}")
        return serialize_for_json({
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "system_health": {
                "emotion_system": False,
                "camera": False,
                "emotion_detector": False,
                "vosk_model": False,
                "database": False,
                "llm_system": False,
                "tts_system": False
            },
            "pipeline_success": False
        })
# ========== STATUS MANAGEMENT ==========
def get_interaction_status():
    """Get detailed interaction status for frontend - FIXED JSON serialization"""
    status = {
        "interaction_active": interaction_active.is_set(),
        "listening_active": listening_active.is_set(),
        "stt_processing_active": stt_processing_active.is_set(),
        "processing_active": processing_active.is_set(),
        "avatar_talking": avatar_talking.is_set(),
        "camera_active": camera_active.is_set(),
        "detection_active": detection_active.is_set(),
        "system_ready": (camera_active.is_set() and detection_active.is_set()),
        "current_phase": get_current_phase(),
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    # Ensure JSON serializable
    return serialize_for_json(status)

def get_current_phase():
    """FIXED: Better phase detection with STT processing phase"""
    if avatar_talking.is_set():
        return "speaking"
    elif processing_active.is_set():
        return "processing"  
    elif listening_active.is_set():
        return "listening"
    elif interaction_active.is_set() and not listening_active.is_set():
        return "converting"  # STT processing phase
    else:
        return "idle" 

def get_current_timing_data():
    """Get current timing data in a thread-safe way"""
    with performance_lock:
        result = timing_data.copy() # Start with current timing data to preserve counts
        # Set defaults only for missing values
        default_timing = {
            "stt_time": 0.0,
            "tone_time": 0.0,
            "llm_time": 0.0,
            "tts_time": 0.0,
            "total_time": 0.0,
            "last_updated": datetime.now(timezone.utc).isoformat()
        }
        
        for key, value in default_timing.items():
            if key not in result:
                result[key] = value
        # Recalculate total_time to ensure consistency
        result["total_time"] = (result["stt_time"] + result["tone_time"] + result["llm_time"] + result["tts_time"])
        
        return result

def get_performance_metrics():
    """Return performance timing data with derived percentages"""
    current_timing = get_current_timing_data()
    total_time = current_timing["total_time"]
    # Get current system status
    system_status = {
        "emotion_system": detection_active.is_set() and camera_active.is_set(),
        "llm_system": True,  # Assuming LLM is always available if this function is called
        "database": emotions_collection is not None
    }

    # Calculate percentages if we have meaningful data
    if total_time > 0.001:  # Small threshold to avoid division by tiny numbers
        current_timing.update({
            "stt_percentage": (current_timing["stt_time"] / total_time) * 100,
            "tone_percentage": (current_timing["tone_time"] / total_time) * 100,
            "llm_percentage": (current_timing["llm_time"] / total_time) * 100,
            "tts_percentage": (current_timing["tts_time"] / total_time) * 100,
            "system_status": system_status
        })
    else:
        current_timing.update({
            "stt_percentage": 0.0,
            "tone_percentage": 0.0,
            "llm_percentage": 0.0,
            "tts_percentage": 0.0,
            "interaction_count": 0,
            "system_status": system_status
        })
    logger.info(
        "📊 Performance metrics sent: {"
        f"'interaction_count': {current_timing.get('interaction_count', 0)}, "
        f"'total_time': {current_timing['total_time']:.3f}s, "
        "'breakdown': {"
        f"'stt': {current_timing['stt_time']:.3f}s ({current_timing['stt_percentage']:.1f}%), "
        f"'tone': {current_timing['tone_time']:.3f}s ({current_timing['tone_percentage']:.1f}%), "
        f"'llm': {current_timing['llm_time']:.3f}s ({current_timing['llm_percentage']:.1f}%), "
        f"'tts': {current_timing['tts_time']:.3f}s ({current_timing['tts_percentage']:.1f}%)"
        "}"
        "}"
    )
    return current_timing

def increment_interaction_count():
    """Increment the interaction counter"""
    with performance_lock:
        timing_data["interaction_count"] = timing_data.get("interaction_count", 0) + 1
        timing_data["last_updated"] = datetime.now(timezone.utc).isoformat()
        logger.debug(f"📈 Interaction count incremented to {timing_data['interaction_count']}")

def reset_audio_system():
    global p, stream
    try:
        if stream is not None:
            stream.stop_stream()
            stream.close()
            stream = None
        if p is not None:
            p.terminate()
            p = None
    except Exception as e:
        pass
    p = pyaudio.PyAudio() # Reinitialize for next use

def reset_interaction_flags():
    global interaction_active, listening_active, processing_active, avatar_talking, stt_processing_active, current_phase, current_llm_response, current_dominant_emotion
    with threading.Lock():
        listening_active.clear()
        stt_processing_active.clear()
        processing_active.clear()
        avatar_talking.clear()
        interaction_active.clear()
        tone_analysis_allowed.clear()
        current_llm_response = ""  # Clear the current LLM response
        current_dominant_emotion = "neutral"  # Reset to neutral emotion
        reset_audio_system()
        time.sleep(0.2) # Small delay to ensure state propagation 
        if any([listening_active.is_set(), processing_active.is_set(), 
                avatar_talking.is_set(), interaction_active.is_set(), tone_analysis_allowed.is_set()]):
            logger.warning("⚠️ RESET INCOMPLETE - Some flags still set | "
                         f"listening_active:{'✅' if listening_active.is_set() else '❌'} | "
                         f"processing_active:{'✅' if processing_active.is_set() else '❌'} | "
                         f"avatar_talking:{'✅' if avatar_talking.is_set() else '❌'} | "
                         f"interaction_active:{'✅' if interaction_active.is_set() else '❌'} | "
                         f"tone_analysis_allowed:{'✅' if tone_analysis_allowed.is_set() else '❌'}")
            listening_active.clear()
            stt_processing_active.clear()
            processing_active.clear()
            avatar_talking.clear()
            interaction_active.clear()
            tone_analysis_allowed.clear() 
        current_phase = "idle"
    logger.debug(f"FULL RESET: phase={current_phase}, flags={[listening_active.is_set(), processing_active.is_set(), ...]}")
    logger.info("🧹 Interaction flags fully reset - System now in ready state")
    # Clean up any leftover temp files during reset
    cleanup_temp_audio_files()

def update_all_performance_metrics(stt_time=None, tone_time=None, llm_time=None, tts_time=None):
    """Update multiple performance metrics at once"""
    with performance_lock:
        global timing_data
        
        if stt_time is not None:
            timing_data["stt_time"] = float(stt_time)
        if tone_time is not None:
            timing_data["tone_time"] = float(tone_time)
        if llm_time is not None:
            timing_data["llm_time"] = float(llm_time)
        if tts_time is not None:
            timing_data["tts_time"] = float(tts_time)
        
        # Recalculate total_time
        timing_data["total_time"] = ( timing_data.get("stt_time", 0.0) + timing_data.get("tone_time", 0.0) + timing_data.get("llm_time", 0.0) + timing_data.get("tts_time", 0.0))
        
        timing_data["last_updated"] = datetime.now(timezone.utc).isoformat()
        timing_data["interaction_count"] = timing_data.get("interaction_count", 0) + 1
        
        logger.debug(f"📊 Updated all metrics - Total: {timing_data['total_time']}")

def cleanup():
    """Safe-to-call-multiple-times cleanup"""
    if not hasattr(cleanup, '_already_called'):
        cleanup._already_called = True
        logger.info("🧹 Cleaning up resources...")
        result = stop_detection()
        if result["status"] != "success":
                logger.warning(f"Detection stop warning: {result.get('message')}")
        stop_camera()
        
        if 'mongo_client' in globals() and mongo_client:
            try:
                mongo_client.close()
                logger.info("✅ MongoDB connection closed")
            except Exception as e:
                logger.warning(f"⚠️ Error closing MongoDB: {e}")
        
        logger.info("✅ Cleanup completed")

def cleanup_temp_audio_files():
    """Clean up any leftover temp audio files from previous interactions"""
    import tempfile
    import glob
    
    try:
        # Get the temp directory
        temp_dir = tempfile.gettempdir()
        # Look for temp audio files (common patterns)
        patterns = [
            os.path.join(temp_dir, "tmp*.wav"),
            os.path.join(temp_dir, "temp*.wav"),
            os.path.join(temp_dir, "*tmp*.wav")
        ]
        
        cleaned_files = []
        for pattern in patterns:
            try:
                files = glob.glob(pattern)
                for file_path in files:
                    try:
                        # Check if file is older than 1 minute (likely leftover)
                        if os.path.exists(file_path):
                            file_age = time.time() - os.path.getmtime(file_path)
                            if file_age > 60:  # Older than 1 minute
                                os.remove(file_path)
                                cleaned_files.append(file_path)
                                logger.debug(f"🧹 Cleaned up old temp audio file: {file_path}")
                    except Exception as e:
                        logger.debug(f"⚠️ Could not remove temp file {file_path}: {e}")
            except Exception as e:
                logger.debug(f"⚠️ Error scanning pattern {pattern}: {e}")
        
        if cleaned_files:
            logger.info(f"🧹 Cleaned up {len(cleaned_files)} leftover temp audio files")
        return len(cleaned_files)
        
    except Exception as e:
        logger.warning(f"⚠️ Error during temp file cleanup: {e}")
        return 0

def remove_repeated_phrases(text):
    # Remove repeated consecutive words/phrases (e.g., "they left me they left me")
    return re.sub(r'\b(\w+\b(?:\s+\w+\b){0,4})\s+\1\b', r'\1', text, flags=re.IGNORECASE)

# ========== Main Entry Point ==========
if __name__ == "__main__":
    logger.info("🤖 Enhanced Emotion Avatar System - Starting")
    
    try:
        start_camera()
        time.sleep(1)
        start_detection()
        logger.info("✅ Avatar system ready. Use talk_to_avatar() to interact.")
        
        while True:
            status = get_system_status()
            if isinstance(status, dict):
                logger.info(f"Status: Camera={status.get('camera_active', False)}, Detection={status.get('detection_active', False)}")
            else:
                logger.info(f"Status: {status}")
            time.sleep(3)
            
    except KeyboardInterrupt:
        logger.info("🛑 Shutdown requested by user")
        os._exit(0) # Force exit after cleanup
    except Exception as e:
        logger.error(f"❌ Unexpected error: {e}")
        os._exit(1) # Force exit after cleanup
    finally:
        cleanup()
        os._exit(0) # Force exit to ensure complete termination

