from datetime import datetime, timezone
import traceback
from flask import Flask, jsonify, request, Response, make_response
from flask_cors import CORS
from pymongo import MongoClient
from emotion_detector import interaction_active,reset_interaction_flags,reset_performance_metrics, scrub_sensitive_info, tts_engine, local_tts, mongo_db, emotions_collection, interactions_collection, serialize_for_json
import csv
import os
import subprocess
from io import StringIO
import threading
import requests
import time
import logging
import atexit

# ========== Logging Setup ==========
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global state tracking for API
pending_llm_results = {}
last_sent_data = {}
data_lock = threading.Lock()

app = Flask(__name__)
CORS(app, 
     resources={
         r"/*": {
             "origins": ["http://localhost:3000"],
             "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
             "allow_headers": ["Content-Type", "Authorization", "Accept", "Cache-Control", "Pragma"],
             "expose_headers": ["*"],
             "supports_credentials": False
         }
     })

# ========== Ollama Configuration ==========
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2:latest" 

def check_ollama_connection():
    """Check both Ollama connection and model availability with timeout"""
    try:
        # First check if Ollama is running
        test_response = requests.get(
            "http://localhost:11434/api/tags",
            timeout=3
        )
        
        if test_response.status_code != 200:
            return {
                "connected": False,
                "error": f"API returned {test_response.status_code}",
                "model_available": False
            }
        
        # Then verify the specific model exists
        models = [m['name'] for m in test_response.json().get('models', [])]
        model_available = OLLAMA_MODEL in models
        
        return {
            "connected": True,
            "model_available": model_available,
            "models_found": models[:3]  # Return first 3 models for debugging
        }
        
    except requests.exceptions.ConnectionError:
        return {
            "connected": False,
            "error": "Ollama service not running",
            "model_available": False
        }
    except Exception as e:
        return {
            "connected": False,
            "error": str(e),
            "model_available": False
        }

# ========== Safe Import of emotion_detector functions ==========
try:
    from emotion_detector import (
    talk_to_avatar, get_latest_emotion, get_system_status, start_detection, stop_detection, start_camera, stop_camera,
    get_frame, cleanup, get_performance_metrics, query_ollama, get_current_timing_data, camera_active, detection_active,
    get_current_llm_response, get_current_dominant_emotion
)
    logger.info("✅ All emotion_detector functions imported successfully")
    EMOTION_DETECTOR_AVAILABLE = True

except ImportError as e:
    logger.warning(f"⚠️ Some emotion_detector functions not available: {e}")
    EMOTION_DETECTOR_AVAILABLE = False
    
    # Create fallback functions
    def talk_to_avatar(*args, **kwargs):
        return {"status": "error", "error": "Emotion detector not available"}
    
    def get_latest_emotion():
        return {"status": "offline", "facial_emotion": "neutral", "timestamp": time.time()}
    
    def get_system_status():
        return {"status": "offline", "camera_active": False, "detection_active": False}
    
    def start_detection():
        return {"status": "error", "error": "Detection system not available"}
    
    def stop_detection():
        return {"status": "error", "error": "Detection system not available"}
    
    def start_camera():
        return False
    
    def stop_camera():
        pass
    
    def get_frame():
        return None
    
    def cleanup():
        pass
    
    def get_performance_metrics():
        return {}
    
    def get_current_timing_data():
        return {}
    
    def get_system_health():
        return {"status": "offline", "components": {}}
    
    def get_current_llm_response():
        return {"status": "no_response", "llm_response": "", "timestamp": datetime.now(timezone.utc).isoformat()}

    def get_current_dominant_emotion():
        return {"status": "no_emotion", "dominant_emotion": "neutral", "timestamp": datetime.now(timezone.utc).isoformat()}

    # Create mock threading events
    class MockEvent:
        def is_set(self):
            return False
    
    camera_active = MockEvent()
    detection_active = MockEvent()

# ========== Main Avatar Interaction Route ==========
@app.route('/api/talk', methods=['POST', 'OPTIONS'])
def api_talk():
    # Handle CORS preflight OPTIONS request
    if request.method == 'OPTIONS':
        response = app.make_default_options_response()
        response.headers['Access-Control-Allow-Origin'] = 'http://localhost:3000'
        response.headers['Access-Control-Allow-Methods'] = 'POST, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, Accept, Cache-Control, Pragma'
        response.headers['Access-Control-Max-Age'] = '3600'
        return response, 200
    
    # Forcefully clear all flags before starting a new interaction
    from emotion_detector import reset_interaction_flags
    reset_interaction_flags()
    logger.info("🧹 Force reset of interaction flags before starting new interaction")
    
    if not EMOTION_DETECTOR_AVAILABLE:
        return jsonify({"status": "error", "error": "Emotion detection system not available"}), 503
    
    # Check for existing interaction
    if interaction_active.is_set():
        reset_interaction_flags()
        return jsonify({
            "status": "error",
            "error": "Another interaction is already in progress"
        }), 429
    try:
        data = request.get_json() or {}
        speak = data.get('speak', True)
        voice_gender = data.get('voice_gender', 'female')
        privacy_mode = data.get('privacy_mode', True)
        emotion_context_enabled = data.get('emotion_context', True)
        
        # Direct interaction without complex threading
        try:
            interaction_active.set()
            logger.info("🔴 interaction_active set to True")
            result = talk_to_avatar(
                speak=speak,
                voice_gender=voice_gender,
                privacy_mode=privacy_mode,
                use_emotion_context=emotion_context_enabled
            )
            return jsonify(serialize_for_json(result))
        finally:
            reset_interaction_flags()
            logger.info("🟢 interaction_active set to False")
                
    except Exception as e:
        reset_interaction_flags()
        logger.error(f"Avatar interaction error: {str(e)}")
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

                
    except Exception as e:
        reset_interaction_flags()
        logger.error(f"Avatar interaction error: {str(e)}")
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

# Determining any mismatch between verbal content, tone, and facial expression
def analyze_emotion_congruence(emotion_context):
    if not emotion_context:
        return "Emotion alignment unknown. Respond supportively."

    facial = emotion_context.get("facial_emotion", "unknown").lower()
    tone = emotion_context.get("tone_emotion", "unknown").lower()
    sentiment = emotion_context.get("text_sentiment", "unknown").lower()

    contradiction = False
    cues = []

    if sentiment in ["positive", "very positive"] and facial in ["sad", "angry", "fearful", "disgust"]:
        contradiction = True
        cues.append("The user says something positive but looks upset or tense.")
    if tone in ["angry", "sad", "fearful"] and sentiment in ["positive", "neutral"]:
        contradiction = True
        cues.append("The voice tone sounds emotional while the message is neutral or upbeat.")
    if facial == "happy" and sentiment in ["negative", "very negative"]:
        contradiction = True
        cues.append("The facial expression is happy but the words are negative.")

    if contradiction:
        return "⚠️ Possible emotional contradiction detected:\n- " + "\n- ".join(cues)
    else:
        return "✅ Emotional signals appear congruent. Respond with empathy and encouragement."
    
# ========== Main LLM Reply Endpoint ==========
@app.route("/llm_reply", methods=["POST", "OPTIONS"])
def llm_reply():
    """Enhanced LLM reply endpoint with better error handling"""
    if request.method == "OPTIONS":
        return jsonify({"message": "CORS preflight successful"})
    
    try:
        # Validate JSON
        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400
            
        data = request.get_json()
        
        # Required parameters
        if "message" not in data:
            return jsonify({"error": "Missing 'message' parameter"}), 400
            
        message = data["message"]
        if not message or not isinstance(message, str):
            return jsonify({"error": "Invalid message"}), 400
            
        # Optional parameters with defaults
        privacy_mode = data.get("privacy_mode", False)
        voice_gender = data.get("voice_gender", "female")
        speak_flag = data.get("speak", False)
        
        # Apply privacy scrubbing if enabled
        processed_message = scrub_sensitive_info(message) if privacy_mode else message
        
        # Process the message
        start_time = time.perf_counter()
        reply = query_ollama(processed_message, None, [])  # No emotion context for text-only
        
        # Prepare response
        response_data = {
            "reply": reply,
            "tts_success": False,  # Text-only doesn't use TTS
            "timing": {
                "llm_time": round(time.perf_counter() - start_time, 3),
                "tts_time": 0.0
            },
            "emotion_acknowledged": False,
            "privacy_mode": privacy_mode,
            "original_message": message if privacy_mode else None,  # For debugging
            "scrubbed_message": processed_message if privacy_mode else None
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"❌ LLM reply error: {e}")
        return jsonify({
            "error": "Failed to process LLM request",
            "details": str(e),
            "reply": "I apologize, but I encountered an error processing your request."
        }), 500

# ========== Video Feed Route ==========
@app.route("/video_feed")
def video_feed():
    """Video feed with emotion detection overlay"""
    if not EMOTION_DETECTOR_AVAILABLE:
        return jsonify({"error": "Camera system not available"}), 503
    
    def generate():
        logger.info("🎥 Starting video feed generation")
        while True:
            frame = get_frame()
            if frame:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            else:
                # Send a placeholder frame or break
                time.sleep(0.1)
            time.sleep(1/30)  # 30 FPS max

    return Response(generate(), 
                    mimetype='multipart/x-mixed-replace; boundary=frame')

# ========== Camera Control Routes ==========
@app.route("/start_camera", methods=["POST"])
def start_camera_endpoint():
    """Start camera capture"""
    if not EMOTION_DETECTOR_AVAILABLE:
        return jsonify({
            "status": "Camera system not available", 
            "success": False, 
            "error": "Emotion detector not loaded"
        }), 503
    
    try:
        success = start_camera()
        result = {
            "success": success, 
            "status": "Camera started" if success else "Failed to start camera"
        }
        logger.info(f"Camera start result: {result}")
        return jsonify(result)
    except Exception as e:
        logger.error(f"❌ Error starting camera: {e}")
        return jsonify({
            "status": "Error starting camera", 
            "success": False, 
            "error": str(e)
        }), 500

@app.route("/llm_result/<interaction_id>", methods=["GET"])
def get_llm_result(interaction_id):
    result = pending_llm_results.get(interaction_id)
    
    if result:
        # Remove once fetched to avoid memory growth
        pending_llm_results.pop(interaction_id, None)
        return jsonify({
            "status": "ready",
            "reply": result["reply"],
            "voice_gender": result["voice_gender"]
        })
    else:
        return jsonify({"status": "pending"})
    
@app.route("/stop_camera", methods=["POST"])
def stop_camera_endpoint():
    """Stop camera capture"""
    if not EMOTION_DETECTOR_AVAILABLE:
        return jsonify({
            "status": "Camera system not available", 
            "success": False
        }), 503
    
    try:
        stop_camera()
        result = {"success": True, "status": "Camera stopped"}
        logger.info(f"Camera stop result: {result}")
        return jsonify(result)
    except Exception as e:
        logger.error(f"❌ Error stopping camera: {e}")
        return jsonify({
            "status": "Error stopping camera", 
            "success": False, 
            "error": str(e)
        }), 500

# ========== Detection Control Routes ==========
@app.route('/api/start', methods=['POST'])
def api_start_detection():
    """Start detection system"""
    if not EMOTION_DETECTOR_AVAILABLE:
        return jsonify({
            "status": "error", 
            "error": "Detection system not available"
        }), 503
    
    try:
        logger.info("🚀 API: Starting detection system")
        
        # Start camera first
        camera_result = start_camera()
        if not camera_result:
            return jsonify({"status": "error", "error": "Failed to start camera"}), 500
        
        # Then start detection
        result = start_detection()
        logger.info("✅ API: Detection system started")
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"❌ API: Start detection error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route('/api/stop', methods=['POST'])
def api_stop_detection():
    """Stop detection system"""
    if not EMOTION_DETECTOR_AVAILABLE:
        return jsonify({
            "status": "error", 
            "error": "Detection system not available"
        }), 503
    
    try:
        logger.info("🛑 API: Stopping detection system")
        result = stop_detection()
        logger.info("✅ API: Detection system stopped")
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"❌ API: Stop detection error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

# ========== Status and Data Routes ==========
@app.route('/api/status', methods=['GET'])
def api_get_status():
    """REAL-TIME Get system status with dynamic updates"""
    try:
        if not EMOTION_DETECTOR_AVAILABLE:
            return jsonify({
                "status": "offline",
                "current_process": "⚠️ System Offline",
                "process_description": "Emotion detection system not available",
                "interaction_count": 0,
                "last_interaction_time": 0
            })
        
        from emotion_detector import avatar_talking, processing_active
        current_status = get_system_status()

        # Clear processing flags if they're stuck
        if avatar_talking.is_set() and not processing_active.is_set():
            current_status["avatar_talking"] = False
            current_status["processing_active"] = False

        # Add interaction statistics
        timing_data = get_current_timing_data()
        current_status["interaction_count"] = timing_data.get("interaction_count", 0)
        current_status["last_interaction_time"] = timing_data.get("total_time", 0)
        
        return jsonify(current_status)
                
    except Exception as e:
        logger.error(f"❌ API: Get status error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route('/api/emotion', methods=['GET'])
def api_get_emotion():
    try:
        current_emotion = get_latest_emotion()
        
        # Always return full data, let frontend handle changes
        if "timing" not in current_emotion:
            current_emotion["timing"] = get_current_timing_data()
        
        # Add additional emotion context data
        current_emotion.update({
            "update_timestamp": datetime.now(timezone.utc).isoformat(),
            "face_confidence": current_emotion.get("confidence", 0),
            "is_valid": True
        })
        
        return jsonify(current_emotion)  # Remove the "no_change" logic
        
    except Exception as e:
        logger.error(f"API emotion error: {str(e)}")
        return jsonify({
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }), 500

def has_data_changed(new_data, last_data):
    """Check if data has meaningfully changed to prevent spam"""
    if not last_data:
        return True
    
    # Check key fields that matter for UI updates
    key_fields = ['status', 'interaction_active', 'listening_active', 'processing_active', 'avatar_talking', 'interaction_count', 'facial_emotion', 'face_detected', 'confidence', 'faces_count']
    
    for field in key_fields:
        if new_data.get(field) != last_data.get(field):
            return True
    
    # Check if timing data changed significantly (avoid floating point spam)
    timing_fields = ['stt_time', 'llm_time', 'tts_time', 'total_time']
    for field in timing_fields:
        new_val = new_data.get(field, 0)
        old_val = last_data.get(field, 0)
        if abs(new_val - old_val) > 0.01:  # Only if difference > 10ms
            return True
    
    return False

@app.route("/conversation_logs", methods=["GET", "OPTIONS"])
def conversation_logs():
    """Get recent conversation logs"""
    if request.method == "OPTIONS":
        return jsonify({"message": "CORS preflight successful"})

    if interactions_collection is None:
        logger.error("❌ MongoDB interactions_collection is not connected.")
        return jsonify({"error": "Database not connected", "logs": []}), 500

    try:
        logs = list(interactions_collection.find({}, {"_id": 0}).sort("timestamp", -1).limit(50))
        logger.info(f"✅ Retrieved {len(logs)} conversation logs")
        return jsonify({
            "logs": logs,
            "count": len(logs),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    except Exception as e:
        logger.error(f"❌ Error retrieving logs: {e}")
        return jsonify({"error": str(e), "logs": []}), 500
    
@app.route("/performance_metrics", methods=["GET", "OPTIONS"])
def performance_metrics():
    """Get performance timing data with detailed debugging"""
    if request.method == "OPTIONS":
        response = jsonify({})
        response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
        response.headers.add('Access-Control-Allow-Headers', "Content-Type,Authorization,Accept,Cache-Control,Pragma")
        response.headers.add('Access-Control-Allow-Methods', "GET,OPTIONS")
        return response
    
    try:
        logger.info("📊 Performance metrics requested")
        
        if not EMOTION_DETECTOR_AVAILABLE:
            # More specific error message when detector is unavailable
            logger.warning("⚠️ Emotion detector not available - returning empty metrics")
            response_data = {
                "status": "success",
                "metrics": {},
                "timestamp": time.time(),
                "debug_info": {
                    "metrics_available": False,
                    "reason": "Emotion detector system not available"
                }
            }
        else:
            try:
                # Get metrics from emotion_detector
                metrics = get_performance_metrics()
                logger.info(f"📊 Retrieved metrics: {metrics}")
                
                # Validate metrics format
                if metrics is None:
                    logger.warning("⚠️ Performance metrics returned None - using empty dict")
                    metrics = {}
                
                if not isinstance(metrics, dict):
                    logger.error(f"❌ Invalid metrics type: {type(metrics).__name__} - converting to dict")
                    metrics = dict(metrics) if hasattr(metrics, '__dict__') else {}
                
                # Enhanced response with more detail
                response_data = {
                    "status": "success",
                    "metrics": metrics,
                    "timestamp": time.time(),
                    "debug_info": {
                        "metrics_available": bool(metrics),
                        "metrics_type": type(metrics).__name__,
                        "metrics_count": len(metrics),
                        "metrics_keys": list(metrics.keys()) if isinstance(metrics, dict) else []
                    }
                }
                
            except Exception as inner_e:
                # Handle inner exceptions specifically
                logger.error(f"❌ Error getting performance metrics from detector: {inner_e}")
                response_data = {
                    "status": "partial_success",
                    "metrics": {},
                    "error": "Failed to retrieve metrics from emotion detector",
                    "details": str(inner_e),
                    "debug_info": {
                        "error_type": type(inner_e).__name__,
                        "timestamp": time.time()
                    }
                }
        
        response = jsonify(response_data)
        response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
        logger.info(f"✅ Performance metrics response prepared")
        return response
        
    except Exception as e:
        # More detailed error logging
        logger.exception(f"❌ Critical error in performance_metrics endpoint: {e}")
        error_response = {
            "error": "Internal server error",
            "message": "Failed to process performance metrics request",
            "details": str(e),
            "debug_info": {
                "error_type": type(e).__name__,
                "timestamp": time.time(),
                "endpoint": "/performance_metrics",
                "request_method": request.method
            }
        }
        response = jsonify(error_response)
        response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
        return response, 500

@app.route('/api/interaction_ready', methods=['GET'])
def interaction_ready():
    """Check if system is ready for new interaction"""
    try:
        from emotion_detector import (
            interaction_active, listening_active, 
            processing_active, avatar_talking
        )
        
        ready = not any([
            interaction_active.is_set(),
            listening_active.is_set(),
            processing_active.is_set(),
            avatar_talking.is_set()
        ])
        
        return jsonify({
            "ready": ready,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    except Exception as e:
        return jsonify({
            "ready": False,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }), 500

# ========== Health Check Route ==========
@app.route('/api/health', methods=['GET'])
def api_health():
    try: # Get component statuses
        ollama_status = check_ollama_connection()
        mongo_status = interactions_collection is not None
        
        # More lenient health determination
        health_data = {
            "status": "healthy",
            "components": {
                "emotion_detector": EMOTION_DETECTOR_AVAILABLE,
                "camera": camera_active.is_set() if EMOTION_DETECTOR_AVAILABLE else False,
                "detection": detection_active.is_set() if EMOTION_DETECTOR_AVAILABLE else False,
                "ollama": ollama_status,
                "mongodb": mongo_status
            },
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        # Don't fail completely if non-critical components are down
        if not ollama_status.get('connected') or not mongo_status:
            health_data["status"] = "degraded"
            
        return jsonify(health_data)  
    except Exception as e:
        logger.error(f"Health check error: {e}")
        return jsonify({
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }), 500

def test_camera():
    """Check if camera is actually working"""
    try:
        if not EMOTION_DETECTOR_AVAILABLE or not camera_active.is_set():
            return False
        frame = get_frame()
        return frame is not None and len(frame) > 1000  # Simple check for valid frame
    except:
        return False

def test_detection():
    """Check if emotion detection is working"""
    try:
        if not EMOTION_DETECTOR_AVAILABLE or not detection_active.is_set():
            return False
        emotion = get_latest_emotion()
        return emotion and "facial_emotion" in emotion
    except:
        return False

def test_llm_connection():
    """Check if LLM is actually reachable"""
    try:
        # Simple prompt to test connectivity
        test_prompt = {"model": OLLAMA_MODEL, "prompt": "Say 'OK'", "stream": False}
        response = requests.post(OLLAMA_URL, json=test_prompt, timeout=5)
        return response.status_code == 200 and "OK" in response.json().get("response", "")
    except:
        return False

@app.route("/interaction_flags", methods=["GET"])
def interaction_flags():
    try:
        if not EMOTION_DETECTOR_AVAILABLE:
            return jsonify({
                "listening_active": False,
                "processing_active": False,
                "avatar_talking": False,
                "available": False,
                "stt_processing_active": False,
                "interaction_active": False,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

        from emotion_detector import (
            listening_active, processing_active, 
            avatar_talking, stt_processing_active,
            interaction_active, phase_start_time
        )

        # Calculate current phase based on priority
        current_phase = (
            "speaking" if avatar_talking.is_set() else
            "processing" if processing_active.is_set() else
            "stt_processing" if stt_processing_active.is_set() else
            "listening" if listening_active.is_set() else
            "idle"
        )

        # Only reset flags if they're stuck for too long (30s timeout)
        current_time = time.time()
        max_duration = 30  # Increased timeout to 30 seconds
        
        phase_start = getattr(phase_start_time, 'phase_start_time', current_time)
        
        if (avatar_talking.is_set() and not processing_active.is_set() and 
            (current_time - phase_start) > max_duration):
            logger.warning(f"⚠️ Avatar talking timeout - resetting flags")
            reset_interaction_flags()
            
        if (interaction_active.is_set() and not any([
            listening_active.is_set(),
            processing_active.is_set(),
            avatar_talking.is_set()
        ]) and (current_time - phase_start) > max_duration):
            logger.warning(f"⚠️ Interaction active timeout - resetting flags")
            reset_interaction_flags()

        return jsonify({
            "listening_active": listening_active.is_set(),
            "processing_active": processing_active.is_set(),
            "avatar_talking": avatar_talking.is_set(),
            "stt_processing_active": stt_processing_active.is_set(),
            "interaction_active": interaction_active.is_set(),
            "current_phase": current_phase,
            "available": not any([
                listening_active.is_set(),
                processing_active.is_set(),
                avatar_talking.is_set(),
                stt_processing_active.is_set(),
                interaction_active.is_set()
            ]),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    except Exception as e:
        logger.error(f"❌ Interaction flags error: {e}")
        return jsonify({
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }), 500

@app.route('/api/interaction_status', methods=['GET'])
def api_interaction_status():
    """Get interaction status (compatibility endpoint)"""
    return interaction_flags()  # Reuse the existing endpoint

@app.route('/api/current_llm_response', methods=['GET'])
def api_current_llm_response():
    """Get the current LLM response if available"""
    try:
        if not EMOTION_DETECTOR_AVAILABLE:
            return jsonify({
                "status": "no_response",
                "llm_response": "",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
        
        result = get_current_llm_response()
        logger.info(f"📝 Current LLM response requested: {result['status']}")
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"❌ Error getting current LLM response: {e}")
        return jsonify({
            "status": "error",
            "error": str(e),
            "llm_response": "",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }), 500

@app.route('/api/current_dominant_emotion', methods=['GET'])
def api_current_dominant_emotion():
    """Get the current dominant emotion if available"""
    try:
        if not EMOTION_DETECTOR_AVAILABLE:
            return jsonify({
                "status": "no_emotion",
                "dominant_emotion": "neutral",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
        
        result = get_current_dominant_emotion()
        logger.info(f"😊 Current dominant emotion requested: {result['dominant_emotion']}")
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"❌ Error getting current dominant emotion: {e}")
        return jsonify({
            "status": "error",
            "error": str(e),
            "dominant_emotion": "neutral",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }), 500

@app.route('/system_status', methods=['GET'])
def system_status():
    """Get system component status with proper error handling"""
    try:
        logger.info("📊 System status requested")
        
        status_data = {
            "camera_active": False,
            "detection_active": False,
            "mongodb_connected": interactions_collection is not None,
            "emotion_detector_available": EMOTION_DETECTOR_AVAILABLE,
            "timestamp": time.time()
        }
        
        # Only check camera/detection status if emotion detector is available
        if EMOTION_DETECTOR_AVAILABLE:
            try:
                status_data["camera_active"] = camera_active.is_set()
                status_data["detection_active"] = detection_active.is_set()
            except Exception as e:
                logger.warning(f"⚠️ Could not get camera/detection status: {e}")
                status_data["camera_active"] = False
                status_data["detection_active"] = False
        
        logger.info(f"✅ System status: {status_data}")
        return jsonify(status_data)
        
    except Exception as e:
        logger.error(f"❌ System status error: {e}")
        return jsonify({
            "error": "Failed to get system status",
            "details": str(e),
            "camera_active": False,
            "detection_active": False,
            "mongodb_connected": False,
            "emotion_detector_available": False,
            "timestamp": time.time()
        }), 500

# LLM-specific status endpoint
@app.route("/llm_status", methods=["GET"])
def llm_status():
    """Get LLM API system status"""
    try:
        # Test Ollama connection
        ollama_status = "disconnected"
        try:
            test_response = requests.get("http://localhost:11434/api/tags", timeout=5)
            if test_response.status_code == 200:
                ollama_status = "connected"
        except:
            pass
        
        return jsonify({
            "status": "healthy",
            "ollama_status": ollama_status,
            "ollama_model": OLLAMA_MODEL,
            "tts_available": tts_engine is not None,
            "mongodb_connected": interactions_collection is not None,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "version": "2.0_integrated"
        })
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500  
    
def llm_health():
    try:
        # Use the same test as in the main health check
        operational = test_llm_connection()
        return jsonify({
            "status": "healthy" if operational else "unhealthy",
            "operational": operational,
            "test_description": "Verified by sending test prompt to LLM"
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500
    
# ========== Data Logging Routes ==========
@app.route("/emotion_data_logs", methods=["GET", "OPTIONS"])
def emotion_data_logs():
    """Get emotion data logs from MongoDB"""
    if request.method == "OPTIONS":
        response = jsonify({})
        response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
        response.headers.add('Access-Control-Allow-Headers', "Content-Type,Authorization,Accept,Cache-Control,Pragma")
        response.headers.add('Access-Control-Allow-Methods', "GET,OPTIONS")
        return response
    
    if emotions_collection is None:
        response = jsonify({"error": "MongoDB not connected", "logs": []})
        response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
        return response, 200
    
    try:
        logs = list(emotions_collection.find({}, {"_id": 0}).sort("timestamp", -1).limit(100))
        response = jsonify({"logs": logs, "count": len(logs)})
        response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
        return response
    except Exception as e:
        logger.error(f"❌ Error getting emotion logs: {e}")
        response = jsonify({"error": str(e), "logs": []})
        response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
        return response, 500

@app.route('/api/reset_metrics', methods=['POST'])
def api_reset_metrics():
    """Reset performance metrics"""
    if not EMOTION_DETECTOR_AVAILABLE:
        return jsonify({
            "status": "error", 
            "error": "Emotion detector not available"
        }), 503
    
    try:
        from emotion_detector import reset_performance_metrics
        reset_performance_metrics()
        return jsonify({"status": "Metrics reset successfully"})
    except Exception as e:
        logger.error(f"❌ API: Reset metrics error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route('/api/reset', methods=['POST'])
def api_reset():
    if not request.is_json:
        return jsonify({
            "status": "error",
            "error": "Content-Type must be application/json"
        }), 415
    
    try:
        data = request.get_json() or {}
        hard_reset = data.get("hard_reset", False)
        
        if EMOTION_DETECTOR_AVAILABLE:
            reset_interaction_flags()
            reset_performance_metrics()  # Reset metrics on normal reset
            
            if hard_reset:
                logger.info("🔄 Performing HARD RESET")
                time.sleep(0.2)
                reset_interaction_flags()
                reset_performance_metrics()  # Reset metrics on hard reset
                time.sleep(0.2)
        
        return jsonify({
            "status": "success",
            "hard_reset": hard_reset,
            "message": "System reset successfully"
        })
    except Exception as e:
        logger.error(f"❌ Reset error: {e}")
        return jsonify({
            "status": "error",
            "error": str(e),
            "traceback": traceback.format_exc() if app.debug else None
        }), 500
    
@app.route("/download_logs")
def download_logs():
    """Download emotion logs as CSV"""
    if emotions_collection is None:
        return jsonify({"error": "MongoDB not connected"}), 500
    
    try:
        logs = list(emotions_collection.find({}, {"_id": 0}).sort("timestamp", -1).limit(1000))
        if not logs:
            return jsonify({"error": "No logs found"}), 404

        # Updated headers to match new emotion_detector structure
        headers = [
            "timestamp", "status", "speech_text", "facial_emotion", "tone_emotion", 
            "text_sentiment", "llm_response", "tts_success", "timing", "interaction_id"
        ]
        
        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=headers)
        writer.writeheader()
        
        for row in logs:
            # Flatten timing data if it exists
            timing_str = ""
            if "timing" in row and isinstance(row["timing"], dict):
                timing_parts = []
                for key, value in row["timing"].items():
                    timing_parts.append(f"{key}:{value}")
                timing_str = "; ".join(timing_parts)
            
            csv_row = {key: row.get(key, "") for key in headers}
            csv_row["timing"] = timing_str
            writer.writerow(csv_row)

        response = make_response(output.getvalue())
        response.headers["Content-Disposition"] = "attachment; filename=emotion_avatar_logs.csv"
        response.headers["Content-Type"] = "text/csv"
        logger.info(f"📊 Downloaded {len(logs)} emotion logs")
        return response
        
    except Exception as e:
        logger.error(f"❌ Error downloading logs: {e}")
        return jsonify({"error": str(e)}), 500

# ========== Documentation Route ==========
@app.route("/")
def api_documentation():
    """Integrated API documentation"""
    return jsonify({
        "name": "Emotion Avatar with Integrated LLM API",
        "version": "2.0",
        "description": "Enhanced emotion detection, avatar interaction, and LLM API",
        "status": "running",
        "emotion_detector_available": EMOTION_DETECTOR_AVAILABLE,
        "endpoints": {
            "interaction": {
                "POST /api/talk": "Main avatar interaction",
                "POST /llm_reply": "Text-only LLM interaction",
                "POST /llm_batch": "Batch process LLM requests"
            },
            "camera": {
                "GET /video_feed": "Live video feed",
                "POST /start_camera": "Start camera",
                "POST /stop_camera": "Stop camera"
            },
            "detection": {
                "POST /api/start": "Start detection",
                "POST /api/stop": "Stop detection"
            },
            "data": {
                "GET /api/emotion": "Latest emotion data",
                "GET /emotion_data_logs": "Emotion logs",
                "GET /conversation_logs": "Conversation history",
                "GET /download_logs": "Download logs as CSV",
                "GET /performance_metrics": "Performance data"
            },
            "system": {
                "GET /api/status": "System status",
                "GET /api/health": "Health check",
                "GET /system_status": "Component status",
                "GET /llm_status": "LLM system status",
                "GET /interaction_flags": "Interaction flags",
                "GET /": "This documentation"
            }
        },
        "features": {
            "emotion_detection": "Facial emotion recognition",
            "speech_recognition": "Local Vosk STT",
            "llm_integration": "Ollama-based conversational AI",
            "emotional_context": "Uses facial/tone/text emotions",
            "privacy_protection": "Sensitive info scrubbing",
            "batch_processing": "Multiple message handling",
            "tts_system": "Local text-to-speech"
        },
        "models": {
            "llm_model": OLLAMA_MODEL,
            "tts_voices": ["male", "female"]
        },
        "ports": {
            "api_server": 5000
        }
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Endpoint not found",
        "available_endpoints": [
            "/api/talk", "/llm_reply", "/llm_batch", 
            "/video_feed", "/api/status", "/llm_status",
            "/conversation_logs", "/performance_metrics", "/"
        ]
    }), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal server error: {error}")
    return jsonify({"status": "error", "error": "Internal server error"}), 500

if __name__ == '__main__':
    try:
        logger.info("🚀 Starting Emotion Avatar API Server")
        
        # Initialize systems only if emotion detector is available
        if EMOTION_DETECTOR_AVAILABLE:
            start_camera()
            time.sleep(1)
            start_detection()
            logger.info("✅ Emotion detection systems initialized")
        else:
            logger.info("⚠️ Running in fallback mode - emotion detection not available")
        
        atexit.register(cleanup) # Register cleanup only once
        
        logger.info("✅ Systems initialized. Starting Flask server...")
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=False,
            threaded=True,
            use_reloader=False
        )
           
    except KeyboardInterrupt:
        logger.info("🛑 API Server shutdown requested")
        os._exit(0) # Force exit after cleanup
    except Exception as e:
        logger.error(f"❌ API Server error: {e}")
        os._exit(1) # Force exit after cleanup
    finally:
        if 'cleanup' in globals(): # Ensure cleanup runs only once
            try:
                cleanup()
            except Exception as e:
                logger.warning(f"⚠️ Cleanup error: {e}")
        os._exit(0) # Force exit to ensure complete termination