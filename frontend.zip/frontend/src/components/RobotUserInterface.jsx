import React, { useState, useEffect } from "react";
import RobotAvatar from "./RobotAvatar";

const UserInterface = ({
  emotion,
  reply,
  message,
  setMessage,
  sendToLLM,
  clearMessage,
  talkToAvatar,
  isRecording,
  isListening,
  isProcessing,
  privacyMode,
  setPrivacyMode,
  isMuted,
  setIsMuted,
  speakReply,
  setSpeakReply,
  voiceGender,
  setVoiceGender,
  onBackToControl,
  backendConnected,
  currentPhase,
  healthData,
  emotionContextEnabled
}) => {
  // Read emotion context setting from localStorage
  const [localEmotionContextEnabled, setLocalEmotionContextEnabled] = useState(() => {
    const saved = localStorage.getItem('emotionContextEnabled');
    return saved !== null ? JSON.parse(saved) : true;
  });

  // Poll for changes to localStorage (since storage event doesn't fire for same-origin windows)
  useEffect(() => {
    const checkLocalStorage = () => {
      const saved = localStorage.getItem('emotionContextEnabled');
      const newValue = saved !== null ? JSON.parse(saved) : true;
      if (newValue !== localEmotionContextEnabled) {
        setLocalEmotionContextEnabled(newValue);
      }
    };

    const interval = setInterval(checkLocalStorage, 500); // Check every 500ms
    return () => clearInterval(interval);
  }, [localEmotionContextEnabled]);
  return (
    <div style={{ 
      height: "100vh", 
      background: "#667eea",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      padding: "10px",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif",
      overflow: "hidden"
    }}>
      {/* Header */}
      <div style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        width: "100%",
        maxWidth: "800px",
        marginBottom: "10px",
        height: "60px"
      }}>
        <button
          onClick={onBackToControl}
          style={{
            padding: "10px 20px",
            backgroundColor: "rgba(255, 255, 255, 0.2)",
            color: "white",
            border: "1px solid rgba(255, 255, 255, 0.3)",
            borderRadius: "25px",
            cursor: "pointer",
            fontSize: "14px",
            backdropFilter: "blur(10px)"
          }}
        >
          ← Back to Control
        </button>

        <div style={{
          display: "flex",
          alignItems: "center",
          gap: "10px",
          color: "white"
        }}>
          <div
            style={{
              width: "12px",
              height: "12px",
              borderRadius: "50%",
              backgroundColor: backendConnected ? 
                            (healthData?.status === "healthy" ? "#00ff00" : 
                              healthData?.status === "degraded" ? "#ffff00" : "#999") : 
                            "#ff0000",
              boxShadow: backendConnected ? 
                        (healthData?.status === "healthy" ? "0 0 10px rgba(0, 255, 0, 0.5)" : 
                        healthData?.status === "degraded" ? "0 0 10px rgba(255, 255, 0, 0.5)" : 
                        "0 0 10px rgba(51, 255, 0, 0.75)") : 
                        "0 0 10px rgba(255, 0, 0, 0.5)"
            }}
          ></div>
          <span style={{ fontSize: "14px" }}>
            {backendConnected ? 
            (healthData?.status === "healthy" ? "Connected ✅" : 
              healthData?.status === "degraded" ? "Degraded ⚠️" : "Connected") : 
            "Disconnected"}
          </span>
        </div>
      </div>

      {/* Main Content */}
      <div style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "10px",
        maxWidth: "800px",
        width: "100%",
        flex: 1,
        minHeight: 0
      }}>
        {/* Avatar Section */}
        <div style={{
          background: "rgba(255, 255, 255, 0.1)",
          borderRadius: "15px",
          padding: "10px",
          backdropFilter: "blur(10px)",
          border: "1px solid rgba(255, 255, 255, 0.2)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "8px",
          width: "100%",
          flex: 1,
          minHeight: 0
        }}>
          <div style={{
            display: "flex",
            alignItems: "center",
            gap: "30px",
            width: "100%",
            justifyContent: "center",
            flexWrap: "wrap"
          }}>
            <h1 style={{
              color: "white",
              margin: "0",
              fontSize: "clamp(1.5rem, 4vw, 2.2rem)",
              textAlign: "center"
            }}>
              🤖 Avatar Interface
            </h1>
            
            
          </div>

          <div style={{ 
            transform: "scale(clamp(0.8, 1.5vw, 1.0))",
            flex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            minHeight: 0
          }}>
            <RobotAvatar emotion={emotion} isSpeaking={currentPhase === "speaking"} emotionContextEnabled={localEmotionContextEnabled} />
          </div>

          {/* Status Display */}
          <div style={{
            color: "white",
            fontSize: "clamp(12px, 2.5vw, 16px)",
            textAlign: "center",
            minHeight: "30px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "rgba(0, 0, 0, 0.2)",
            borderRadius: "8px",
            padding: "8px",
            width: "100%"
          }}>
            {currentPhase === "listening" ? (
              <div style={{ color: "#00ff00", fontStyle: "italic" }}>
                🎤 Listening for your voice...
              </div>
            ) : currentPhase === "stt_processing" ? (
              <div style={{ color: "#ffa500", fontStyle: "italic" }}>
                ⏳ Analyzing speech...
              </div>
            ) : currentPhase === "processing" ? (
              <div style={{ color: "#ffa500", fontStyle: "italic" }}>
                🧠 Processing your request...
              </div>
            ) : currentPhase === "speaking" ? (
              <div style={{ color: "#9370db", fontStyle: "italic" }}>
                🔊 Avatar is speaking...
              </div>
            ) : reply ? (

              <div style={{ 

              fontStyle: "normal", 

              fontWeight: "400",

              lineHeight: "1.4",

              maxWidth: "90%"

              }}>

              <div style={{ 

              color: "#FFD700", 

              fontWeight: "bold", 

              marginBottom: "8px",

              fontSize: "clamp(12px, 2.2vw, 14px)"

              }}>

              🤖 Avatar Response:

              </div>

              <div style={{ 

              background: "rgba(255, 255, 255, 0.1)",

              padding: "12px",

              borderRadius: "8px",

              border: "1px solid rgba(255, 255, 255, 0.2)"

              }}>

              {reply}

              </div>

              </div>

              ) : (

              <div style={{ color: "#ccc", fontStyle: "italic", fontWeight: "500" }}>

              Ready to interact...

              </div>

              )}
          </div>
        </div>

        {/* Settings Section */}
        <div style={{
          background: "rgba(255, 255, 255, 0.1)",
          borderRadius: "15px",
          padding: "15px",
          backdropFilter: "blur(10px)",
          border: "1px solid rgba(255, 255, 255, 0.2)",
          width: "100%"
        }}>
          {/* Settings Row */}
          <div style={{
            display: "flex",
            gap: "20px",
            alignItems: "center",
            flexWrap: "wrap",
            justifyContent: "center",
            marginBottom: "15px"
          }}>
            <label style={{ 
              fontSize: "clamp(12px, 2.5vw, 14px)", 
              display: "inline-flex", 
              alignItems: "center",
              color: "white",
              whiteSpace: "nowrap"
            }}>
              <input
                type="checkbox"
                checked={privacyMode}
                onChange={(e) => setPrivacyMode(e.target.checked)}
                style={{ marginRight: "8px" }}
              />
              Privacy Mode
            </label>
            
            <label style={{ 
              fontSize: "clamp(12px, 2.5vw, 14px)", 
              display: "inline-flex", 
              alignItems: "center",
              color: "white",
              whiteSpace: "nowrap"
            }}>
              <input
                type="checkbox"
                checked={isMuted}
                onChange={(e) => setIsMuted(e.target.checked)}
                style={{ marginRight: "8px" }}
              />
              Mute Voice
            </label>
            
            <label style={{ 
              fontSize: "clamp(12px, 2.5vw, 14px)", 
              display: "inline-flex", 
              alignItems: "center",
              color: "white",
              whiteSpace: "nowrap"
            }}>
              <input
                type="checkbox"
                checked={speakReply}
                onChange={(e) => setSpeakReply(e.target.checked)}
                style={{ marginRight: "8px" }}
              />
              Speak Avatar Reply
            </label>

            <label style={{ 
              fontSize: "clamp(12px, 2.5vw, 14px)", 
              display: "inline-flex", 
              alignItems: "center",
              color: "white",
              whiteSpace: "nowrap"
            }}>
              Voice Gender:
              <select
                value={voiceGender}
                onChange={(e) => setVoiceGender(e.target.value)}
                style={{
                  padding: "4px 8px",
                  borderRadius: "6px",
                  border: "1px solid rgba(255, 255, 255, 0.3)",
                  background: "rgba(255, 255, 255, 0.9)",
                  marginLeft: "8px",
                  fontSize: "clamp(12px, 2.5vw, 14px)"
                }}
              >
                <option value="female">Female</option>
                <option value="male">Male</option>
              </select>
            </label>
          </div>

          {/* Controls Row */}
          <div style={{
            display: "flex",
            gap: "10px",
            alignItems: "center",
            flexWrap: "wrap",
            justifyContent: "center"
          }}>
            {/* Talk to Avatar Button */}
            <button
              onClick={talkToAvatar}
              disabled={["listening", "processing", "speaking"].includes(currentPhase) || !backendConnected}
              style={{
                padding: "12px 20px",
                background: !backendConnected ? "#999" : 
                          healthData?.status === "healthy" ? "#4CAF50" : 
                          healthData?.status === "degraded" ? "#FFC107" : 
                          ["listening", "processing", "speaking"].includes(currentPhase) ? "#999" : 
                          "#F44336",
                color: "#fff",
                border: "none",
                borderRadius: "25px",
                fontSize: "clamp(12px, 2.5vw, 16px)",
                cursor: ["listening", "processing", "speaking"].includes(currentPhase) || !backendConnected ? "not-allowed" : "pointer",
                boxShadow: "0 4px 15px rgba(0, 0, 0, 0.2)",
                transition: "all 0.3s ease",
                whiteSpace: "nowrap"
              }}
            >
              {!backendConnected ? "❌ Backend Offline" :
                currentPhase === "listening" ? "🎤 Listening..." :
                currentPhase === "processing" ? "🧠 Thinking..." :
                currentPhase === "speaking" ? "🔊 Responding..." :
                healthData?.status === "healthy" ? "🎙️ Talk to Avatar" :
                healthData?.status === "degraded" ? "⚠️ Talk to Avatar" :
                "🎙️ Talk to Avatar"} {/* Default to Talk to Avatar even if status is unknown */}
            </button>

            {/* Message Input */}
            <input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type a message to the avatar..."
              onKeyPress={(e) => e.key === 'Enter' && sendToLLM(message, speakReply, voiceGender, privacyMode)}
              style={{
                flex: 1,
                minWidth: "150px",
                padding: "12px",
                fontSize: "clamp(12px, 2.5vw, 16px)",
                borderRadius: "8px",
                border: "1px solid rgba(255, 255, 255, 0.3)",
                background: "rgba(255, 255, 255, 0.9)",
                color: "#333",
                boxSizing: "border-box"
              }}
            />

            {/* Send Button */}
            <button
              onClick={() => sendToLLM(message, speakReply, voiceGender, privacyMode)}
              disabled={!backendConnected}
              style={{
                padding: "12px 20px",
                backgroundColor: backendConnected ? "#007bff" : "#ccc",
                color: "#fff",
                border: "none",
                borderRadius: "8px",
                cursor: backendConnected ? "pointer" : "not-allowed",
                fontSize: "clamp(12px, 2.5vw, 16px)",
                whiteSpace: "nowrap",
                boxShadow: "0 4px 15px rgba(0, 0, 0, 0.2)",
                transition: "all 0.3s ease"
              }}
            >
              Send to Avatar
            </button>

            {/* Clear Button */}
            <button
              onClick={clearMessage}
              style={{
                padding: "12px 16px",
                backgroundColor: "#6c757d",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer",
                fontSize: "clamp(12px, 2.5vw, 16px)",
                whiteSpace: "nowrap",
                boxShadow: "0 4px 15px rgba(0, 0, 0, 0.2)",
                transition: "all 0.3s ease"
              }}
            >
              Clear
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserInterface;