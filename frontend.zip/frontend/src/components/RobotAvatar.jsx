import React, { useEffect, useState, useRef } from "react";
import { motion, useAnimation } from "framer-motion";
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

const emotionColors = {
  happy: "#FFD700",      // Bright gold for happiness
  sad: "#87CEEB",        // Light blue for sadness
  angry: "#FF6347",      // Red for anger
  surprise: "#FF69B4",   // Pink for surprise (matching backend)
  fear: "#9370DB",       // Purple for fear
  disgust: "#98FB98",    // Light green for disgust
  neutral: "#FFA500",    // Orange for neutral
};

const RobotAvatar = ({
  emotion = "neutral",
  isSpeaking = false,
  valence = 0,
  isThinking = false,
  emotionContextEnabled = true,
}) => {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const robotRef = useRef(null);
  const headRef = useRef(null);
  const leftEyeRef = useRef(null);
  const rightEyeRef = useRef(null);
  const mouthRef = useRef(null);
  const leftEyebrowRef = useRef(null);
  const rightEyebrowRef = useRef(null);
  const leftArmRef = useRef(null);
  const rightArmRef = useRef(null);
  const auraRef = useRef(null);
  const animationFrameRef = useRef(null);

  // Additional refs for more complex mouth expressions
  const mouthGroupRef = useRef(null);
  const tearRef = useRef(null);

  const [blink, setBlink] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  // Use neutral emotion when emotion context is disabled
  const effectiveEmotion = emotionContextEnabled ? emotion : "neutral";
  const faceColor = emotionColors[effectiveEmotion] || emotionColors.neutral;

  // Initialize Three.js scene
  useEffect(() => {
    if (!mountRef.current || isInitialized) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 475 / 450, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    
    renderer.setSize(475, 450);
    renderer.setClearColor(0x000000, 0);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    mountRef.current.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.8);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.0);
    directionalLight.position.set(5, 10, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    // Robot group
    const robot = new THREE.Group();
    robot.scale.set(1.0, 1.0, 1.0);
    
    const buildRoboticArm = (side = "left") => {
      const isLeft = side === "left";
      const sign = isLeft ? -1 : 1;

      // Bright green robotic arm material
      const armMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x4ade80, // Bright green like in the image
        shininess: 100 
      });
      
      // Dark joint material
      const jointMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x374151, // Dark gray/blue for joints
        shininess: 50 
      });

      // Black fingertip material
      const fingertipMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x000000,
        shininess: 30 
      });

      // Create a continuous arm group that flows together
      const armGroup = new THREE.Group();
      
      // Upper arm - tapering to match lower arm connection
      const upperArmGeometry = new THREE.CylinderGeometry(0.16, 0.18, 1.0, 16);
      const upperArm = new THREE.Mesh(upperArmGeometry, armMaterial);
      upperArm.position.set(0, -0.0, 0); // Half of its height down
      armGroup.add(upperArm);

      // Elbow joint band - seamlessly connecting upper and lower arm
      const elbowBandGeometry = new THREE.CylinderGeometry(0.16, 0.16, 0.15, 16);
      const elbowBand = new THREE.Mesh(elbowBandGeometry, jointMaterial);
      elbowBand.position.set(0, -0.575, 0); // -0.5 (bottom of upper arm) - 0.075 (half of band height)
      armGroup.add(elbowBand);

      // Forearm - continuous with upper arm
      const forearmGeometry = new THREE.CylinderGeometry(0.16, 0.16, 1.0, 16);
      const forearm = new THREE.Mesh(forearmGeometry, armMaterial);
      forearm.position.set(0, -1.075, 0); // -1.075 (bottom of band) - 0.5 (half of forearm)
      armGroup.add(forearm);

      // Wrist joint band - seamless connection to hand
      const wristBandGeometry = new THREE.CylinderGeometry(0.16, 0.16, 0.12, 16);
      const wristBand = new THREE.Mesh(wristBandGeometry, jointMaterial);
      wristBand.position.set(0, -1.635, 0); // -1.575 - 0.5 (forearm half) - 0.06 (half of wrist band)
      armGroup.add(wristBand);

      // Hand/Palm - flows from wrist
      const handGeometry = new THREE.BoxGeometry(0.35, 0.5, 0.2);
      const hand = new THREE.Mesh(handGeometry, armMaterial);
      hand.position.set(0, -1.935, 0); // -2.135 - 0.06 (wrist half) - 0.25 (half of hand height)
      armGroup.add(hand);

      // Position and orient the entire arm group
      armGroup.position.set(sign * 1.7, 0.2, 0);
      armGroup.rotation.z = sign * 0.25; // Unified rotation for the entire arm
      robot.add(armGroup);

      // Finger joint bands around the hand
      const fingerJointGeometry = new THREE.CylinderGeometry(0.18, 0.18, 0.08, 16);
      const fingerJoint = new THREE.Mesh(fingerJointGeometry, jointMaterial);
      fingerJoint.position.set(sign * 2.25, -1.82, 0);
      fingerJoint.rotation.z = sign * 0.3;
      robot.add(fingerJoint);

      // Create 5 robotic fingers
      const fingerPositions = [
        { x: 0.12, y: 0.05, z: 0.08, name: 'thumb', rotation: -0.6 },
        { x: 0.08, y: -0.15, z: 0.05, name: 'index', rotation: 0 },
        { x: 0.02, y: -0.18, z: 0.02, name: 'middle', rotation: 0 },
        { x: -0.04, y: -0.16, z: 0, name: 'ring', rotation: 0 },
        { x: -0.1, y: -0.12, z: -0.02, name: 'pinky', rotation: 0.2 }
      ];

      fingerPositions.forEach((finger, index) => {
        const baseX = sign * 2.25 + sign * finger.x;
        const baseY = -1.85 + finger.y;
        const baseZ = finger.z;

        // Proximal segment (base of finger)
        const proximalGeometry = new THREE.CylinderGeometry(0.035, 0.04, 0.2, 8);
        const proximal = new THREE.Mesh(proximalGeometry, armMaterial);
        proximal.position.set(baseX, baseY, baseZ);
        proximal.rotation.z = sign * (0.3 + finger.rotation);
        if (finger.name === 'thumb') {
          proximal.rotation.x = 0.4;
        }
        robot.add(proximal);

        // Middle segment
        const middleGeometry = new THREE.CylinderGeometry(0.03, 0.035, 0.18, 8);
        const middle = new THREE.Mesh(middleGeometry, armMaterial);
        middle.position.set(
          baseX + sign * (finger.name === 'thumb' ? 0.06 : 0.02),
          baseY - 0.15,
          baseZ + (finger.name === 'thumb' ? 0.08 : 0)
        );
        middle.rotation.z = sign * (0.3 + finger.rotation);
        if (finger.name === 'thumb') {
          middle.rotation.x = 0.3;
        }
        robot.add(middle);

        // Distal segment (fingertip)
        const distalGeometry = new THREE.CylinderGeometry(0.025, 0.03, 0.15, 8);
        const distal = new THREE.Mesh(distalGeometry, armMaterial);
        distal.position.set(
          baseX + sign * (finger.name === 'thumb' ? 0.1 : 0.03),
          baseY - 0.28,
          baseZ + (finger.name === 'thumb' ? 0.12 : 0)
        );
        distal.rotation.z = sign * (0.3 + finger.rotation);
        if (finger.name === 'thumb') {
          distal.rotation.x = 0.2;
        }
        robot.add(distal);

        // Black fingertip
        const fingertipGeometry = new THREE.SphereGeometry(0.03, 8, 8);
        const fingertip = new THREE.Mesh(fingertipGeometry, fingertipMaterial);
        fingertip.position.set(
          baseX + sign * (finger.name === 'thumb' ? 0.12 : 0.04),
          baseY - 0.35,
          baseZ + (finger.name === 'thumb' ? 0.15 : 0)
        );
        fingertip.scale.set(1, 1.2, 1);
        robot.add(fingertip);
      });

      if (isLeft) {
        leftArmRef.current = upperArm;
      } else {
        rightArmRef.current = upperArm;
      }
    };

    // Head (rounded cube to match the image)
    const radius = 0.3; // corner radius
    const segments = 4; // smoothness

    const headGeometry = new RoundedBoxGeometry(2.2, 2.2, 2.0, segments, radius);
    const headMaterial = new THREE.MeshPhongMaterial({
      color: new THREE.Color(faceColor),
      shininess: 50
    });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 1.8;
    head.castShadow = true;
    robot.add(head);
    headRef.current = head;

    // Side panels (ears) like in the image
    const earGeometry = new THREE.BoxGeometry(0.3, 1.0, 0.8);
    const earMaterial = new THREE.MeshPhongMaterial({ color: 0x333333 });
    
    const leftEar = new THREE.Mesh(earGeometry, earMaterial);
    leftEar.position.set(-1.25, 1.8, 0);
    robot.add(leftEar);
    
    const rightEar = new THREE.Mesh(earGeometry, earMaterial);
    rightEar.position.set(1.25, 1.8, 0);
    robot.add(rightEar);

    // Eyes (oval shaped like in the image)
    const eyeGeometry = new THREE.SphereGeometry(0.25, 16, 8);
    const eyeMaterial = new THREE.MeshPhongMaterial({ color: 0x000000 });
    
    const leftEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    leftEye.position.set(-0.5, 2.0, 0.95);
    leftEye.scale.set(1, 1.5, 0.8);
    robot.add(leftEye);
    leftEyeRef.current = leftEye;
    
    const rightEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    rightEye.position.set(0.5, 2.0, 0.95);
    rightEye.scale.set(1, 1.5, 0.8); 
    robot.add(rightEye);
    rightEyeRef.current = rightEye;

    // Eyebrows
    const eyebrowGeometry = new THREE.TorusGeometry(0.4, 0.05, 8, 16, Math.PI * 0.75);
    const eyebrowMaterial = new THREE.MeshPhongMaterial({ color: 0x000000 });
    
    const leftEyebrow = new THREE.Mesh(eyebrowGeometry, eyebrowMaterial);
    leftEyebrow.position.set(-0.5, 2.0, 0.95);
    leftEyebrow.rotation.z = 0; 
    robot.add(leftEyebrow);
    leftEyebrowRef.current = leftEyebrow;
    
    const rightEyebrow = new THREE.Mesh(eyebrowGeometry, eyebrowMaterial);
    rightEyebrow.position.set(0.5, 2.0, 0.95);  
    rightEyebrow.rotation.z = 0;  
    robot.add(rightEyebrow);
    rightEyebrowRef.current = rightEyebrow;

    // Enhanced mouth system - create a group for complex mouth expressions
    const mouthGroup = new THREE.Group();
    mouthGroup.position.set(0, 1.4, 0.95);
    robot.add(mouthGroup);
    mouthGroupRef.current = mouthGroup;

    // Main mouth (curved)
    const mouthGeometry = new THREE.TorusGeometry(0.4, 0.08, 8, 16, Math.PI);
    const mouthMaterial = new THREE.MeshPhongMaterial({ color: 0x000000 });
    const mouth = new THREE.Mesh(mouthGeometry, mouthMaterial);
    mouthGroup.add(mouth);
    mouthRef.current = mouth;

    // Tear for sad emotion (initially hidden)
    const tearGeometry = new THREE.SphereGeometry(0.08, 8, 8);
    const tearMaterial = new THREE.MeshPhongMaterial({ 
      color: 0x87ceeb, 
      transparent: true, 
      opacity: 0 
    });
    const tear = new THREE.Mesh(tearGeometry, tearMaterial);
    tear.position.set(-0.7, 0.5, 0.1); // Below left eye
    robot.add(tear);
    tearRef.current = tear;

    // Call buildRoboticArm after function is declared
    buildRoboticArm("left");
    buildRoboticArm("right");

    // Body (more rectangular like in the image)
    const bodyGeometry = new THREE.BoxGeometry(2.8, 2.0, 1.8);
    const bodyMaterial = new THREE.MeshPhongMaterial({ color: 0xaaaaaa });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.position.y = -0.2;
    body.castShadow = true;
    robot.add(body);

    // Base (more like the image)
    const baseGeometry = new THREE.CylinderGeometry(1.2, 1.4, 0.8);
    const baseMaterial = new THREE.MeshPhongMaterial({ color: 0x666666 });
    const base = new THREE.Mesh(baseGeometry, baseMaterial);
    base.position.y = -1.8;
    base.castShadow = true;
    robot.add(base);

    // Aura (large transparent sphere)
    const auraGeometry = new THREE.SphereGeometry(4.0);
    const auraMaterial = new THREE.MeshPhongMaterial({ 
      color: 0xffa500, 
      transparent: true, 
      opacity: 0.1,
      side: THREE.DoubleSide
    });
    const aura = new THREE.Mesh(auraGeometry, auraMaterial);
    robot.add(aura);
    auraRef.current = aura;

    scene.add(robot);
    camera.position.z = 7;
    camera.position.y = 1;

    sceneRef.current = scene;
    rendererRef.current = renderer;
    robotRef.current = robot;

    // Animation loop
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);
      
      // Gentle rotation
      if (robotRef.current) {
        robotRef.current.rotation.y = Math.sin(Date.now() * 0.001) * 0.1;
      }
      
      renderer.render(scene, camera);
    };
    animate();

    setIsInitialized(true);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Update emotion colors and expressions
  useEffect(() => {
    if (!headRef.current || !mouthRef.current || !leftEyeRef.current || !rightEyeRef.current) return;
    
    const color = new THREE.Color(faceColor);
    headRef.current.material.color = color;

    // Update eyebrow positions based on emotion - more pronounced expressions
    if (leftEyebrowRef.current && rightEyebrowRef.current) {
      const eyebrowRotations = {
        happy: { left: 0.4, right: -0.4 }, // More raised eyebrows for happiness
        sad: { left: -0.5, right: 0.5 }, // More droopy eyebrows for sadness
        angry: { left: -0.8, right: 0.8 }, // More furrowed brows for anger
        surprise: { left: 0.7, right: -0.7 }, // Very raised for surprise
        fear: { left: 0.5, right: -0.5 }, // Raised with worry for fear
        disgust: { left: -0.4, right: 0.4 }, // Furrowed for disgust
        neutral: { left: 0, right: 0 },
      };
      
      const rotations = eyebrowRotations[effectiveEmotion] || eyebrowRotations.neutral;
      leftEyebrowRef.current.rotation.z = rotations.left;
      rightEyebrowRef.current.rotation.z = rotations.right;
    }

    // Enhanced eye expressions based on emotion - more pronounced
    if (leftEyeRef.current && rightEyeRef.current) {
      const eyeExpressions = {
        happy: { scaleX: 0.6, scaleY: 0.9 }, // More squinting from smiling
        sad: { scaleX: 1.1, scaleY: 1.4 }, // Wider, sadder eyes
        angry: { scaleX: 0.7, scaleY: 0.8 }, // More narrowed angry eyes
        surprise: { scaleX: 1.2, scaleY: 1.6 }, // Wide surprise eyes (reduced size)
        fear: { scaleX: 1.3, scaleY: 1.7 }, // Wide fearful eyes
        disgust: { scaleX: 0.8, scaleY: 1.0 }, // More narrowed for disgust
        neutral: { scaleX: 1.0, scaleY: 1.2 },
      };
      
      const eyeExp = eyeExpressions[effectiveEmotion] || eyeExpressions.neutral;
      leftEyeRef.current.scale.set(eyeExp.scaleX, eyeExp.scaleY, 0.8);
      rightEyeRef.current.scale.set(eyeExp.scaleX, eyeExp.scaleY, 0.8);
    }

    // Enhanced mouth shapes and positions based on emotion - more pronounced
    if (mouthRef.current && mouthGroupRef.current) {
      const mouthExpressions = {
        happy: { 
          rotation: Math.PI, // Downward curve (frown)
          scaleX: 1.1, 
          scaleY: 1.1, 
          positionY: 1.4 
        },
        sad: { 
          rotation: 0, // Upward curve (smile)
          scaleX: 0.8, 
          scaleY: 0.8, 
          positionY: 1.3 
        },
        angry: { 
          rotation: Math.PI * 0.5, // Open "O" shape (current surprise mouth)
          scaleX: 0.8, 
          scaleY: 1.8, 
          positionY: 1.35 
        },
        surprise: { 
          rotation: Math.PI * 0.5, // Eye-like shape
          scaleX: 0.4, 
          scaleY: 0.6, 
          positionY: 1.35 
        },
        fear: { 
          rotation: Math.PI * 1.15, // More pronounced downward with worry
          scaleX: 0.8, 
          scaleY: 0.8, 
          positionY: 1.3 
        },
        disgust: { 
          rotation: Math.PI * 0.8, // More twisted expression
          scaleX: 0.6, 
          scaleY: 0.8, 
          positionY: 1.35 
        },
        neutral: { 
          rotation: Math.PI * 0.5, // Straight line
          scaleX: 1.0, 
          scaleY: 0.6, 
          positionY: 1.4 
        },
      };
      
      const mouthExp = mouthExpressions[effectiveEmotion] || mouthExpressions.neutral;
      mouthRef.current.rotation.x = mouthExp.rotation;
      
      // Scale mouth for speaking and emotion (smart scaling)
      let speakingScale = 1.0;
      if (isSpeaking) {
        // Don't apply speaking scale to emotions that already have large mouths
        if (effectiveEmotion === 'happy' || effectiveEmotion === 'surprise') {
          speakingScale = 1.0; // No additional scaling for happy/surprise
        } else {
          speakingScale = 1.1; // Small scaling for other emotions
        }
      }
      
      mouthRef.current.scale.set(
        mouthExp.scaleX * speakingScale, 
        mouthExp.scaleY * speakingScale, 
        speakingScale
      );
      
      mouthGroupRef.current.position.y = mouthExp.positionY;
    }

    // Show/hide tear for sad emotion - more pronounced
    if (tearRef.current) {
      if (effectiveEmotion === 'sad') {
        tearRef.current.material.opacity = 1.0; // More visible tear
      } else {
        tearRef.current.material.opacity = 0;
      }
    }

  }, [emotion, faceColor, isSpeaking, emotionContextEnabled]);

  // Blinking effect
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 150);
    }, 4000);
    return () => clearInterval(blinkInterval);
  }, []);

  useEffect(() => {
    if (leftEyeRef.current && rightEyeRef.current) {
      if (blink) {
        leftEyeRef.current.scale.y = 0.1;
        rightEyeRef.current.scale.y = 0.1;
      } else {
        // Restore emotion-specific eye scaling when not blinking
        const eyeExpressions = {
          happy: { scaleY: 0.9 },
          sad: { scaleY: 1.4 },
          angry: { scaleY: 0.8 },
          surprise: { scaleY: 1.6 },
          fear: { scaleY: 1.7 },
          disgust: { scaleY: 1.0 },
          neutral: { scaleY: 1.2 },
        };
        
        const eyeExp = eyeExpressions[effectiveEmotion] || eyeExpressions.neutral;
        leftEyeRef.current.scale.y = eyeExp.scaleY;
        rightEyeRef.current.scale.y = eyeExp.scaleY;
      }
    }
  }, [blink, emotion, emotionContextEnabled]);

  // Arm movement animation
  useEffect(() => {
    if (!leftArmRef.current || !rightArmRef.current) return;
    
    const animateArms = () => {
      const time = Date.now() * 0.002;
      leftArmRef.current.rotation.z = 0.2 + Math.sin(time) * 0.05;
      rightArmRef.current.rotation.z = -0.2 - Math.sin(time) * 0.05;
    };
    
    const interval = setInterval(animateArms, 16);
    return () => clearInterval(interval);
  }, []);

  // Head nodding based on valence
  useEffect(() => {
    if (!headRef.current) return;
    
    const animateHead = () => {
      const time = Date.now() * 0.003;
      const nodAngle = (valence * 0.3) + Math.sin(time) * 0.1;
      headRef.current.rotation.x = nodAngle;
    };
    
    const interval = setInterval(animateHead, 16);
    return () => clearInterval(interval);
  }, [valence]);

  // Aura pulsing effect
  useEffect(() => {
    if (!auraRef.current) return;
    
    const animateAura = () => {
      const time = Date.now() * 0.002;
      const pulseScale = 0.8 + (Math.abs(valence) * 0.2) + Math.sin(time) * 0.1;
      const pulseOpacity = 0.1 + Math.abs(valence) * 0.3;
      
      auraRef.current.scale.set(pulseScale, pulseScale, pulseScale);
      auraRef.current.material.opacity = pulseOpacity;
    };
    
    const interval = setInterval(animateAura, 16);
    return () => clearInterval(interval);
  }, [valence]);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px",
        position: "relative",
        width: "475px",
        height: "450px",
      }}
    >
      <div
        ref={mountRef}
        style={{
          width: "475px",
          height: "450px",
        }}
      />

      {isThinking && (
        <motion.div
          style={{
            position: "absolute",
            top: "10px",
            left: "50%",
            transform: "translateX(-50%)",
            fontSize: "1rem",
            color: "#666",
            background: "rgba(255,255,255,0.9)",
            padding: "8px 16px",
            borderRadius: "20px",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255,255,255,0.3)",
            boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
          }}
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 1.2, repeat: Infinity }}
        >
          Thinking...
        </motion.div>
      )}

      {/* Demo Controls */}
      <div style={{
        position: "absolute",
        bottom: "10px",
        left: "10px",
        display: "flex",
        gap: "10px",
        flexWrap: "wrap"
      }}>
        {Object.keys(emotionColors).map(emotionKey => (
          <button
            key={emotionKey}
            onClick={() => {
              // This is just for demo - in real usage these would be props
              const event = new CustomEvent('emotionChange', { detail: emotionKey });
              window.dispatchEvent(event);
            }}
            style={{
              padding: "4px 8px",
              fontSize: "10px",
              backgroundColor: emotionColors[emotionKey],
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
              color: emotionKey === 'neutral' ? 'black' : 'white'
            }}
          >
            {emotionKey}
          </button>
        ))}
      </div>
    </div>
  );
};

export default RobotAvatar;