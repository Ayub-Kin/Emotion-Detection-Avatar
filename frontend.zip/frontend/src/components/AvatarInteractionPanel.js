import React, { useState } from "react";
import RobotAvatar from "./RobotAvatar";

const AvatarInteractionPanel = () => {
  const [emotion, setEmotion] = useState("neutral");
  const [valence, setValence] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [userInput, setUserInput] = useState("");

  const handleSend = async () => {
    if (!userInput.trim()) return;

    setIsThinking(true); // ⏳ Start thinking

    try {
      // Example request to your Flask backend
      const response = await fetch("http://localhost:5000/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: userInput }),
      });

      const data = await response.json();

      // Expecting something like { emotion: 'happy', valence: 0.8 }
      setEmotion(data.emotion || "neutral");
      setValence(data.valence ?? 0);
    } catch (error) {
      console.error("Error getting emotion:", error);
      setEmotion("neutral");
      setValence(0);
    } finally {
      setIsThinking(false); // ✅ Done thinking
    }
  };

  return (
    <div style={{ textAlign: "center", padding: "20px" }}>
      <h2>Talk to the Avatar</h2>

      <div style={{ display: "flex", justifyContent: "center", gap: "1rem" }}>
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Type your message..."
          style={{ width: "300px", padding: "10px" }}
          disabled={isThinking}
        />

        <button
          onClick={handleSend}
          disabled={isThinking}
          style={{
            padding: "10px 20px",
            backgroundColor: isThinking ? "#ccc" : "#007bff",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: isThinking ? "not-allowed" : "pointer",
          }}
        >
          {isThinking ? "Thinking..." : "Send to Avatar"}
        </button>
      </div>

      <div style={{ marginTop: "40px" }}>
        <RobotAvatar
          emotion={emotion}
          valence={valence}
          isSpeaking={isSpeaking}
          isThinking={isThinking}
        />
      </div>
    </div>
  );
};

export default AvatarInteractionPanel;
