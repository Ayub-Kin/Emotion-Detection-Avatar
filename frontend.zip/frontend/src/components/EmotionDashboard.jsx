import { useEffect, useState, useRef, useMemo  } from "react";
import { Line, Bar, Pie, Doughnut } from "react-chartjs-2";
import ChartDataLabels from 'chartjs-plugin-datalabels';
import 'chart.js/auto';
import { saveAs } from 'file-saver';
import html2canvas from 'html2canvas';
import { Chart } from 'chart.js';
import * as XLSX from 'xlsx';
import { utils as XLSXUtils } from 'xlsx';
import ExcelJS from 'exceljs';
Chart.register(ChartDataLabels);
const SystemStatusIndicator = ({ status, label, tooltip }) => (
    <div 
      style={{ 
        padding: "10px 15px", 
        borderRadius: "5px", 
        backgroundColor: status ? "#d4edda" : "#f8d7da",
        border: `1px solid ${status ? "#c3e6cb" : "#f5c6cb"}`,
        position: "relative",
        cursor: tooltip ? "help" : "default",
        minWidth: "120px",
        textAlign: "center"
      }}
      title={tooltip}
    >
      {status ? "✅" : "❌"} {label}
    </div>
  );
  
const emotionColors = {
  happy: "#4CAF50",
  sad: "#2196F3", 
  angry: "#F44336",
  surprise: "#FF9800",
  fear: "#9C27B0",
  disgust: "#795548",
  neutral: "#9E9E9E"
};

// Define validEmotions globally for use throughout the component
const validEmotions = Object.keys(emotionColors);

// Define tone colors for the chart and legend
const toneColors = {
  shouting: '#F44336', // red
  excited: '#ff9800', // orange
  energetic: '#000000', // black
  engaged: '#59a14f',
  calm: '#4e79a7',
  soft: '#90caf9', // light blue
  low: '#888888', // grey
  neutral: '#bab0ab'
};

const sentimentColors = {
  positive: "#8BC34A",
  negative: "#FF5722",
  neutral: "#607D8B"
};

const EmotionDashboard = ({ performanceMetrics, emotionContextEnabled }) => {
  const [emotionData, setEmotionData] = useState([]);
  const [conversationLogs, setConversationLogs] = useState([]);
  const [systemStatus, setSystemStatus] = useState({});
  const [, setLlmStatus] = useState({});
  const [chartType, setChartType] = useState("line");
  const [dataSource, setDataSource] = useState("emotion");
  const [timeFilter, setTimeFilter] = useState("all");
  const [downloadStatus, setDownloadStatus] = useState("");
  const [lastUpdateHash, setLastUpdateHash] = useState("");
  const [localPerformanceMetrics, setLocalPerformanceMetrics] = useState({});
  const MAX_ENTRIES = 500;
  const chartRef = useRef();
  const pieChartRef = useRef(null);
  const comparisonChartRef = useRef(null);
  const latest = emotionData[emotionData.length - 1] || {};
  const API_BASE_URL = "http://localhost:5000";

  // Define the tones to be used in the Voice Tone chart and legend
  const allTones = [
    "shouting",
    "excited",
    "energetic",
    "engaged",
    "calm",
    "soft",
    "low",
    "neutral"
  ];

  // Move these lines to after latest is defined:
  const usedEmotions = latest?.all_emotions_captured?.filter(e => validEmotions.includes(e)) || [];
  const capturedEmotions = latest?.all_emotions_captured_raw?.filter(e => validEmotions.includes(e)) || [];

  // Track last non-empty values for live status
  const [lastNonEmptyEmotion, setLastNonEmptyEmotion] = useState(null);
  const [lastNonEmptySpeech, setLastNonEmptySpeech] = useState(null);
  const [lastNonEmptyConversation, setLastNonEmptyConversation] = useState(null);
  const [lastEmotionUpdate, setLastEmotionUpdate] = useState(null);

  // Update last non-empty emotion and speech
  useEffect(() => {
    const latest = emotionData[emotionData.length - 1];
    if (latest) {
      setLastEmotionUpdate(new Date(latest.timestamp));
      if (latest.facial_emotion || latest.tone_emotion || latest.text_sentiment) {
        setLastNonEmptyEmotion(latest);
      }
      if (latest.speech_text || latest.transcript || latest.user_message) {
        setLastNonEmptySpeech(latest);
      }
    }
  }, [emotionData]);

  // Update last non-empty conversation
  useEffect(() => {
    if (conversationLogs.length > 0) {
      const firstValid = conversationLogs.find(log => log.user_message || log.llm_reply);
      if (firstValid) {
        setLastNonEmptyConversation(firstValid);
      }
    }
  }, [conversationLogs]);

  // Helper to check if data is stale
  const isEmotionDataStale = () => {
    if (!lastEmotionUpdate) return true;
    return (Date.now() - lastEmotionUpdate.getTime()) > 10000; // 10 seconds
  };

  useEffect(() => {
    fetchEmotionLogs();
    fetchConversationLogs();
    fetchSystemStatus();
    fetchLlmStatus();
    fetchPerformanceMetrics();
  }, [timeFilter, dataSource]);

  // Real-time polling for emotion data
  useEffect(() => {
    const interval = setInterval(() => {
      fetchLatestEmotion();
      fetchSystemStatus();
      fetchPerformanceMetrics();
      fetchConversationLogs();
      fetchEmotionLogs();
    }, 1500); // 1500ms for near real-time updates
    return () => clearInterval(interval);
  }, []);

  // Fetch conversation logs every 7.5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchConversationLogs();
      fetchLlmStatus();
    }, 7500);
    return () => clearInterval(interval);
  }, []);

// Helper for comparison chart
  const getUserVsAvatarEmotionPairs = () => {
    return conversationLogs.map(log => ({
      timestamp: new Date(log.timestamp).toLocaleTimeString("en-US", { hour12: false }),
      userEmotion: log.tone_emotion || log.text_sentiment || "neutral",
      avatarTone: log.llm_reply_tone || "neutral"
    }));
  };

  const exportUserVsAvatarChart = () => {
    if (!comparisonChartRef.current) return;

    html2canvas(comparisonChartRef.current).then(canvas => {
      canvas.toBlob(blob => {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        saveAs(blob, `user_vs_avatar_comparison_${timestamp}.png`);
      });
    });
  };
  const emotionScale = {
    angry: 1,
    sad: 2,
    neutral: 3,
    happy: 4,
    cheerful: 5,
    calm: 4,
    excited: 5,
    fearful: 1,
    disgust: 1,
    bored: 2, 
    engaged: 4
  };

  const comparisonData = getUserVsAvatarEmotionPairs();

  const userVsAvatarChartData = {
    labels: comparisonData.map(entry => entry.timestamp),
    datasets: [
      {
        label: "User Emotion",
        data: comparisonData.map(entry => emotionScale[entry.userEmotion] || 3),
        backgroundColor: "#2196F3"
      },
      {
        label: "Avatar Response Tone",
        data: comparisonData.map(entry => emotionScale[entry.avatarTone] || 3),
        backgroundColor: "#FF9800"
      }
    ]
  };

  const fetchEmotionLogs = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/emotion`);
      const newData = await response.json();
      
      // Skip if invalid or error
      if (newData.status === "error" || !newData.is_valid) return;
      
      // Simple hash to detect actual changes
      const newHash = `${newData.facial_emotion}-${newData.tone_emotion}-${newData.update_timestamp}`;
      
      if (newHash !== lastUpdateHash) {
        setLastUpdateHash(newHash);
        
        setEmotionData(prev => {
          const newEntry = {
            facial_emotion: newData.facial_emotion,
            tone_emotion: newData.tone_emotion,
            text_sentiment: newData.text_sentiment,
            timestamp: newData.update_timestamp,
            confidence: newData.face_confidence,
            emotion_confidence: newData.emotion_confidence,
            face_detected: newData.face_detected,
            all_emotions_captured: newData.all_emotions_captured,
            all_emotions_captured_raw: newData.all_emotions_captured_raw,
            tone_analysis_details: newData.tone_analysis_details
          };
          
          return [...prev.slice(-99), newEntry]; // Max 100 entries
        });
      }
    } catch (err) {
      console.error("Emotion update error:", err);
    }
  };

  const fetchConversationLogs = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/conversation_logs`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data.logs && Array.isArray(data.logs)) {
        // Keep only the latest 50 logs
        const latestLogs = data.logs.slice(0, 50);
        setConversationLogs(latestLogs);
      }
    } catch (err) {
      console.error("Conversation logs fetch error:", err);
    }
  };

  const fetchLatestEmotion = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/emotion`);
      const newData = await response.json();
      
      // Handle 'no_change' status
      if (newData.status === "no_change") return;
      
      setEmotionData(prev => {
        // Update only if new emotion detected
        const last = prev[prev.length - 1];
        if (!last || last.facial_emotion !== newData.facial_emotion) {
          return [...prev.slice(-MAX_ENTRIES), newData];
        }
        return prev;
      });
    } catch (err) {
      console.error("Live emotion fetch error:", err);
    }
  };

  const fetchSystemStatus = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/health");
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();
      
      // Use the data from the health endpoint directly
      setSystemStatus({
        status: data.status,
        components: {
          emotion_detector: data.components?.emotion_detector || false,
          ollama: data.components?.ollama || { connected: false },
          mongodb: data.components?.mongodb || false
        }
      });
    } catch (err) {
      console.error("System status fetch error:", err);
      setSystemStatus({
        status: "error",
        components: {
          emotion_detector: false,
          ollama: { connected: false },
          mongodb: false
        }
      });
    }
  };

  const fetchLlmStatus = async () => {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000); // 5s timeout
      
      const response = await fetch(`${API_BASE_URL}/llm_status`, {
        signal: controller.signal
      });
      
      clearTimeout(timeout);
      
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      
      const data = await response.json();
      setLlmStatus({
        status: data.components?.ollama?.connected ? "connected" : "disconnected",
        ollama_status: data.components?.ollama?.connected ? "connected" : "disconnected",
        error: null
      });
    } catch (err) {
      if (err.name !== 'AbortError') {
        console.error("LLM status check error:", err);  
      }
      setLlmStatus({
        status: "error",
        ollama_status: "disconnected",
        error: err.message.includes("timeout") ? "Connection timeout" : err.message
      });
    }
  };
  
  const fetchPerformanceMetrics = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/performance_metrics`);
      if (response.ok) {
        const data = await response.json();
        // Get metrics from nested property
        if (data.metrics) {
          setLocalPerformanceMetrics(data.metrics);
        }
      }
    } catch (err) {
      console.error("Performance metrics fetch error:", err);
    }
  };

  const getFilteredData = () => {
    const data = dataSource === "emotion" ? emotionData : conversationLogs;
    if (timeFilter === "all") return data;
    
    const now = new Date();
    const durationMap = { "15min": 15, "30min": 30, "1hr": 60, "6hr": 360 };
    const cutoff = new Date(now - durationMap[timeFilter] * 60 * 1000);
    
    return data.filter(item => new Date(item.timestamp) > cutoff);
  };

  const filteredData = getFilteredData();

  const emotionIntensityMap = {
    happy: "HIGH POSITIVE",
    surprise: "POSITIVE",
    engaged: "POSITIVE",
    excited: "HIGH POSITIVE",
    energetic: "HIGH POSITIVE",
    neutral: "NEUTRAL",
    calm: "NEUTRAL",
    none: "NEUTRAL",
    sad: "NEGATIVE",
    angry: "NEGATIVE",
    fear: "LOW",
    disgust: "LOW",
    bored: "LOW",
    low: "LOW"
  };
  const sentimentIntensityMap = {
    positive: "POSITIVE",
    neutral: "NEUTRAL",
    negative: "NEGATIVE"
  };

  function getTrendForIntensity(intensity, field = "facial_emotion", timeWindowMinutes = 60) {
    const now = Date.now();
    const ms = 60 * 1000;
    const recent = emotionData.filter(e => new Date(e.timestamp) > now - timeWindowMinutes * ms);
    const prev = emotionData.filter(e =>
      new Date(e.timestamp) <= now - timeWindowMinutes * ms &&
      new Date(e.timestamp) > now - 2 * timeWindowMinutes * ms
    );
    const map = field === "sentiment" ? sentimentIntensityMap : emotionIntensityMap;
    const getIntensity = e => map[e[field]] || "NEUTRAL";
    const recentCount = recent.filter(e => getIntensity(e) === intensity).length;
    const prevCount = prev.filter(e => getIntensity(e) === intensity).length;
    const percentChange = prevCount === 0 ? 100 : ((recentCount - prevCount) / prevCount) * 100;
    return { recentCount, prevCount, percentChange };
  }

  function detectSpike(intensity, field = "facial_emotion", windowMinutes = 10, threshold = 2) {
    const now = Date.now();
    const ms = 60 * 1000;
    const recent = emotionData.filter(e => new Date(e.timestamp) > now - windowMinutes * ms);
    const prev = emotionData.filter(e => new Date(e.timestamp) <= now - windowMinutes * ms && new Date(e.timestamp) > now - 2 * windowMinutes * ms);
    const map = field === "sentiment" ? sentimentIntensityMap : emotionIntensityMap;
    const getIntensity = e => map[e[field]] || "NEUTRAL";
    const recentCount = recent.filter(e => getIntensity(e) === intensity).length;
    const prevCount = prev.filter(e => getIntensity(e) === intensity).length;
    return prevCount > 0 && recentCount / prevCount > threshold;
  }

  // Overlay and correlation chart data
  const bucketSizeMinutes = 10;
  const bucketCount = 7;
  const nowTs = Date.now();
  const ms = 60 * 1000;
  const buckets = Array.from({ length: bucketCount + 1 }, (_, i) => nowTs - (bucketCount - i) * bucketSizeMinutes * ms);
  const timeLabels = buckets.slice(0, -1).map(ts => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
  function countInBucket(bucketStart, bucketEnd, field, value, map) {
    return emotionData.filter(e =>
      new Date(e.timestamp) >= bucketStart &&
      new Date(e.timestamp) < bucketEnd &&
      (map ? map[e[field]] === value : e[field] === value)
    ).length;
  }
  const happyCounts = buckets.slice(0, -1).map((ts, i) => countInBucket(ts, buckets[i + 1], "facial_emotion", "HIGH POSITIVE", emotionIntensityMap));
  const calmCounts = buckets.slice(0, -1).map((ts, i) => countInBucket(ts, buckets[i + 1], "tone_emotion", "NEUTRAL", emotionIntensityMap));
  const positiveCounts = buckets.slice(0, -1).map((ts, i) => countInBucket(ts, buckets[i + 1], "text_sentiment", "POSITIVE", sentimentIntensityMap));
  const llmTimes = buckets.slice(0, -1).map((ts, i) => {
    const entries = emotionData.filter(e => new Date(e.timestamp) >= ts && new Date(e.timestamp) < buckets[i + 1]);
    return entries.reduce((sum, e) => sum + (e.timing?.llm_time || 0), 0) / (entries.length || 1);
  });
  const overlayChartData = {
    labels: timeLabels,
    datasets: [
      { label: "Facial (High Positive)", data: happyCounts, borderColor: "green", fill: false },
      { label: "Tone (Neutral)", data: calmCounts, borderColor: "blue", fill: false },
      { label: "Sentiment (Positive)", data: positiveCounts, borderColor: "orange", fill: false }
    ]
  };
  const correlationChartData = {
    labels: timeLabels,
    datasets: [
      { label: "Facial (High Positive)", data: happyCounts, borderColor: "green", fill: false, yAxisID: 'y' },
      { label: "LLM Response Time (s)", data: llmTimes, borderColor: "red", fill: false, yAxisID: 'y1' }
    ]
  };

  const getEmotionStats = () => {
    // Use a Map for more reliable counting
    const facialCounts = new Map();
    const toneCounts = new Map();
    const sentimentCounts = new Map();

    // Only use the tones you want to display
    allTones.forEach(t => toneCounts.set(t, 0));
    Object.keys(emotionColors).forEach(e => facialCounts.set(e, 0));
    Object.keys(sentimentColors).forEach(s => sentimentCounts.set(s, 0));

    // Count occurrences
    emotionData.forEach(entry => {
      if (entry.facial_emotion) {
        facialCounts.set(
          entry.facial_emotion, 
          (facialCounts.get(entry.facial_emotion) || 0) + 1
        );
      }
      // Use only the tone_emotion field, which is set by analyze_tone_from_audio
      if (entry.tone_emotion && allTones.includes(entry.tone_emotion)) {
        toneCounts.set(
          entry.tone_emotion,
          (toneCounts.get(entry.tone_emotion) || 0) + 1
        );
      }
      if (entry.text_sentiment) {
        sentimentCounts.set(
          entry.text_sentiment,
          (sentimentCounts.get(entry.text_sentiment) || 0) + 1
        );
      }
    });

    return {
      facialEmotions: Object.fromEntries(facialCounts),
      toneEmotions: Object.fromEntries(toneCounts),
      textSentiments: Object.fromEntries(sentimentCounts)
    };
  };

  const getConversationStats = () => {
    if (dataSource === "emotion") return {};
    
    const totalInteractions = filteredData.length;
    const successfulTts = filteredData.filter(item => item.tts_success).length;
    const avgLlmTime = filteredData.reduce((sum, item) => 
      sum + (item.timing?.llm_time || 0), 0) / totalInteractions || 0;
    
    return { totalInteractions, successfulTts, avgLlmTime };
  };

  const emotionStats = getEmotionStats();
  const conversationStats = getConversationStats();

  const timestamps = filteredData.map(item => 
    new Date(item.timestamp).toLocaleTimeString("en-US", { hour12: false })
  );

  const getCongruenceStats = () => {
    const congruent = conversationLogs.filter(log =>
      log.log_flags?.emotion_congruence?.includes("✅")
    ).length;

    const contradictory = conversationLogs.filter(log =>
      log.log_flags?.emotion_congruence?.includes("⚠️")
    ).length;

    return {
      "Emotion Congruent": congruent,
      "Emotion Mismatch": contradictory
    };
  };

  const congruenceStats = getCongruenceStats();
  const congruenceRatio = ((congruenceStats["Emotion Congruent"] / (congruenceStats["Emotion Congruent"] + congruenceStats["Emotion Mismatch"] || 1)) * 100).toFixed(1);

  const getChartData = () => {
    const chartData = {
      labels: [],
      datasets: [
        {
          label: "Facial Emotion",
          data: [],
          borderColor: "#2196F3",
          backgroundColor: "rgba(33, 150, 243, 0.1)",
          tension: 0.4
        },
        {
          label: "Tone Emotion",
          data: [],
          borderColor: "#FF9800", 
          backgroundColor: "rgba(255, 152, 0, 0.1)",
          tension: 0.4
        }
      ]
    };

    const displayData = emotionData.slice(-30); // Use a fixed window of last 30 entries for smoother updates
    
    displayData.forEach((entry, index) => {
      chartData.labels.push(
        new Date(entry.timestamp).toLocaleTimeString("en-US", { 
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        })
      );
      
      chartData.datasets[0].data.push(
        emotionScale[entry.facial_emotion] || 3
      );
      
      chartData.datasets[1].data.push(
        emotionScale[entry.tone_emotion] || 3
      );
    });

    return chartData;
  };

  const getBarData = () => {
    if (dataSource === "emotion") {
      return {
        labels: Object.keys(emotionStats.facialEmotions || {}),
        datasets: [{
          label: "Facial Emotion Frequency",
          data: Object.values(emotionStats.facialEmotions || {}),
          backgroundColor: Object.keys(emotionStats.facialEmotions || {}).map(e => emotionColors[e] || "#ccc")
        }]
      };
    } else {
      const hourlyData = {};
      filteredData.forEach(item => {
        const hour = new Date(item.timestamp).getHours();
        hourlyData[hour] = (hourlyData[hour] || 0) + 1;
      });
      
      return {
        labels: Object.keys(hourlyData).map(h => `${h}:00`),
        datasets: [{
          label: "Conversations per Hour",
          data: Object.values(hourlyData),
          backgroundColor: "#4CAF50"
        }]
      };
    }
  };

  const getPieData = () => {
    if (dataSource === "emotion") {
      return {
        labels: Object.keys(emotionStats.toneEmotions || {}),
        datasets: [{
          label: "Tone Distribution",
          data: Object.values(emotionStats.toneEmotions || {}),
          backgroundColor: Object.keys(emotionStats.toneEmotions || {}).map(e => toneColors[e] || "#ccc")
        }]
      };
    } else {
      const ttsStats = {
        "Successful TTS": conversationStats.successfulTts,
        "Failed TTS": conversationStats.totalInteractions - conversationStats.successfulTts
      };
      
      return {
        labels: Object.keys(ttsStats),
        datasets: [{
          label: "TTS Success Rate",
          data: Object.values(ttsStats),
          backgroundColor: ["#4CAF50", "#F44336"]
        }]
      };
    }
  };

  const downloadSessionLogs = async () => {
    try {
      setDownloadStatus("⏳ Preparing download...");
      
      const response = await fetch("http://localhost:5000/download_logs");
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const blob = await response.blob();
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `emotion_session_logs_${timestamp}.csv`;
      
      saveAs(blob, filename);
      setDownloadStatus("✅ Emotion logs downloaded!");
      setTimeout(() => setDownloadStatus(""), 3000);
      
    } catch (error) {
      console.error("Download error:", error);
      setDownloadStatus("❌ Download failed. Check console.");
      setTimeout(() => setDownloadStatus(""), 5000);
    }
  };

  const downloadConversationLogs = async () => {
    try {
      setDownloadStatus("⏳ Preparing conversation logs...");
      
      const csvContent = conversationLogs.map(log => ({
        timestamp: log.timestamp,
        user_message: log.user_message,
        llm_reply: log.llm_reply,
        voice_gender: log.voice_gender,
        tts_success: log.tts_success,
        llm_time: log.timing?.llm_time || 0,
        tts_time: log.timing?.tts_time || 0,
        privacy_mode: log.privacy_mode,
        emotion_congruence: log.log_flags?.emotion_congruence || ""
      }));
      
      const headers = Object.keys(csvContent[0] || {});
      const csvString = [
        headers.join(','),
        ...csvContent.map(row => headers.map(header => `"${row[header] || ''}"`).join(','))
      ].join('\n');
      
      const blob = new Blob([csvString], { type: 'text/csv' });
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      saveAs(blob, `conversation_logs_${timestamp}.csv`);
      
      setDownloadStatus("✅ Conversation logs downloaded!");
      setTimeout(() => setDownloadStatus(""), 3000);
      
    } catch (error) {
      console.error("Conversation download error:", error);
      setDownloadStatus("❌ Conversation download failed.");
      setTimeout(() => setDownloadStatus(""), 5000);
    }
  };

  const exportDashboard = async () => {
    setDownloadStatus && setDownloadStatus('⏳ Preparing Excel export...');
    try {
      // 1. Prepare data sheets
      setDownloadStatus && setDownloadStatus('⏳ Creating Excel workbook...');
      const wb = XLSX.utils.book_new();
      // Emotion Data Sheet
      if (emotionData && emotionData.length > 0) {
        const ws1 = XLSX.utils.json_to_sheet(emotionData);
        XLSX.utils.book_append_sheet(wb, ws1, 'Emotion Data');
      }
      // Conversation Logs Sheet
      if (conversationLogs && conversationLogs.length > 0) {
        const ws2 = XLSX.utils.json_to_sheet(conversationLogs);
        XLSX.utils.book_append_sheet(wb, ws2, 'Conversation Logs');
      }
      // 2. Prepare chart images (as base64 PNGs)
      setDownloadStatus && setDownloadStatus('⏳ Capturing visible chart images...');
      async function captureChart(ref, name) {
        if (!ref) {
          console.warn(`[Excel Export] ${name} ref is undefined (skipped)`);
          return null;
        }
        if (!ref.current) {
          console.warn(`[Excel Export] ${name} ref.current is undefined (skipped)`);
          return null;
        }
        // Only capture if the element is visible in the DOM
        const el = ref.current;
        if (!el.offsetParent) {
          // Not visible (display:none or not in DOM tree)
          console.warn(`[Excel Export] ${name} is not visible in the DOM (skipped)`);
          return null;
        }
        try {
          const canvas = await html2canvas(el, { backgroundColor: '#fff' });
          return canvas.toDataURL('image/png');
        } catch (err) {
          console.warn(`[Excel Export] html2canvas failed for ${name} (skipped):`, err);
          return null;
        }
      }
      // Chart refs
      const chartImages = [];
      const skippedCharts = [];
      if (typeof chartRef !== 'undefined' && chartRef?.current) {
        const img = await captureChart(chartRef, 'Main Chart');
        if (img) chartImages.push({ name: 'Main Chart', img });
        else skippedCharts.push('Main Chart');
      } else {
        skippedCharts.push('Main Chart');
      }
      if (typeof comparisonChartRef !== 'undefined' && comparisonChartRef?.current) {
        const img = await captureChart(comparisonChartRef, 'Comparison Chart');
        if (img) chartImages.push({ name: 'Comparison Chart', img });
        else skippedCharts.push('Comparison Chart');
      } else {
        skippedCharts.push('Comparison Chart');
      }
      if (typeof pieChartRef !== 'undefined' && pieChartRef?.current) {
        const img = await captureChart(pieChartRef, 'Emotion Congruence');
        if (img) chartImages.push({ name: 'Emotion Congruence', img });
        else skippedCharts.push('Emotion Congruence');
      } else {
        skippedCharts.push('Emotion Congruence');
      }
      // 3. Add each chart image as a new sheet (as base64 string in cell)
      setDownloadStatus && setDownloadStatus('⏳ Adding chart images to Excel...');
      for (const { name, img } of chartImages) {
        const ws = XLSX.utils.aoa_to_sheet([[`${name} (chart image below)`], [img]]);
        XLSX.utils.book_append_sheet(wb, ws, name);
      }
      // 4. Save the workbook
      setDownloadStatus && setDownloadStatus('⏳ Saving Excel file...');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `emotion_dashboard_export_${timestamp}.xlsx`;
      XLSX.writeFile(wb, filename);
      let statusMsg = '✅ Excel export complete!';
      if (skippedCharts.length > 0) {
        statusMsg += ` (Skipped: ${skippedCharts.join(', ')})`;
      }
      setDownloadStatus && setDownloadStatus(statusMsg);
      setTimeout(() => setDownloadStatus && setDownloadStatus(''), 7000);
    } catch (err) {
      setDownloadStatus && setDownloadStatus('❌ Excel export failed');
      setTimeout(() => setDownloadStatus && setDownloadStatus(''), 5000);
      console.error('Excel export error:', err);
    }
  };

  const exportEmotionCongruenceChart = () => {
    if (!pieChartRef.current) return;

    html2canvas(pieChartRef.current).then(canvas => {
      canvas.toBlob(blob => {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        saveAs(blob, `emotion_congruence_chart_${timestamp}.png`);
      });
    });
  };

  // CSV export for dashboard data
  const exportDashboardCSV = () => {
    // Combine emotionData and conversationLogs into one CSV (with section headers)
    let csv = '';
    // Emotion Data
    if (emotionData && emotionData.length > 0) {
      csv += '--- Emotion Data ---\n';
      const emotionHeaders = Object.keys(emotionData[0]);
      csv += emotionHeaders.join(',') + '\n';
      emotionData.forEach(row => {
        csv += emotionHeaders.map(h => JSON.stringify(row[h] ?? '')).join(',') + '\n';
      });
      csv += '\n';
    }
    // Conversation Logs
    if (conversationLogs && conversationLogs.length > 0) {
      csv += '--- Conversation Logs ---\n';
      const logHeaders = Object.keys(conversationLogs[0]);
      csv += logHeaders.join(',') + '\n';
      conversationLogs.forEach(row => {
        csv += logHeaders.map(h => JSON.stringify(row[h] ?? '')).join(',') + '\n';
      });
      csv += '\n';
    }
    // Download as CSV
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    saveAs(blob, `emotion_dashboard_${timestamp}.csv`);
  };

  const getSystemHealthStatus = () => {
    if (!systemStatus.components) {
      return {
        emotionSystemUp: false,
        llmSystemUp: false,
        mongoUp: false
      };
    }

    return {
      emotionSystemUp: systemStatus.components?.emotion_detector,
      llmSystemUp: systemStatus.components?.ollama?.connected,
      mongoUp: systemStatus.components?.mongodb
    };
  };

  const { emotionSystemUp, llmSystemUp, mongoUp } = getSystemHealthStatus();

  // Performance metrics visualization
  const performanceChartLabels = [
    'STT - Vosk model',
    'Tone Analysis',
    'Ollama3.2:latest',
    'TTS - eSpeak-ng',
    'Total Time'
  ];

  // Update the chart data to use these labels
  const performanceChartData = {
    labels: performanceChartLabels,
    datasets: [
      {
        label: 'Time (s)',
        data: [
          Number((localPerformanceMetrics?.stt_time ?? 0).toFixed(4)),
          Number((localPerformanceMetrics?.tone_time ?? 0).toFixed(4)),
          Number((localPerformanceMetrics?.llm_time ?? 0).toFixed(4)),
          Number((localPerformanceMetrics?.tts_time ?? 0).toFixed(4)),
          Number((localPerformanceMetrics?.total_time ?? 0).toFixed(4)),
        ],
        backgroundColor: [
          '#4e79a7',
          '#f28e2b',
          '#e15759',
          '#76b7b2',
          '#888888',
        ],
      },
    ],
  };

  // Face Detected logic: show ✅ if any valid emotion was captured
  const faceDetected =
    (usedEmotions.length > 0) ||
    (capturedEmotions.length > 0) ||
    (lastNonEmptyEmotion?.all_emotions_captured?.length > 0) ||
    (lastNonEmptyEmotion?.all_emotions_captured_raw?.length > 0);

  // Helper to render emotional context as a string or array of objects
  function renderEmotionalContext(ctx) {
    if (!ctx) return "N/A";
    if (Array.isArray(ctx)) {
      return ctx.map(renderEmotionalContext).join("; ");
    }
    if (typeof ctx === 'object') {
      return `Dominant: ${ctx.dominant ?? "-"}, Confidence: ${ctx.confidence ?? "-"}, Tone: ${ctx.tone ?? "-"}, Sentiment: ${ctx.sentiment ?? "-"}`;
    }
    return String(ctx);
  }

  // Helper to render emotion match as JSON if it's an object with confidence, dominant, sentiment, tone
  function renderEmotionMatch(val) {
    if (!val) return "N/A";
    if (typeof val === 'object') {
      // If it has the keys for full context, show as JSON
      if ('confidence' in val && 'dominant' in val && 'sentiment' in val && 'tone' in val) {
        return JSON.stringify({
          confidence: val.confidence,
          dominant: val.dominant,
          sentiment: val.sentiment,
          tone: val.tone
        });
      }
      // If it's an object with a congruence property, use that
      if (val.congruence) return val.congruence;
      // If it's a string property, use that
      if (typeof val.emotion_congruence === 'string') return val.emotion_congruence;
      // If it's a known congruence value in any property
      for (const k of Object.keys(val)) {
        if (["aligned", "mixed", "contradiction"].includes(val[k])) return val[k];
      }
      // Otherwise, stringify
      return JSON.stringify(val);
    }
    return String(val);
  }

  // For Emotion Match, show a checkmark, X, or uncertain based on congruence
  function getEmotionMatchSymbol(ctx) {
    if (!ctx || typeof ctx !== 'object') return '❓ UNCERTAIN';
    // Prefer backend's emotion_congruence if available
    const congruence = ctx.emotion_congruence || ctx.congruence;
    if (congruence === 'aligned') return '✅ MATCH';
    if (congruence === 'contradiction') return '❌ CONTRADICT';
    if (congruence === 'mixed') return '⚠️ MIXED';
    // Fallback to old logic if no backend congruence
    const { dominant, tone, sentiment } = ctx;
    if (!dominant || !tone || !sentiment) return '❓ UNCERTAIN';
    if (dominant === tone && tone === sentiment) return '✅ MATCH';
    if (dominant !== tone || dominant !== sentiment || tone !== sentiment) {
      return '❌ CONTRADICT';
    }
    return '❓ UNCERTAIN';
  }

  // PNG export for the entire dashboard
  const exportDashboardPNG = async () => {
    const dashboardElement = document.getElementById('emotion-dashboard-main');
    if (!dashboardElement) {
      alert('Dashboard element not found.');
      return;
    }
    try {
      const canvas = await html2canvas(dashboardElement, { backgroundColor: '#fff', scale: 2 });
      canvas.toBlob(blob => {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        saveAs(blob, `emotion_dashboard_${timestamp}.png`);
      });
    } catch (err) {
      alert('Failed to export dashboard as PNG.');
      console.error('PNG export error:', err);
    }
  };

  // Store dashboard PNGs for each interaction
  const [dashboardPNGs, setDashboardPNGs] = useState([]);

  // After every interaction, capture a PNG of the dashboard and store it
  useEffect(() => {
    // Only capture if there is new data
    if (emotionData.length === 0) return;
    const capturePNG = async () => {
      const dashboardElement = document.getElementById('emotion-dashboard-main');
      if (!dashboardElement) return;
      try {
        const canvas = await html2canvas(dashboardElement, { backgroundColor: '#fff', scale: 2 });
        const dataUrl = canvas.toDataURL('image/png');
        setDashboardPNGs(prev => [...prev, dataUrl]);
      } catch (err) {
        setDashboardPNGs(prev => [...prev, null]);
      }
    };
    // Only capture if this is a new interaction
    if (dashboardPNGs.length < emotionData.length) {
      capturePNG();
    }
  }, [emotionData]);

  // Excel export for dashboard data with embedded PNGs
  const exportDashboardExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Dashboard Data');
    // Add headers
    const headers = [
      'Timestamp', 'Facial Emotion', 'Tone Emotion', 'Text Sentiment', 'Confidence', 'Emotion Confidence', 'Face Detected', 'All Emotions', 'All Emotions Raw', 'Tone Analysis Details', 'Dashboard Snapshot'
    ];
    worksheet.addRow(headers);
    // For each interaction
    for (let i = 0; i < emotionData.length; i++) {
      const entry = emotionData[i];
      const row = worksheet.addRow([
        entry.timestamp,
        entry.facial_emotion,
        entry.tone_emotion,
        entry.text_sentiment,
        entry.confidence,
        entry.emotion_confidence,
        entry.face_detected,
        JSON.stringify(entry.all_emotions_captured),
        JSON.stringify(entry.all_emotions_captured_raw),
        entry.tone_analysis_details,
        '' // Placeholder for image
      ]);
      // Add image if available
      if (dashboardPNGs[i]) {
        const imageId = workbook.addImage({
          base64: dashboardPNGs[i],
          extension: 'png',
        });
        worksheet.addImage(imageId, {
          tl: { col: 10, row: row.number - 1 },
          ext: { width: 200, height: 120 }
        });
      } else {
        worksheet.getCell(`K${row.number}`).value = 'No image';
      }
    }
    // Add Performance Metrics Sheet
    const perfSheet = workbook.addWorksheet('Performance Metrics');
    // List of metrics to export (with pretty names)
    const metrics = [
      ['INTERACTION COUNT', localPerformanceMetrics?.interaction_count ?? 'N/A'],
      ['LLM PERCENTAGE (%)', localPerformanceMetrics?.llm_percentage?.toFixed(2) ?? 'N/A'],
      ['LLM TIME (s)', localPerformanceMetrics?.llm_time?.toFixed(4) ?? 'N/A'],
      ['STT PERCENTAGE (%)', localPerformanceMetrics?.stt_percentage?.toFixed(2) ?? 'N/A'],
      ['STT TIME (s)', localPerformanceMetrics?.stt_time?.toFixed(4) ?? 'N/A'],
      ['TONE PERCENTAGE (%)', localPerformanceMetrics?.tone_percentage?.toFixed(2) ?? 'N/A'],
      ['TONE TIME (s)', localPerformanceMetrics?.tone_time?.toFixed(4) ?? 'N/A'],
      ['TOTAL TIME (s)', localPerformanceMetrics?.total_time?.toFixed(4) ?? 'N/A'],
      ['TTS PERCENTAGE (%)', localPerformanceMetrics?.tts_percentage?.toFixed(2) ?? 'N/A'],
      ['TTS TIME (s)', localPerformanceMetrics?.tts_time?.toFixed(4) ?? 'N/A'],
    ];
    perfSheet.addRow(['Metric', 'Value']);
    metrics.forEach(([name, value]) => perfSheet.addRow([name, value]));
    // Download
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    saveAs(blob, `emotion_dashboard_${timestamp}.xlsx`);
  };

  return (
    <div id="emotion-dashboard-main" style={{ padding: "30px", backgroundColor: "#f5f5f5", minHeight: "100vh" }}>
      <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
        <h2>🧠 Enhanced Emotion Avatar Dashboard v2.0</h2>
        
        {/* Enhanced System Health Status with tooltips */}
        <div style={{ display: "flex", gap: "15px", marginBottom: "20px", flexWrap: "wrap" }}>
          <SystemStatusIndicator 
            status={emotionSystemUp}
            label="Emotion System"
            tooltip={`Status: ${emotionSystemUp ? '✅' : '❌'}`}
          />
          <SystemStatusIndicator 
            status={llmSystemUp}
            label="LLM System"
            tooltip={`Model: ${llmSystemUp ? '✅' : '❌'}`}
          />
          <SystemStatusIndicator 
            status={mongoUp}
            label="Database"
            tooltip={`Collections: ${mongoUp ? '✅' : '❌'}`}
          />
        </div>

        {/* Controls (unchanged but more resilient) */}
        <div style={{ marginBottom: "20px" }}>
          <label style={{ marginRight: "10px" }}>Data Source: </label>
          <select 
            value={dataSource || "emotion"} 
            onChange={e => setDataSource?.(e.target.value)} 
            style={{ marginRight: "20px", padding: "5px" }}
          >
            <option value="emotion">Emotion Detection</option>
            <option value="conversation">LLM Conversations</option>
          </select>

          <label style={{ marginRight: "10px" }}>Chart Type: </label>
          <select 
            value={chartType || "line"} 
            onChange={e => setChartType?.(e.target.value)} 
            style={{ marginRight: "20px", padding: "5px" }}
          >
            <option value="line">Line</option>
            <option value="bar">Bar</option>
            <option value="pie">Pie/Doughnut</option>
          </select>

          <label style={{ marginRight: "10px" }}>Time Filter: </label>
          <select 
            value={timeFilter || "all"} 
            onChange={e => setTimeFilter?.(e.target.value)} 
            style={{ marginRight: "20px", padding: "5px" }}
          >
            <option value="all">All Time</option>
            <option value="15min">Last 15 min</option>
            <option value="30min">Last 30 min</option>
            <option value="1hr">Last 1 hour</option>
            <option value="6hr">Last 6 hours</option>
          </select>

          <button 
            onClick={exportDashboardPNG} 
            style={{ marginRight: "10px", padding: "8px 12px", backgroundColor: "#2196F3", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}
            disabled={!exportDashboardPNG}
          >
            📤 Export Dashboard
          </button>

          <button onClick={exportDashboardExcel} style={{marginRight: 12, padding: '8px 18px', fontWeight: 600}}>
            Download Dashboard
          </button>

          <button 
            onClick={downloadSessionLogs} 
            style={{ marginRight: "10px", padding: "8px 12px", backgroundColor: "#4CAF50", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}
            disabled={!downloadSessionLogs}
          >
            📥 Download Emotion Logs
          </button>

          <button 
            onClick={downloadConversationLogs} 
            style={{ padding: "8px 12px", backgroundColor: "#FF9800", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}
            disabled={!downloadConversationLogs}
          >
            💬 Download Conversation Logs
          </button>

          {downloadStatus && (
            <span style={{ 
              marginLeft: "10px", 
              padding: "5px 10px", 
              backgroundColor: downloadStatus.includes("✅") ? "#d4edda" : 
                              downloadStatus.includes("❌") ? "#f8d7da" : "#fff3cd",
              border: "1px solid " + (downloadStatus.includes("✅") ? "#c3e6cb" : 
                                    downloadStatus.includes("❌") ? "#f5c6cb" : "#ffeaa7"),
              borderRadius: "4px",
              fontSize: "14px"
            }}>
              {downloadStatus}
            </span>
          )}
        </div>
      </div>

      {/* Performance Metrics Section */}
      {Object.keys(localPerformanceMetrics).length > 0 && (
        <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
          <h3>⚡ Real-time Performance Metrics</h3>
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "20px" }}>
            <div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "15px" }}>
                {Object.entries(localPerformanceMetrics).map(([key, value]) => {
                  if (typeof value === 'number') {
                    return (
                      <div key={key} style={{ padding: "12px", backgroundColor: "#f8f9fa", borderRadius: "6px" }}>
                        <div style={{ fontSize: "12px", color: "#666" }}>
                          {key.replace(/_/g, ' ').toUpperCase()}
                        </div>
                        <div style={{ fontSize: "18px", fontWeight: "bold" }}>
                          {key.includes('percentage') ?
                            `${value.toFixed(2)}%` :
                            key.includes('time') ? `${value.toFixed(4)}s` :
                            value}
                        </div>
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
            {performanceChartData && (
              <div style={{ height: "300px" }}>
                <h4 style={{ marginTop: 0, marginBottom: "15px" }}>Performance Breakdown</h4>
                <Bar 
                  data={performanceChartData} 
                  options={{ 
                    responsive: true, 
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true, title: { display: true, text: 'Time (seconds)' } } }
                  }} 
                />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Analytics Section: Trends, Spikes, Overlay, Correlation */}
      {dataSource === "emotion" && (
        <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
          <h3>📊 Emotion Detection Analytics</h3>
          {/* Trend display for each intensity */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '18px', marginBottom: '10px' }}>
            {["HIGH POSITIVE", "POSITIVE", "NEUTRAL", "LOW", "NEGATIVE"].map(intensity => {
              const { recentCount, percentChange } = getTrendForIntensity(intensity, "facial_emotion");
              return (
                <div key={intensity} style={{ minWidth: 120 }}>
                  <strong>{intensity}:</strong> {recentCount} {percentChange > 0 ? "▲" : percentChange < 0 ? "▼" : ""} ({percentChange.toFixed(1)}%)
                </div>
              );
            })}
          </div>
          {/* Spike detection warning for negative emotions */}
          {detectSpike("NEGATIVE") && <div style={{ color: "red", fontWeight: "bold" }}>⚠️ Spike in negative emotions detected!</div>}
          {/* Overlay and correlation charts side by side */}
          <div style={{ display: 'flex', flexDirection: 'row', gap: '24px', marginTop: '10px' }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Line data={overlayChartData} options={{ responsive: true, plugins: { legend: { position: "bottom" } } }} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Line
                data={correlationChartData}
                options={{
                  responsive: true,
                  plugins: { legend: { position: "bottom" } },
                  scales: {
                    y: { type: 'linear', position: 'left', title: { display: true, text: 'Emotion Count' } },
                    y1: { type: 'linear', position: 'right', title: { display: true, text: 'LLM Time (s)' }, grid: { drawOnChartArea: false } }
                  }
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Main Chart */}
      <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
        <h3>{dataSource === "emotion" ? "📊 Emotion Detection Analytics" : "💬 Conversation Analytics"}</h3>
        <div style={{ height: "400px" }}>
          {chartType === "line" && (
            <Line
              ref={chartRef}
              data={getChartData()}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    min: 1,
                    max: 5,
                    ticks: {
                      callback: function(value) {
                        const labels = {
                          1: "Negative", 
                          2: "Low",
                          3: "Neutral",
                          4: "Positive",
                          5: "High Positive"
                        };
                        return labels[value] || value;
                      }
                    }
                  }
                }
              }}
            />
          )}
          {chartType === "bar" && <Bar data={getBarData()} options={{ responsive: true, maintainAspectRatio: false }} />}
          {chartType === "pie" && (dataSource === "emotion" ? 
            <Pie data={getPieData()} options={{ responsive: true, maintainAspectRatio: false }} /> : 
            <Doughnut data={getPieData()} options={{ responsive: true, maintainAspectRatio: false }} />
          )}
        </div>
      </div>

      {dataSource === "conversation" && (
        <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
          <h3>📉 User vs Avatar Emotion Comparison</h3>
          <div style={{ marginBottom: "10px", color: "#555" }}>
            <strong>Emotion Congruence:</strong> {congruenceRatio}%
          </div>
          <div ref={comparisonChartRef} style={{ height: "300px" }}>
            <Bar
              data={userVsAvatarChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    max: 5,
                    ticks: {
                      callback: function(value) {
                        const labels = ["", "Angry", "Sad", "Neutral", "Happy", "Cheerful"];
                        return labels[value];
                      }
                    },
                    title: { display: true, text: "Emotion Level" }
                  }
                }
              }}
            />
          </div>
          <button
            onClick={exportUserVsAvatarChart}
            style={{
              marginTop: "10px",
              padding: "8px 12px",
              backgroundColor: "#6c757d",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer"
            }}
          >
            📤 Export Comparison Chart as PNG
          </button>
        </div>
      )}

      {/* Live Status */}
      <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
        <h3>🔴 Live Status</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
          <div>
            <h4>Latest Emotion Detection</h4>
            {isEmotionDataStale() && (
              <div style={{ color: '#d9534f', marginBottom: '10px' }}>
                ⏳ Waiting for new emotion data...
              </div>
            )}
            <ul style={{ listStyle: "none", padding: 0 }}>
              <li style={{ marginBottom: "8px" }}><strong>Facial:</strong> {lastNonEmptyEmotion?.facial_emotion || "N/A"}</li>
              <li style={{ marginBottom: "8px" }}><strong>Face Detected:</strong> {faceDetected ? "✅" : "❌"}</li>
              <li style={{ marginBottom: "8px" }}><strong>Tone:</strong> {lastNonEmptyEmotion?.tone_emotion || "N/A"}</li>
              <li style={{ marginBottom: "8px" }}><strong>Sentiment:</strong> {lastNonEmptyEmotion?.text_sentiment || "N/A"}</li>
              {/* Replace Interaction ID with INTERACTION COUNT in Live Status */}
              <li style={{ marginBottom: "8px" }}>
                <strong>Interaction Count:</strong> {localPerformanceMetrics?.interaction_count ?? "N/A"}
              </li>
            </ul>
            {/* Full Speech Text Display */}
            <div style={{ marginTop: "15px" }}>
              <h5 style={{ marginBottom: "8px" }}>💬 Latest Speech:</h5>
              <div style={{ 
                padding: "10px", 
                backgroundColor: "#f8f9fa", 
                borderRadius: "5px", 
                border: "1px solid #e9ecef",
                maxHeight: "150px",
                overflowY: "auto",
                fontSize: "14px",
                lineHeight: "1.4"
              }}>
                {/* Show only the last user speech, not the LLM reply */}
                {lastNonEmptyConversation?.user_message || lastNonEmptySpeech?.speech_text || lastNonEmptySpeech?.transcript || lastNonEmptySpeech?.user_message || (isEmotionDataStale() ? "Waiting for new speech..." : "No speech detected yet...")}
              </div>
              <div style={{ fontSize: "12px", color: "#666", marginTop: "5px" }}>
                <strong>Timestamp:</strong> {lastNonEmptySpeech?.timestamp ? new Date(lastNonEmptySpeech.timestamp).toLocaleString() : lastNonEmptyEmotion?.timestamp ? new Date(lastNonEmptyEmotion.timestamp).toLocaleString() : "N/A"}
              </div>
            </div>
          </div>
          <div>
            <h4>Latest Conversation</h4>
            {/* Only show the last conversation log, or waiting message if none */}
            {(!lastNonEmptyConversation || isEmotionDataStale()) ? (
              <p style={{ color: '#d9534f' }}>⏳ Waiting for conversation data...</p>
            ) : (
              <div>
                <p><strong>User Message:</strong> {lastNonEmptyConversation?.user_message || "N/A"}</p>
                <p><strong>Ollama3.2:latest:</strong> {lastNonEmptyConversation?.llm_reply || "N/A"}</p>
                {emotionContextEnabled && (
                  <>
                    <p><strong>Emotion Match:</strong> {getEmotionMatchSymbol(lastNonEmptyConversation?.emotional_context)}</p>
                    <p><strong>Emotional Context:</strong> {renderEmotionalContext(lastNonEmptyConversation?.emotional_context)}</p>
                  </>
                )}
                <p><strong>TTS:</strong> {lastNonEmptyConversation?.tts_success ? "✅" : "❌"}</p>
                <p><strong>Time:</strong> {lastNonEmptyConversation?.timing?.llm_time?.toFixed(2) || "N/A"}s</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Detailed Statistics */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
        {dataSource === "emotion" && (
          <>
            <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px" }}>
              <h3>😊 Facial Emotions</h3>
              {/* Show total sample counts if available */}
              {latest?.all_emotions_captured_raw && Array.isArray(latest.all_emotions_captured_raw) && (
                <div style={{ fontWeight: "bold", marginBottom: "4px", color: "#333" }}>
                  Samples captured: {capturedEmotions.length}
                </div>
              )}
              {latest?.all_emotions_captured && Array.isArray(latest.all_emotions_captured) && (
                <div style={{ fontWeight: "bold", marginBottom: "8px", color: "#333" }}>
                  Samples used: {usedEmotions.length}
                </div>
              )}
              <div style={{ height: "300px" }}>
                <Bar 
                  data={{
                    labels: validEmotions,
                    datasets: [{
                      label: "Frequency",
                      data: validEmotions.map(e => usedEmotions.filter(x => x === e).length),
                      backgroundColor: validEmotions.map(e => emotionColors[e] || "#ccc")
                    }]
                  }}
                  options={{ responsive: true, maintainAspectRatio: false }}
                />
              </div>
              {/* Color legend for facial emotions */}
              <div style={{ marginTop: '10px', fontSize: '14px' }}>
                <strong>Color Legend:</strong>
                <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
                  {validEmotions.map(emotion => (
                    <li key={emotion} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <span style={{ display: 'inline-block', width: '16px', height: '16px', backgroundColor: emotionColors[emotion], borderRadius: '50%', border: '1px solid #aaa' }}></span>
                      {emotion.charAt(0).toUpperCase() + emotion.slice(1)}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px" }}>
              <h3>🎵 Voice Tone</h3>
              <div style={{ height: "300px" }}>
                {/* Always use all emotionData for tone analysis, not filteredData */}
                {(() => {
                  const toneCounts = {};
                  allTones.forEach(t => toneCounts[t] = 0);
                  // Use all emotionData, not filteredData
                  emotionData.forEach(entry => {
                    if (entry.tone_emotion && allTones.includes(entry.tone_emotion)) {
                      toneCounts[entry.tone_emotion]++;
                    }
                  });
                  const toneChartData = {
                    labels: allTones,
                    datasets: [{
                      label: "Tone Analysis Results",
                      data: allTones.map(t => toneCounts[t]),
                      backgroundColor: allTones.map(t => toneColors[t] || "#ccc")
                    }]
                  };
                  return (
                    <Doughnut
                      data={toneChartData}
                      options={{ responsive: true, maintainAspectRatio: false }}
                    />
                  );
                })()}
              </div>
              {/* Show Tone Analysis details after every interaction */}
              <div style={{ marginTop: '12px', fontSize: '15px', color: '#333' }}>
                <strong>Tone Analysis:</strong> {lastNonEmptyEmotion?.tone_analysis_details || "N/A"}
              </div>
              {/* Custom legend for tone colors */}
              <div style={{ marginTop: '10px', fontSize: '14px' }}>
                <strong>Legend:</strong>
                <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
                  {allTones.map(tone => (
                    <li key={tone} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <span style={{ display: 'inline-block', width: '16px', height: '16px', backgroundColor: toneColors[tone], borderRadius: '50%', border: '1px solid #aaa' }}></span>
                      {tone.charAt(0).toUpperCase() + tone.slice(1)}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </>
        )}

        {dataSource === "conversation" && (
          <>
            <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px" }}>
              <h3>📈 Conversation Metrics</h3>
              <ul style={{ listStyle: "none", padding: 0, fontSize: "16px" }}>
                <li style={{ marginBottom: "10px" }}><strong>Total Interactions:</strong> {conversationStats.totalInteractions}</li>
                <li style={{ marginBottom: "10px" }}><strong>TTS Success Rate:</strong> {conversationStats.totalInteractions > 0 ? ((conversationStats.successfulTts / conversationStats.totalInteractions) * 100).toFixed(1) : 0}%</li>
                <li style={{ marginBottom: "10px" }}><strong>Avg Response Time:</strong> {conversationStats.avgLlmTime.toFixed(3)}s</li>
                <li style={{ marginBottom: "10px" }}><strong>Privacy Mode Usage:</strong> {conversationLogs.filter(log => log.privacy_mode).length}</li>
              </ul>
            </div>

            {/* Emotion Congruence Pie Chart */}
            <div ref={pieChartRef} style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px" }}>
              <h3>🧠 Emotion Congruence</h3>
              <div style={{ height: "300px" }}>
                <Pie
                  data={{
                    labels: Object.keys(congruenceStats),
                    datasets: [{
                      data: Object.values(congruenceStats),
                      backgroundColor: ["#28a745", "#d9534f"]
                    }]
                  }}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: { position: "bottom" },
                      datalabels: {
                        color: "#fff",
                        font: { weight: "bold" },
                        formatter: (value, ctx) => {
                          const total = ctx.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                          const percentage = ((value / total) * 100).toFixed(1);
                          return `${percentage}%`;
                        }
                      }
                    }
                  }}
                />
              </div>
              <p style={{ fontSize: "13px", color: "#555", marginTop: "10px" }}>
                <span style={{ color: "#28a745", fontWeight: "bold" }}>✅ Congruent</span>: Facial, tone, and sentiment agree.<br />
                <span style={{ color: "#d9534f", fontWeight: "bold" }}>⚠️ Mismatch</span>: Words and emotions appear inconsistent — may suggest stress, masking, or contradiction.
              </p>
              {/* Export Button */}
              <button
                onClick={exportEmotionCongruenceChart}
                style={{
                  marginTop: "10px",
                  padding: "8px 12px",
                  backgroundColor: "#6c757d",
                  color: "white",
                  border: "none",
                  borderRadius: "4px",
                  cursor: "pointer"
                }}
              >
                📤 Export Emotion Chart as PNG
              </button>
            </div>

            <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "8px" }}>
              <h3>🗣️ Recent Conversations</h3>
              <div style={{ maxHeight: "300px", overflowY: "auto" }}>
                {conversationLogs.slice(0, 5).map((log, i) => (
                  <div key={i} style={{ padding: "10px", borderBottom: "1px solid #eee", marginBottom: "10px" }}>
                    <div style={{ marginBottom: "5px" }}>
                      <strong>User Message:</strong> {log.user_message?.substring(0, 80)}...
                    </div>
                    <div style={{ marginBottom: "5px" }}>
                      <strong>Ollama3.2:latest:</strong> {log.llm_reply?.substring(0, 80)}...
                    </div>
                    <div style={{ fontSize: "12px", color: "#666" }}>
                      {new Date(log.timestamp).toLocaleString()} | {log.timing?.llm_time?.toFixed(2)}s
                    </div>
                    {log.log_flags?.emotion_congruence && (
                      <div
                        style={{
                          fontSize: "12px",
                          marginTop: "5px",
                          color: log.log_flags.emotion_congruence.includes("⚠️") ? "#d9534f" : "#28a745",
                          fontWeight: "bold"
                        }}
                      >
                        <strong>Emotion Check:</strong> {log.log_flags.emotion_congruence}
                      </div>
                    )}
                    {log.emotional_context && (
                      <div style={{ fontSize: "12px", color: "#666", marginTop: "5px" }}>
                        <strong>Emotional Context:</strong> {renderEmotionalContext(log.emotional_context)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      
    </div>
  );
};
export default EmotionDashboard;

