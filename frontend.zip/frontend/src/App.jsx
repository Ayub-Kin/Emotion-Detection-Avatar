import React, { useEffect, useState, useCallback, useRef } from "react";
import RobotAvatar from "./components/RobotAvatar";
import EmotionDashboard from "./components/EmotionDashboard";
import UserInterface from "./components/RobotUserInterface";

const App = () => {
  const [emotion, setEmotion] = useState("neutral");
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState("");
  const [privacyMode, setPrivacyMode] = useState(true);
  const [showVideo, setShowVideo] = useState(false);
  const [, setCurrentEmotion] = useState(null);
  const [, setDetections] = useState([]);
  const [showDashboard, setShowDashboard] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [voiceGender, setVoiceGender] = useState("female");
  const [speakReply, setSpeakReply] = useState(true);
  const [, setIsListening] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [, setIsTalking] = useState(false);
  const [llmResponse, setllmResponse] = useState("");
  const [performanceMetrics, setPerformanceMetrics] = useState({});
  const [lastInteractionTime, setLastInteractionTime] = useState(null);
  const [currentView, setCurrentView] = useState("control");
  const [currentPhase, setCurrentPhase] = useState("idle");
  const [backendConnected, setBackendConnected] = useState(false);
  const [healthData, setHealthData] = useState({ status: "unknown",components: {} });
  const [emotionContextEnabled, setEmotionContextEnabled] = useState(() => {
    const saved = localStorage.getItem('emotionContextEnabled');
    return saved !== null ? JSON.parse(saved) : true;
  });

  // Custom setter that saves to localStorage
  const setEmotionContextEnabledWithStorage = (value) => {
    setEmotionContextEnabled(value);
    localStorage.setItem('emotionContextEnabled', JSON.stringify(value));
  };
  const [currentLlmResponse, setCurrentLlmResponse] = useState("");
  const [lastFetchedEmotion, setLastFetchedEmotion] = useState("neutral");
  const [stableEmotion, setStableEmotion] = useState("neutral"); // Stable emotion for avatar display
  const [dominantEmotionSet, setDominantEmotionSet] = useState(false); // Track if dominant emotion is set for current interaction
  const [emotionLocked, setEmotionLocked] = useState(false); // Lock emotion updates during interactions
  const emotionStabilityTimerRef = useRef(null);
  const abortControllerRef = useRef(null);
  const healthCheckControllerRef = useRef(null);
  const pollControllerRef = useRef(null);
  const BACKEND_URL = "http://localhost:5000";
  const API_BASE_URL = "http://localhost:5000";
  const LLM_API_URL = `${API_BASE_URL}/llm_reply`;
  const INTERACTION_FLAGS_URL = `${API_BASE_URL}/interaction_flags`; 
  const CURRENT_LLM_RESPONSE_URL = `${API_BASE_URL}/api/current_llm_response`;
  const CURRENT_DOMINANT_EMOTION_URL = `${API_BASE_URL}/api/current_dominant_emotion`;
  // Cleanup function for abort controllers
  const cleanupControllers = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    if (healthCheckControllerRef.current) {
      healthCheckControllerRef.current.abort();
      healthCheckControllerRef.current = null;
    }
    if (pollControllerRef.current) {
      pollControllerRef.current.abort();
      pollControllerRef.current = null;
    }
  }, []);

  // Reset avatar state properly
  const resetAvatarState = () => {
      setIsRecording(false);
      setIsListening(false);
      setIsProcessing(false);
      setIsTalking(false);
      //setReply("");
      setllmResponse("");
      setCurrentLlmResponse("");
      setLastFetchedEmotion("neutral"); // Reset emotion tracking
      setStableEmotion("neutral"); // Reset stable emotion immediately
      setDominantEmotionSet(false); // Reset dominant emotion flag
      setEmotionLocked(false); // Unlock emotion updates
      
      // Clear any pending emotion stability timer
      if (emotionStabilityTimerRef.current) {
        clearTimeout(emotionStabilityTimerRef.current);
        emotionStabilityTimerRef.current = null;
      }
      
      console.log("🔄 Avatar state reset - emotions cleared");
  };

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('view') === 'user') {
      setCurrentView('user');
    }
  }, []);

  // Backend connection check with cleanup
  useEffect(() => {
    const checkBackendConnection = async () => {
      console.log('[POLL] Backend connection check started');
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        controller.abort();
        console.warn('[POLL] Backend connection check timed out');
      }, 8000);
      try {
        const response = await fetch(`${BACKEND_URL}/api/health`, {
          signal: controller.signal,
          headers: {'Cache-Control': 'no-cache'}
        });
        clearTimeout(timeoutId);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        const isHealthy = data.status === "healthy" || data.status === "degraded";
        if (backendConnected !== isHealthy || healthData.status !== data.status) {
          setBackendConnected(isHealthy);
          setHealthData(data);
        }
        console.log('[POLL] Backend connection check success:', data);
        return true;
      } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
          console.warn('[POLL] Backend connection check aborted (timeout)');
        } else {
          console.warn('[POLL] Connection check failed:', error.message);
        }
        return false;
      }
    };
    checkBackendConnection(); // Check immediately
    const checkInterval = setInterval(async () => {
      console.log('[POLL] Backend connection interval tick');
      const isConnected = await checkBackendConnection();
      if (!backendConnected && isConnected) {
        setBackendConnected(true);
        setCurrentPhase("idle");
        setReply("✅ Connection restored");
      }
    }, 5000);
    return () => {
      clearInterval(checkInterval);
      console.log('[POLL] Backend connection polling stopped');
    };
  }, [backendConnected]);

  const recoverSystemState = async () => {
      if (currentPhase !== "error" || Date.now() - lastInteractionTime < 5000) {
          return;
      }
      
      try {
          setCurrentPhase("recovering");
          setReply("🔄 Attempting recovery...");
          
          await testBackendConnection(); // First check backend status
          
          // Then soft reset
          await fetch(`${API_BASE_URL}/api/reset`, {
              method: "POST",
              headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({ hard_reset: false })
          });
          
          setCurrentPhase("idle");
          setReply("✅ System recovered");
      } catch (e) {
          console.error("Recovery failed:", e);
      }
  };
  const lastResetAttempt = useRef(0);
  const RESET_COOLDOWN = 3000; // 3 seconds
  
  // Add to useEffect for status polling
  const hardResetSystem = async () => {
    const now = Date.now();
    if (now - lastResetAttempt.current < RESET_COOLDOWN) {
        return; // Skip if recently tried to reset
    }
    lastResetAttempt.current = now;
    try {
          setReply("🔄 Resetting application state...");
          setCurrentPhase("resetting");
          
          resetAvatarState();
          setCurrentEmotion(null);
          setDetections([]);
          
          // Modified fetch call with proper headers
          const response = await fetch("http://localhost:5000/api/reset", {
              method: "POST",
              headers: {
                  "Content-Type": "application/json", // Add this header
              },
              body: JSON.stringify({ hard_reset: true }) 
          });
          
          if (!response.ok) {
              throw new Error(`HTTP ${response.status}`);
          }

          const result = await response.json();
          
          if (result.status !== "success") {
              throw new Error(result.error || "State reset failed");
          }

          setCurrentPhase("idle");
          setReply("✅ Application state reset complete");
          
          setTimeout(() => {
              if (reply.includes("✅ Application state reset complete")) {
                  setReply("");
              }
          }, 3000);
          
      } catch (e) {
          setReply(`❌ State reset failed: ${e.message}`);
          setCurrentPhase("error");
          await new Promise(resolve => setTimeout(resolve, 5000));
      }
  };

  // Fetch emotion data (completely disabled - only use dominant emotion endpoint)
  useEffect(() => {
    // Completely disable regular emotion polling to prevent conflicts
    return;
    const fetchEmotion = async () => {
      console.log('[POLL] Emotion fetch started');
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        controller.abort();
        console.warn('[POLL] Emotion fetch timed out');
      }, 5000);
      try {
        const res = await fetch("http://localhost:5000/api/emotion", {
          signal: controller.signal,
          headers: {'Cache-Control': 'no-cache'}
        });
        clearTimeout(timeoutId);
        if (res.ok) {
          const data = await res.json();
          if (data.status !== "no_change") {
            const newEmotion = data.facial_emotion || data.dominant_emotion || data.emotion;
            if (newEmotion && newEmotion !== lastFetchedEmotion) {
              setLastFetchedEmotion(newEmotion);
              updateStableEmotion(newEmotion); // Use debounced update
              console.log('😊 Regular emotion detected:', lastFetchedEmotion, '→', newEmotion);
            }
            setLastInteractionTime(Date.now());
          }
          console.log('[POLL] Emotion fetch success:', data);
        } else {
          console.error('[POLL] Emotion fetch failed: HTTP', res.status);
        }
      } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
          console.warn('[POLL] Emotion fetch aborted (timeout)');
        } else {
          console.error('[POLL] Emotion fetch error:', error);
        }
      }
    };
    const interval = setInterval(fetchEmotion, 500); // More frequent updates for immediate response
    return () => {
      clearInterval(interval);
      console.log('[POLL] Emotion polling stopped');
    };
  }, [showDashboard, backendConnected]);

  // Fetch performance metrics
  useEffect(() => {
    if (!showDashboard && !lastInteractionTime) return;
    const fetchPerformanceMetrics = async () => {
      console.log('[POLL] Performance metrics fetch started');
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        controller.abort();
        console.warn('[POLL] Performance metrics fetch timed out');
      }, 5000);
      try {
        const response = await fetch("http://localhost:5000/performance_metrics", {
          signal: controller.signal,
          headers: {
            'Cache-Control': 'no-cache',
            'Accept': 'application/json'
          }
        });
        clearTimeout(timeoutId);
        if (response.ok) {
          const data = await response.json();
          console.log("📊 Performance metrics received:", data);
          if (data.status === "success" && data.metrics) {
            setPerformanceMetrics(data.metrics);
          } else if (data.metrics) {
            setPerformanceMetrics(data.metrics);
          } else {
            setPerformanceMetrics(data);
          }
          console.log('[POLL] Performance metrics fetch success:', data);
        } else {
          console.error('[POLL] Performance metrics fetch failed: HTTP', response.status);
        }
      } catch (error) {
        clearTimeout(timeoutId);
        if (error.name !== 'AbortError') {
          console.error("Performance metrics fetch error:", error);
        } else {
          console.warn('[POLL] Performance metrics fetch aborted (timeout)');
        }
      }
    };
    if (showDashboard) {
      fetchPerformanceMetrics();
    }
    const interval = setInterval(fetchPerformanceMetrics, 2000);
    return () => {
      clearInterval(interval);
      console.log('[POLL] Performance metrics polling stopped');
    };
  }, [showDashboard, lastInteractionTime]);

  // Dashboard-specific data fetching 
  useEffect(() => {
    if (!showDashboard) return;
    const fetchDashboardData = async () => {
      console.log('[POLL] Dashboard data fetch started');
      try {
        const [emotionRes, logsRes] = await Promise.all([
          fetch(`${API_BASE_URL}/api/emotion`, {
            headers: { 'Cache-Control': 'no-cache' }
          }).catch(e => ({ ok: false, error: e })),
          fetch(`${API_BASE_URL}/emotion_data_logs`, {
            headers: { 'Cache-Control': 'no-cache' }
          }).catch(e => ({ ok: false, error: e }))
        ]);
        if (emotionRes.ok) {
          const emotionData = await emotionRes.json();
          const logEmotion = emotionData.facial_emotion || emotionData.dominant_emotion;
          if (logEmotion && logEmotion !== "no_face") {
            setEmotion(logEmotion);
          }
          console.log('[POLL] Dashboard emotion fetch success:', emotionData);
        } else if (emotionRes.error) {
          console.error('[POLL] Dashboard emotion fetch error:', emotionRes.error);
        }
        if (logsRes.ok) {
          const logsData = await logsRes.json();
          console.log("📊 Dashboard logs data:", logsData);
          if (logsData.logs && logsData.logs.length > 0) {
            const latestLog = logsData.logs[logsData.logs.length - 1];
            if (latestLog.timing) {
              setPerformanceMetrics(prev => ({
                ...prev,
                ...latestLog.timing
              }));
            }
          }
          console.log('[POLL] Dashboard logs fetch success:', logsData);
        } else if (logsRes.error) {
          console.error('[POLL] Dashboard logs fetch error:', logsRes.error);
        }
      } catch (error) {
        console.error("Dashboard data fetch error:", error);
      }
    };
    fetchDashboardData();
    const interval = setInterval(fetchDashboardData, 2000);
    return () => {
      clearInterval(interval);
      console.log('[POLL] Dashboard data polling stopped');
    };
  }, [showDashboard, lastInteractionTime]);

  // Simplified interaction status check (remove if redundant)
  useEffect(() => {
    if (!backendConnected) return;
    const checkInteractionStatus = async () => {
      console.log('[POLL] Interaction status check started');
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        controller.abort();
        console.warn('[POLL] Interaction status check timed out');
      }, 5000);
      try {
        const res = await fetch(INTERACTION_FLAGS_URL, {
          signal: controller.signal,
          headers: { 'Cache-Control': 'no-cache' }
        });
        clearTimeout(timeoutId);
        if (res.ok) {
          const status = await res.json();
          const backendPhase = status.current_phase || 
            (status.listening_active ? "listening" :
            status.stt_processing_active ? "stt_processing" :
            status.processing_active ? "processing" :
            status.avatar_talking ? "speaking" :
            "idle");
          setIsListening(status.listening_active);
          setIsProcessing(status.processing_active);
          setIsTalking(status.avatar_talking);
          if (backendPhase !== currentPhase) {
            console.log(`🔄 Phase transition: ${currentPhase} → ${backendPhase}`);
            setCurrentPhase(backendPhase);
            switch (backendPhase) {
              case "idle":
                if (!reply || reply.includes("✅ Ready for interaction") || reply.includes("🎤 Listening") || reply.includes("⚙️ Processing") || reply.includes("��️ Speaking")) {
                setReply("✅ Ready for interaction");
                }
                break;
              case "listening":
                setReply("🎤 Listening...");
                // Reset emotions at the start of a new interaction
                if (currentPhase !== "listening") {
                  resetAvatarState();
                  // Force immediate neutral display
                  setStableEmotion("neutral");
                  setLastFetchedEmotion("neutral");
                  setDominantEmotionSet(false); // Ensure flag is reset
                  setEmotionLocked(true); // Lock emotion updates during interaction
                }
                break;
              case "processing":
                setReply("⚙️ Processing...");
                // Fetch the current dominant emotion immediately when processing phase begins
                fetchCurrentDominantEmotion();
                break;
              case "speaking":
                setReply("🗣️ Speaking...");
                // Fetch the LLM response and dominant emotion immediately when speaking phase begins
                fetchCurrentLlmResponse();
                fetchCurrentDominantEmotion();
                break;
              default:
                setReply("🔄 System busy...");
            }
          }
          console.log('[POLL] Interaction status fetch success:', status);
        } else {
          console.error('[POLL] Failed to fetch interaction status: HTTP', res.status);
        }
      } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
          console.warn('[POLL] Interaction status fetch aborted (timeout)');
        } else {
          console.error('[POLL] Error checking interaction status:', error);
        }
      }
    };
    const interval = setInterval(checkInteractionStatus, 1000);
    return () => {
      clearInterval(interval);
      console.log('[POLL] Interaction status polling stopped');
    };
  }, [backendConnected, currentPhase, isRecording]);

  // Poll for current dominant emotion during processing and speaking phases
  useEffect(() => {
    if ((currentPhase !== "processing" && currentPhase !== "speaking") || !backendConnected) return;
    
    const pollDominantEmotion = async () => {
      await fetchCurrentDominantEmotion();
    };
    
    // Poll immediately when phase starts
    pollDominantEmotion();
    
    // Then poll every 500ms during these phases for faster response
    const interval = setInterval(pollDominantEmotion, 500);
    
    return () => {
      clearInterval(interval);
    };
  }, [currentPhase, backendConnected]);

  // Dashboard toggle handler
  const toggleDashboard = () => {
    const newShowDashboard = !showDashboard;
    setShowDashboard(newShowDashboard);
    
    if (newShowDashboard) {
      setLastInteractionTime(Date.now());
      console.log("📊 Dashboard opened - forcing data refresh");
    }
  };

  const speakText = (text, gender = "female") => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = speechSynthesis
      .getVoices()
      .find(v => v.name.toLowerCase().includes(gender.toLowerCase())) || null;
    speechSynthesis.speak(utterance);
  };

  // Function to fetch current LLM response
  const fetchCurrentLlmResponse = async () => {
    try {
      const response = await fetch(CURRENT_LLM_RESPONSE_URL, {
        headers: { 'Cache-Control': 'no-cache' }
      });
      if (response.ok) {
        const data = await response.json();
        if (data.status === "success" && data.llm_response) {
          setCurrentLlmResponse(data.llm_response);
          setllmResponse(data.llm_response);
          setReply(`🤖 ${data.llm_response}`);
          console.log('✅ Current LLM response fetched:', data.llm_response);
        }
      }
    } catch (error) {
      console.warn('⚠️ Failed to fetch current LLM response:', error);
    }
  };

  // Function to update emotion immediately (with lock protection)
  const updateStableEmotion = (newEmotion, force = false) => {
    // Clear any existing timer
    if (emotionStabilityTimerRef.current) {
      clearTimeout(emotionStabilityTimerRef.current);
      emotionStabilityTimerRef.current = null;
    }
    
    // Only update if not locked or if forced
    if (!emotionLocked || force) {
      setStableEmotion(newEmotion);
      console.log('😊 Emotion updated immediately:', newEmotion, force ? '(forced)' : '');
    } else {
      console.log('🔒 Emotion update blocked (locked):', newEmotion);
    }
  };

  // Function to fetch current dominant emotion (only set once per interaction)
  const fetchCurrentDominantEmotion = async () => {
    // Only set dominant emotion once per interaction to prevent alternation
    if (dominantEmotionSet) {
      return;
    }
    
    try {
      const response = await fetch(CURRENT_DOMINANT_EMOTION_URL, {
        headers: { 'Cache-Control': 'no-cache' }
      });
      if (response.ok) {
        const data = await response.json();
        if (data.status === "success" && data.dominant_emotion) {
          const newEmotion = data.dominant_emotion;
          // Only update if we haven't set a dominant emotion yet for this interaction
          if (!dominantEmotionSet) {
            setLastFetchedEmotion(newEmotion);
            updateStableEmotion(newEmotion, true); // Force update
            setDominantEmotionSet(true); // Mark that we've set the dominant emotion
            console.log('😊 Dominant emotion set (once):', newEmotion);
          }
        }
      }
    } catch (error) {
      console.warn('⚠️ Failed to fetch current dominant emotion:', error);
    }
  };

  // Improved LLM communication with better error handling
  const sendToLLM = async (message = "", speak = false, voiceGender = 'female', privacyMode = true) => {
  const messageToSend = message || message;

  if (!messageToSend.trim()) {
    console.warn('⚠️ Empty message - cannot send to LLM');
    setReply('Please enter a message.');
    return 'Please enter a message.';
  }

  if (!backendConnected) {
    console.warn('⚠️ Backend not connected - using fallback response');
    setReply('Backend connection required for LLM interaction.');
    return 'Backend connection required for LLM interaction.';
  }

  // Clean up previous request
  if (abortControllerRef.current) {
    abortControllerRef.current.abort();
  }
  
  abortControllerRef.current = new AbortController();
  
  try {
    setIsProcessing(true);
    setReply("⚙️ Processing your message...");
    
    const response = await fetch(LLM_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        message: messageToSend,
        speak: speak,
        voice_gender: voiceGender,
        privacy_mode: privacyMode
      }),
      signal: abortControllerRef.current.signal
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`LLM API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    console.log('✅ LLM response received:', data);

    const reply = data.reply || 'No reply received.';
    setllmResponse(reply);
    setReply(`🤖 ${reply}`);

    // Speak the response if enabled
    if (!isMuted && speak) {
      speakText(reply, voiceGender);
    }

    return reply;

  } catch (error) {
    console.error('🔥 Exception in sendToLLM:', error);
    
    let errorMessage = 'I apologize, but I encountered an error processing your message.';
    
    if (error.name === 'AbortError') {
      errorMessage = 'Request timeout. Please try again.';
    } else if (error.message.includes('Failed to fetch')) {
      errorMessage = 'Connection to the avatar failed. Please check your network.';
    }
    
    setReply(`⚠️ ${errorMessage}`);
    return errorMessage;
  } finally {
    setIsProcessing(false);
  }
};

  const clearMessage = () => {
    setMessage("");
  };

  // Avatar interaction with better error handling
  const talkToAvatarWithAPI = async () => {
    if (!backendConnected) {
      setReply("❌ Backend not connected. Please check backend status.");
      return;
    }

    try {
      resetAvatarState(); // Clear previous state
      
      // Force immediate neutral emotion display
      setStableEmotion("neutral");
      setLastFetchedEmotion("neutral");
      setDominantEmotionSet(false); // Reset dominant emotion flag
      setEmotionLocked(true); // Lock emotion updates during interaction
      
      // Clear any pending emotion updates
      if (emotionStabilityTimerRef.current) {
        clearTimeout(emotionStabilityTimerRef.current);
        emotionStabilityTimerRef.current = null;
      }
      
      setIsRecording(true);
      //setReply("🎤 Starting interaction...");

      // --- Start interaction with POST /api/talk
      console.log("🔵 Sending POST /api/talk");
      const response = await fetch(`${API_BASE_URL}/api/talk`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          speak: !isMuted && speakReply,
          voice_gender: voiceGender,
          privacy_mode: privacyMode,
          emotion_context: emotionContextEnabled
        })
      });

      // === Interaction completed
      setIsRecording(false);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      console.log("🟢 Received response from /api/talk", data);

      // --- Immediately fetch latest performance metrics after interaction ---
      if (typeof fetchPerformanceMetrics === 'function') {
        await fetchPerformanceMetrics();
        // --- Fetch again after a short delay to guarantee backend update ---
        setTimeout(() => {
          fetchPerformanceMetrics();
        }, 200);
      }

      if (data.status === "success") {
        const llmText = data.llm_response || "I'm here to help!";
        setllmResponse(llmText);
        setReply(`🤖 ${llmText}`);

      } else {
        throw new Error(data.message || "Interaction failed");
      }

    } catch (error) {
      console.error("❌ talkToAvatarWithAPI error:", error);
      
      // Clear all states immediately on error
      setIsRecording(false);
      setIsProcessing(false);
      
      // Better error classification
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        setCurrentPhase("error");
        setReply("❌ Network error - please check your connection and try again.");
      } else if (error.message.includes('HTTP')) {
        setCurrentPhase("error");
        setReply(`❌ Server error: ${error.message}`);
      } else {
        setCurrentPhase("error");
        setReply(`❌ Error: ${error.message}`);
      }
      
      // Attempt recovery
      setTimeout(() => {
        testBackendConnection();
        recoverSystemState();
      }, 2000);
    }
  };

  // Test backend connectivity with improved error handling
  const testBackendConnection = async () => {
    try {
      setReply("🔍 Testing backend connection...");
      
      const response = await fetch("http://localhost:5000/api/health", {
        headers: {'Cache-Control': 'no-cache'}
      });
      
      if (response.ok) {
        const data = await response.json();
        const isHealthy = data.status === "healthy" || data.status === "degraded";
        setHealthData(data);
        setBackendConnected(isHealthy);
        
        // Update all status indicators consistently
        if (isHealthy) {
          setCurrentPhase("idle");
          if (!reply || reply.includes("❌") || reply.includes("🔍")) {
          setReply(data.status === "healthy" ? "✅ System ready" : "⚠️ System degraded but operational");
          }
        }
        return true;
      }
    } catch (error) {
      setBackendConnected(false);
      setCurrentPhase("error");
      setReply("❌ Backend connection failed");
      return false;
    }
  };

  useEffect(() => {
    testBackendConnection();  // Test backend on component mount
  }, []);

  useEffect(() => {
    return () => {
      cleanupControllers();  // Cleanup on unmount
      
      // Clear emotion stability timer on unmount
      if (emotionStabilityTimerRef.current) {
        clearTimeout(emotionStabilityTimerRef.current);
      }
    };
  }, [cleanupControllers]);

  // Function to open user interface in new tab
  const openUserInterfaceInNewTab = () => {
    const currentUrl = new URL(window.location.href);
    currentUrl.searchParams.set('view', 'user');
    
    const newWindow = window.open(currentUrl.toString(), '_blank', 'width=1000,height=800,scrollbars=yes,resizable=yes');
    
    if (newWindow) {
      console.log('✅ User interface opened in new tab');
    } else {
      console.error('❌ Failed to open new tab - popup blocked?');
      alert('Failed to open new tab. Please check if popups are blocked.');
    }
  };

  const talkToAvatar = talkToAvatarWithAPI;

  // If on user interface view, render the UserInterface component
  if (currentView === "user") {
    return (
      <UserInterface
        emotion={stableEmotion}
        reply={reply}
        message={message}
        setMessage={setMessage}
        sendToLLM={sendToLLM}
        clearMessage={clearMessage}
        talkToAvatar={talkToAvatar}
        isRecording={isRecording}
        isProcessing={isProcessing}
        privacyMode={privacyMode}
        setPrivacyMode={setPrivacyMode}
        isMuted={isMuted}
        setIsMuted={setIsMuted}
        speakReply={speakReply}
        setSpeakReply={setSpeakReply}
        voiceGender={voiceGender}
        setVoiceGender={setVoiceGender}
        onBackToControl={() => setCurrentView("control")}
        backendConnected={backendConnected}
        emotionContextEnabled={emotionContextEnabled}
      />
    );
  }

  // Control Panel View (original interface)
  return (
    <div style={{ 
      height: "100vh", 
      width: "100vw", 
      padding: "1vh 2vw", 
      display: "flex", 
      flexDirection: "column", 
      boxSizing: "border-box",
      overflow: "hidden",
      backgroundColor: "linear-gradient(to right, #1e3c72, #2a5298)"
    }}>
      <h1 style={{ 
        textAlign: "center", 
        fontSize: "clamp(1.2rem, 2.5vw, 1.75rem)", 
        margin: "0 0 1vh 0" 
      }}>
        🤖 Emotion-Aware Avatar Control Panel
      </h1>

      {/* Top Navigation Bar */}
      <div style={{ 
        display: "flex", 
        justifyContent: "space-between", 
        alignItems: "center", 
        margin: "1vh 0",
        position: "relative",
        height: "6vh",
        minHeight: "40px"
      }}>
        <button
          onClick={toggleDashboard}
          style={{
            padding: "1vh 2vw",
            fontSize: "clamp(12px, 1.5vw, 16px)",
            background: showDashboard ? "#ccc" : "#4CAF50",
            color: showDashboard ? "#000" : "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
            height: "100%",
            minWidth: "150px"
          }}
        >
          {showDashboard ? "👤 Back to Avatar" : "📊 View Emotion Dashboard"}
        </button>

        <h3 style={{
          position: "absolute",
          left: "50%",
          transform: "translateX(-50%)",
          margin: 0,
          fontSize: "clamp(14px, 1.8vw, 18px)",
          color:
            currentPhase === "listening" ? "green" :
            currentPhase === "stt_processing" ? "orange" :
            currentPhase === "processing" ? "blue" :
            currentPhase === "speaking" ? "purple" :
            currentPhase === "idle" ? "gray" :
            "red"
        }}>
          {
            currentPhase === "listening" ? "🎧 Listening Mode: ON" :
            currentPhase === "stt_processing" ? "⏳ Processing speech..." :
            currentPhase === "processing" ? "🧠 Generating Response..." :
            currentPhase === "speaking" ? "🔊 Speaking..." :
            currentPhase === "idle" ? "✅ Ready for interaction" :
            "🛑 System Error"
          }
        </h3>

        <button
          onClick={openUserInterfaceInNewTab}
          style={{
            padding: "1vh 2vw",
            fontSize: "clamp(12px, 1.5vw, 16px)",
            background: "#007bff",
            color: "#fff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
            whiteSpace: "nowrap",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }}
        >
          <div
            style={{
              width: "12px",
              height: "12px",
              borderRadius: "50%",
              backgroundColor: backendConnected ? (healthData?.status === "healthy" ? "#00ff00" : healthData?.status === "degraded" ? "#ffff00" : "#999") : "#ff0000",
              flexShrink: 0
            }}
          ></div>
          {backendConnected ? (healthData?.status === "healthy" ? "✅Connect" : healthData?.status === "degraded" ? "⚠️Connect" : "Unknown ❓") : "Disconnected"}
        </button>
      </div>

      {showDashboard ? (
        <div style={{ flex: 1, overflow: "auto" }}>
          <EmotionDashboard performanceMetrics={performanceMetrics} emotionContextEnabled={emotionContextEnabled} />
        </div>
      ) : (
        <div style={{
          flex: 1,
          display: "flex",
          gap: "2vw",
          overflow: "hidden"
        }}>
          {/* Left - Message Input */}
          <div style={{ 
            flex: "0 0 25vw", 
            minWidth: "250px",
            display: "flex",
            flexDirection: "column"
          }}>
            <input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type a message to the avatar..."
              style={{
                padding: "1.5vh",
                width: "100%",
                fontSize: "clamp(14px, 1.5vw, 16px)",
                borderRadius: "6px",
                border: "1px solid #ccc",
                boxSizing: "border-box"
              }}
            />
            <div style={{ marginTop: "1vh", display: "flex", gap: "1vw" }}>
              <button
                onClick={() => sendToLLM(message, speakReply, voiceGender, privacyMode)}
                disabled={!backendConnected}
                style={{
                  flex: 1,
                  padding: "1.5vh",
                  backgroundColor: backendConnected ? "#007bff" : "#ccc",
                  color: "#fff",
                  border: "none",
                  borderRadius: "6px",
                  cursor: backendConnected ? "pointer" : "not-allowed",
                  fontSize: "clamp(12px, 1.4vw, 16px)"
                }}
              >
                Send to Avatar
              </button>
              <button
                onClick={clearMessage}
                style={{
                  padding: "1.5vh",
                  backgroundColor: "#6c757d",
                  color: "#fff",
                  border: "none",
                  borderRadius: "6px",
                  cursor: "pointer",
                  fontSize: "clamp(12px, 1.4vw, 16px)",
                  minWidth: "60px"
                }}
                aria-label="Clear message input"
              >
                Clear
              </button>
            </div>

            {(llmResponse || reply) && (
              <div style={{ 
                marginTop: "2vh", 
                fontStyle: "italic", 
                color: "#333",
                fontSize: "clamp(12px, 1.3vw, 14px)",
                flex: 1,
                overflow: "auto"
              }}>
                <strong>Avatar says:</strong> {llmResponse || reply}
              </div>
            )}
          </div>

          {/* Center - Avatar and Controls */}
          <div style={{ 
            flex: 1, 
            display: "flex", 
            flexDirection: "column", 
            alignItems: "center",
            minWidth: "400px"
          }}>
            <div
              style={{
                width: "min(45vw, 475px)",
                height: "min(40vh, 400px)", 
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                overflow: "visible",
                position: "relative",
                flex: 1
              }}
            >
              <div style={{ transform: "translateY(-8vh)" }}>
                <RobotAvatar emotion={stableEmotion} isSpeaking={currentPhase === "speaking"} emotionContextEnabled={emotionContextEnabled} />
              </div>
            </div>

            {/* Line 1: 3 Checkboxes */}
            <div style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: "2vw",
              marginTop: "1vh",
              flexWrap: "wrap"
            }}>
              <label style={{ 
                fontSize: "clamp(12px, 1.3vw, 14px)", 
                display: "inline-flex", 
                alignItems: "center",
                whiteSpace: "nowrap"
              }}>
                <input
                  type="checkbox"
                  checked={privacyMode}
                  onChange={(e) => setPrivacyMode(e.target.checked)}
                />
                <span style={{ marginLeft: "8px" }}>Privacy Mode</span>
              </label>
              <label style={{ 
                fontSize: "clamp(12px, 1.3vw, 14px)", 
                display: "inline-flex", 
                alignItems: "center",
                whiteSpace: "nowrap"
              }}>
                <input
                  type="checkbox"
                  checked={isMuted}
                  onChange={(e) => setIsMuted(e.target.checked)}
                />
                <span style={{ marginLeft: "8px" }}>Mute Voice</span>
              </label>
              <label style={{ 
                fontSize: "clamp(12px, 1.3vw, 14px)", 
                display: "inline-flex", 
                alignItems: "center",
                whiteSpace: "nowrap"
              }}>
                <input
                  type="checkbox"
                  checked={speakReply}
                  onChange={(e) => setSpeakReply(e.target.checked)}
                />
                <span style={{ marginLeft: "8px" }}>Speak Avatar Reply</span>
              </label>
              <label style={{ 
                fontSize: "clamp(12px, 1.3vw, 14px)", 
                display: "inline-flex", 
                alignItems: "center",
                whiteSpace: "nowrap"
              }}>
                <input
                  type="checkbox"
                  checked={emotionContextEnabled}
                  onChange={(e) => setEmotionContextEnabledWithStorage(e.target.checked)}
                />
                <span style={{ marginLeft: "8px" }}>Emotion Context</span>
              </label>
            </div>

            {/* Line 2: Voice + Talk */}
            <div style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: "2vw",
              marginTop: "2vh",
              flexWrap: "nowrap"
            }}>
              <label style={{ 
                fontSize: "clamp(12px, 1.3vw, 14px)", 
                display: "inline-flex", 
                alignItems: "center", 
                whiteSpace: "nowrap" 
              }}>
                Voice Gender:
                <select
                  value={voiceGender}
                  onChange={(e) => setVoiceGender(e.target.value)}
                  style={{
                    padding: "0.8vh 1vw",
                    borderRadius: "6px",
                    border: "1px solid #ccc",
                    marginLeft: "8px",
                    fontSize: "clamp(12px, 1.2vw, 14px)"
                  }}
                >
                  <option value="female">Female</option>
                  <option value="male">Male</option>
                </select>
              </label>
          
              <button
                onClick={talkToAvatarWithAPI} // Use the improved version
                disabled={["listening", "processing", "speaking"].includes(currentPhase) || !backendConnected}
                style={{
                  padding: "1.2vh 2vw",
                  background: !backendConnected ? "#999" : healthData?.status === "healthy"  ? "#4CAF50"  : healthData?.status === "degraded"  ? "#FFC107"  : ["listening", "processing", "speaking"].includes(currentPhase)  ? "#999"  : "#F44336",
                  color: "#fff",
                  border: "none",
                  borderRadius: "5px",
                  fontSize: "clamp(14px, 1.5vw, 16px)",
                  cursor: ["listening", "processing", "speaking"].includes(currentPhase) || !backendConnected  ? "not-allowed"  : "pointer",
                  whiteSpace: "nowrap",
                  transition: "background 0.2s ease"
                }}
              >
                {!backendConnected ? "❌ Backend Offline" :
                  currentPhase === "listening" ? "🎤 Listening..." :
                  currentPhase === "processing" ? "🧠 Thinking..." :
                  currentPhase === "speaking" ? "🔊 Responding..." :
                  healthData?.status === "healthy" ? "🎙️ Talk to Avatar" :
                  healthData?.status === "degraded" ? "⚠️ Talk to Avatar" :
                  "⚠️ System Issues"}
              </button>

              <button
                onClick={testBackendConnection}
                style={{
                  padding: "1vh 1.5vw",
                  fontSize: "clamp(12px, 1.3vw, 14px)",
                  background: backendConnected ? (healthData?.status === "healthy" ? "#4CAF50" : "#FFC107") : "#F44336",
                  color: "#fff",
                  border: "none",
                  borderRadius: "5px",
                  cursor: "pointer",
                  whiteSpace: "nowrap"
                }}
              >
                <div
                  style={{display: "flex", gap: "1vw", marginTop: "0.25vh",
                    backgroundColor: backendConnected ? (healthData?.status === "healthy" ? "#00ff00" : "#ffff00") : "#ff0000", flexShrink: 0
                  }}>
                </div>
                {backendConnected ? (healthData?.status === "healthy" ? "🔍Test Backend" : "🔍Test Backend") : "🔍Test Backend"}
              </button>

              <button
                onClick={hardResetSystem}
                style={{
                  padding: "1vh 1.5vw",
                  fontSize: "clamp(12px, 1.3vw, 14px)",
                  background: backendConnected ? (healthData?.status === "healthy" ? "#4CAF50" : "#FFC107") : "#F44336",
                  color: "#fff",
                  border: "none",
                  borderRadius: "5px",
                  cursor: "pointer",
                  whiteSpace: "nowrap"
                }}
              >
                <div
                  style={{display: "flex", gap: "1vw", marginTop: "0.25vh",
                    backgroundColor: backendConnected ? (healthData?.status === "healthy" ? "#00ff00" : "#ffff00") : "#ff0000", flexShrink: 0
                  }}>
                </div>
                {backendConnected ? (healthData?.status === "healthy" ? "♻️ Hard Reset System" : "♻️ Hard Reset System") : "♻️ Hard Reset System"}
              </button>
            </div>

            {currentPhase === "listening" && (
                <div style={{ color: "green", marginTop: "1vh", fontStyle: "italic", fontSize: "clamp(12px, 1.3vw, 14px)" }}>
                    🎤 Listening for your voice...
                </div>
            )}

            {currentPhase === "stt_processing" && (
                <div style={{ color: "orange", marginTop: "1vh", fontStyle: "italic", fontSize: "clamp(12px, 1.3vw, 14px)" }}>
                    ⏳ PROCESSING STT - Analyzing speech...
                </div>
            )}

            {currentPhase === "processing" && (
                <div style={{ color: "blue", marginTop: "1vh", fontStyle: "italic", fontSize: "clamp(12px, 1.3vw, 14px)" }}>
                    🧠 Processing your request...
                </div>
            )}

            {currentPhase === "speaking" && (
                <div style={{ color: "purple", marginTop: "1vh", fontStyle: "italic", fontSize: "clamp(12px, 1.3vw, 14px)" }}>
                    🔊 Avatar is speaking...
                </div>
            )}

            {/* Error state indicator */}
            {currentPhase === "error" && (
                <div style={{ color: "red", marginTop: "1vh", fontStyle: "italic", fontSize: "clamp(12px, 1.3vw, 14px)" }}>
                    ❌ Error occurred - System will recover shortly
                </div>
            )}

            {/* Ready state indicator */}
            {currentPhase === "idle" && reply && (
                <div style={{ color: "green", marginTop: "1vh", fontStyle: "italic", fontSize: "clamp(12px, 1.3vw, 14px)" }}>
                     {reply}
                </div>
            )}
            
            {/* Performance Metrics Preview */}
            {Object.keys(performanceMetrics).length > 0 && (
              <div style={{ 
                marginTop: "2vh", 
                padding: "1vh", 
                backgroundColor: "#f8f9fa", 
                borderRadius: "5px",
                fontSize: "clamp(10px, 1.1vw, 12px)",
                color: "#666",
                textAlign: "center"
              }}>
                <strong>Last Performance:</strong> {
                  performanceMetrics.total_time ? 
                  `${performanceMetrics.total_time}s total` : 
                  "No recent data"
                }
              </div>
            )}
          </div>

          {/* Right - Live Camera */}
          <div style={{ 
            flex: "0 0 25vw", 
            minWidth: "250px",
            display: "flex",
            flexDirection: "column"
          }}>
            <label style={{ fontSize: "clamp(14px, 1.5vw, 16px)" }}>
              <input
                type="checkbox"
                checked={showVideo}
                onChange={(e) => setShowVideo(e.target.checked)}
              />
              <span style={{ marginLeft: "10px" }}>Show Live Camera</span>
            </label>

            {showVideo && backendConnected && (
              <img
                src="http://localhost:5000/video_feed"
                alt="Live Feed"
                style={{
                  width: "100%",
                  borderRadius: "8px",
                  marginTop: "1vh",
                  marginTop: "1vh",
                  maxHeight: "60vh",
                  objectFit: "contain"
                }}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default App;

