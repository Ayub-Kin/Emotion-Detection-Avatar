import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import wilcoxon
import os
import re
import numpy as np

# === USER SETTINGS ===
base_path = r"D:\MSc Mechanical Engineering\Emotion Detection\emotion_detection_avatar"

emotion_file = os.path.join(base_path, "Emotion Detection System results-survey344191.xlsx")
neutral_file = os.path.join(base_path, "Without Emotion Detection - results-survey649222.xlsx")

# Output folder for figures
output_folder = base_path

# Mapping for 7-point Likert scale
likert_7_map = {
    "Strongly Disagree": 1,
    "Disagree": 2,
    "Somewhat Disagree": 3,
    "Neutral": 4,
    "Somewhat Agree": 5,
    "Agree": 6,
    "Strongly Agree": 7
}

# === LOAD DATA ===
emotion_df = pd.read_excel(emotion_file)
neutral_df = pd.read_excel(neutral_file)

# --- Original Survey Columns ---
tone_col_orig = "Please indicate your level of agreement with the following statements about your experience using the social robotic avatar system. [Do you think the system correctly picked up your tone of voice?]"
facial_col_orig = "Please indicate your level of agreement with the following statements about your experience using the social robotic avatar system. [Do you think the system correctly detected your facial emotion while speaking?]"
appropriate_col_orig = "Please indicate your level of agreement with the following statements about your experience using the social robotic avatar system. [The avatar responded with appropriate response.]"

short_labels = {
    tone_col_orig: "Tone Rating",
    facial_col_orig: "Facial Emotion Rating",
    appropriate_col_orig: "Appropriateness Rating"
}

# --- MDMT Columns ---
mdmt_correct_mapping = {
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Reliable]": "Reliable",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Predictable]": "Predictable",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Someone you can count on]": "Someone you can count on",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Consistent]": "Consistent",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Capable]": "Capable",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Skilled]": "Skilled",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Competent]": "Competent",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Meticulous]": "Meticulous",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Sincere]": "Sincere",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Genuine]": "Genuine",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Candid]": "Candid",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Authentic]": "Authentic",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Ethical]": "Ethical",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Respectable]": "Respectable",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Principled]": "Principled",
    "Please rate the social robotic avatar system using the scale from 0 (Not at all) to 7 (Very). If a particular item does not seem to fit the robot in the situation, please select the option that says \"Does not Fit.\" [Has Integrity]": "Has Integrity"
}

# MDMT subscales
mdmt_subscales = {
    "Performance Trust - Reliable": ["Reliable", "Predictable", "Someone you can count on", "Consistent"],
    "Performance Trust - Capable": ["Capable", "Skilled", "Competent", "Meticulous"],
    "Moral Trust - Sincere": ["Sincere", "Genuine", "Candid", "Authentic"],
    "Moral Trust - Ethical": ["Ethical", "Respectable", "Principled", "Has Integrity"]
}

# Automatic conversion for MDMT values
def convert_mdmt_value(val):
    if pd.isna(val) or val == "Does not Fit.":
        return None
    if isinstance(val, str):
        match = re.match(r"(\d+)", val.strip())
        if match:
            return int(match.group(1))
        else:
            return None
    return float(val)

def prepare_mdmt(df, condition_label):
    sub = df[list(mdmt_correct_mapping.keys())].copy()
    for col in sub.columns:
        sub[col] = sub[col].apply(convert_mdmt_value).astype(float)
    sub = sub.rename(columns=mdmt_correct_mapping)
    sub["Condition"] = condition_label
    return sub

# Prepare the original survey data
def prepare_df(df, condition_label):
    df_clean = df[[tone_col_orig, facial_col_orig, appropriate_col_orig]].copy()
    
    # Convert Likert scale responses to numeric values
    for col in df_clean.columns:
        df_clean[col] = df_clean[col].map(likert_7_map)
    
    df_clean["Condition"] = condition_label
    return df_clean

def plot_metric_with_stats(metric_name, file_name):
    plt.figure(figsize=(8, 8))
    subset = melted_df[melted_df["Metric"] == metric_name]
    
    # Create boxplot
    ax = sns.boxplot(
        data=subset,
        x="Metric",
        y="Score",
        hue="Condition",
        palette="Set2",
        showmeans=True,
        meanprops={"marker": "o",
                   "markerfacecolor": "black",
                   "markeredgecolor": "black",
                   "markersize": "6"},
        flierprops=dict(marker='o', markerfacecolor='red', markersize=6, linestyle='none')
    )
    
    # Calculate statistics
    emotion_data = subset[subset["Condition"] == "Emotion Context"]["Score"].dropna()
    neutral_data = subset[subset["Condition"] == "Emotion Neutral"]["Score"].dropna()
    
    # Perform Wilcoxon test
    if len(emotion_data) > 0 and len(neutral_data) > 0:
        # Ensure we have paired data
        min_len = min(len(emotion_data), len(neutral_data))
        if min_len > 0:
            emotion_data = emotion_data[:min_len]
            neutral_data = neutral_data[:min_len]
            
            stat, p = wilcoxon(emotion_data, neutral_data)
            
            # Add statistical annotation
            if p < 0.05:
                # Draw line
                y_max = max(emotion_data.max(), neutral_data.max())
                y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
                y = y_max + y_range * 0.1
                
                # Draw bracket
                x1, x2 = -0.2, 0.2
                ax.plot([x1, x1, x2, x2], [y, y+y_range*0.02, y+y_range*0.02, y], lw=1.5, c='black')
                
                # Add p-value text (always show actual p-value)
                p_text = f"p = {p:.5f}"
                
                ax.text(0, y+y_range*0.03, p_text, 
                        ha='center', va='bottom', color='black', fontsize=12, fontweight='bold')
    
    plt.title(f"{metric_name} Comparison", fontsize=12)
    plt.ylabel("7-Point Likert Score", fontsize=16)
    plt.xlabel("", fontsize=16)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.grid(axis="y", linestyle="--", alpha=0.7)
    plt.legend(title="Condition", fontsize=12, title_fontsize=12)
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, file_name), dpi=300)
    plt.close()
    print(f"✅ Saved: {file_name}")

# === PREPARE DATA ===
emotion_clean = prepare_df(emotion_df, "Emotion Context")
neutral_clean = prepare_df(neutral_df, "Emotion Neutral")

combined_df = pd.concat([emotion_clean, neutral_clean], ignore_index=True)
melted_df = combined_df.melt(id_vars="Condition", var_name="Metric", value_name="Score")
melted_df["Metric"] = melted_df["Metric"].map(short_labels)

# === PLOT ORIGINAL METRICS WITH STATS ===
plot_metric_with_stats("Tone Rating", "boxplot_tone.png")
plot_metric_with_stats("Facial Emotion Rating", "boxplot_facial.png")
plot_metric_with_stats("Appropriateness Rating", "boxplot_appropriate.png")

# === MDMT COMPARISON ===
emotion_mdmt = prepare_mdmt(emotion_df, "Emotion Context")
neutral_mdmt = prepare_mdmt(neutral_df, "Emotion Neutral")

mdmt_combined = pd.concat([emotion_mdmt, neutral_mdmt], ignore_index=True)

# Create subscale scores by averaging items in each subscale
for subscale_name, items in mdmt_subscales.items():
    # Filter items that exist in our data
    existing_items = [item for item in items if item in mdmt_combined.columns]
    if existing_items:
        mdmt_combined[subscale_name] = mdmt_combined[existing_items].mean(axis=1)

# Melt the data for plotting
melted_mdmt = mdmt_combined.melt(id_vars="Condition", 
                                value_vars=list(mdmt_subscales.keys()),
                                var_name="MDMT Subscale", 
                                value_name="Score")

# Function to add statistical annotations to MDMT plot
def add_stat_annotation(ax, data, x_var, hue_var, hue1, hue2):
    positions = sorted(data[x_var].unique())
    hue_order = sorted(data[hue_var].unique())
    
    for i, pos in enumerate(positions):
        subset = data[data[x_var] == pos]
        group1 = subset[subset[hue_var] == hue1]["Score"].dropna()
        group2 = subset[subset[hue_var] == hue2]["Score"].dropna()
        
        # Ensure we have paired data
        min_len = min(len(group1), len(group2))
        if min_len > 0:
            group1 = group1[:min_len]
            group2 = group2[:min_len]
            
            stat, p = wilcoxon(group1, group2)
            
            if p < 0.05:
                # Calculate position for annotation
                y_max = max(group1.max(), group2.max())
                y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
                y = y_max + y_range * 0.05
                
                # Draw bracket
                x_offset = 0.2
                x1 = i - x_offset
                x2 = i + x_offset
                ax.plot([x1, x1, x2, x2], [y, y+y_range*0.02, y+y_range*0.02, y], lw=1.5, c='black')
                
                # Add p-value text (always show actual p-value)
                p_text = f"p = {p:.5f}"
                
                ax.text(i, y+y_range*0.03, p_text, 
                        ha='center', va='bottom', color='black', fontsize=10, fontweight='bold')

# Plot MDMT subscales with statistical annotations
plt.figure(figsize=(12, 10))
ax = sns.boxplot(
    data=melted_mdmt,
    x="MDMT Subscale",
    y="Score",
    hue="Condition",
    palette="Set2",
    showmeans=True,
    meanprops={"marker": "o",
               "markerfacecolor": "black",
               "markeredgecolor": "black",
               "markersize": "5"},
    flierprops=dict(marker='o', markerfacecolor='red', markersize=6, linestyle='none')
)

# Add statistical annotations
add_stat_annotation(ax, melted_mdmt, "MDMT Subscale", "Condition", "Emotion Context", "Emotion Neutral")

plt.title("MDMT Trust Subscales: Emotion Context vs Emotion Neutral", fontsize=12)
plt.ylabel("0–7 Score", fontsize=16)
plt.xlabel("MDMT Subscale", fontsize=16)
plt.xticks(rotation=30, ha="right", fontsize=14)
plt.yticks(fontsize=14)
plt.grid(axis="y", linestyle="--", alpha=0.7)
plt.legend(title="Condition", fontsize=12)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, "boxplot_mdmt_subscales.png"), dpi=300)
plt.close()
print(f"✅ Saved: boxplot_mdmt_subscales.png")

# === STATS FOR MDMT ===
print("\nMDMT Statistical Significance (Wilcoxon signed-rank test):")
for subscale_name in mdmt_subscales.keys():
    emotion_data = mdmt_combined[mdmt_combined["Condition"] == "Emotion Context"][subscale_name].dropna()
    neutral_data = mdmt_combined[mdmt_combined["Condition"] == "Emotion Neutral"][subscale_name].dropna()
    
    # Ensure we have paired data
    min_len = min(len(emotion_data), len(neutral_data))
    if min_len > 0:
        emotion_data = emotion_data[:min_len]
        neutral_data = neutral_data[:min_len]
        
        stat, p = wilcoxon(emotion_data, neutral_data)
        print(f"{subscale_name} → p = {p:.5f}")

# === USER EXPERIENCE ANALYSIS ===

# Godspeed dimensions mapping
godspeed_dimensions = {
    "Anthropomorphism": [
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Fake (1) - Natural (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Machinelike (1) - Humanlike (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Unconscious (1) - Conscious(7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Artificial (1) - Lifelike(7)]"
    ],
    "Animacy": [
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Moving rigidly (1) - Moving elegantly(7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Dead (1) - Alive (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Stagnant (1) - Lively(7)]"
    ],
    "Likeability": [
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Dislike (1) -Like (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Unfriendly (1) - Friendly (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Unkind (1) - Kind (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Unpleasant (1) - Pleasant (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Awful (1) - Nice (7)]"
    ],
    "Perceived Intelligence": [
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Incompetent (1) - Competent (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Ignorant (1) - Knowledgeable (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Irresponsible (1) - Responsible (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Unintelligent (1) - Intelligent (7) ]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Foolish (1)  - Sensible (7)]"
    ],
    "Perceived Safety": [
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Anxious (1) - Relaxed (7)]",
        "Please indicate your level of agreement with the following statements about your experience using the robotic avatar system. [Calm (1)  - Agitated (7)]"
    ]
}

def prepare_godspeed(df, condition_label):
    # Flatten all Godspeed items
    all_godspeed_items = []
    for dimension_items in godspeed_dimensions.values():
        all_godspeed_items.extend(dimension_items)
    
    sub = df[all_godspeed_items].copy()
    for col in sub.columns:
        # Convert to numeric, handling any non-numeric values
        sub[col] = pd.to_numeric(sub[col], errors="coerce")
    
    sub["Condition"] = condition_label
    return sub

# Prepare Godspeed data
emotion_godspeed = prepare_godspeed(emotion_df, "Emotion Context")
neutral_godspeed = prepare_godspeed(neutral_df, "Emotion Neutral")

godspeed_combined = pd.concat([emotion_godspeed, neutral_godspeed], ignore_index=True)

# Create dimension scores by averaging items in each dimension
for dimension, items in godspeed_dimensions.items():
    # Get only the columns that exist in our data
    existing_items = [item for item in items if item in godspeed_combined.columns]
    if existing_items:
        godspeed_combined[dimension] = godspeed_combined[existing_items].mean(axis=1)

# Melt the data for plotting
melted_godspeed = godspeed_combined.melt(id_vars="Condition", 
                                        value_vars=list(godspeed_dimensions.keys()),
                                        var_name="Godspeed Dimension", 
                                        value_name="Score")

# Plot Godspeed dimensions with statistical annotations
plt.figure(figsize=(14, 10))
ax = sns.boxplot(
    data=melted_godspeed,
    x="Godspeed Dimension",
    y="Score",
    hue="Condition",
    palette="Set2",
    showmeans=True,
    meanprops={"marker": "o",
               "markerfacecolor": "black",
               "markeredgecolor": "black",
               "markersize": "5"},
    flierprops=dict(marker='o', markerfacecolor='red', markersize=6, linestyle='none')
)

# Add statistical annotations
add_stat_annotation(ax, melted_godspeed, "Godspeed Dimension", "Condition", "Emotion Context", "Emotion Neutral")

plt.title("Godspeed Questionnaire Dimensions: Emotion Context vs Neutral", fontsize=12)
plt.ylabel("1–7 Rating", fontsize=16)
plt.xlabel("Godspeed Dimension", fontsize=16)
plt.xticks(rotation=30, ha="right", fontsize=14)
plt.yticks(fontsize=14)
plt.grid(axis="y", linestyle="--", alpha=0.7)
plt.legend(title="Condition", fontsize=12)
plt.tight_layout()
plt.savefig(os.path.join(output_folder, "boxplot_godspeed.png"), dpi=300)
plt.close()
print(f"✅ Saved: boxplot_godspeed.png")

# Stats for Godspeed
print("\nGodspeed Dimensions Statistical Significance (Wilcoxon signed-rank test):")
for dimension in godspeed_dimensions.keys():
    emotion_data = godspeed_combined[godspeed_combined["Condition"] == "Emotion Context"][dimension].dropna()
    neutral_data = godspeed_combined[godspeed_combined["Condition"] == "Emotion Neutral"][dimension].dropna()
    
    # Ensure we have paired data
    min_len = min(len(emotion_data), len(neutral_data))
    if min_len > 0:
        emotion_data = emotion_data[:min_len]
        neutral_data = neutral_data[:min_len]
        
        stat, p = wilcoxon(emotion_data, neutral_data)
        print(f"{dimension} → p = {p:.5f}")